% Regresion por minimos cuadrados con ECUACIONES NORMALES  C*a = b   (como en clase)
% TUS COMANDOS (Clase 01, polinomial grado 2):
%   x=0:5 ; y=[2.1 7.7 13.6 27.2 40.9 61.1]'
%   C=[6 sum(x) sum(x.^2); sum(x) sum(x.^2) sum(x.^3); sum(x.^2) sum(x.^3) sum(x.^4)]
%   b=[sum(y); sum(x.*y); sum((x.^2).*y)]
%   a=inv(C)*b                          % a0, a1, a2
% Clase 06, lineal multiple (Excel): C=[n sum(x1) sum(x2); ...], b=[sum(y); sum(x1.*y); sum(x2.*y)]
%   a=MMULT(MINVERSA(C),b)   en Excel  ->  a=inv(C)*b   en Octave
%   Q = suma de (a0+a1*x1+a2*x2-y)^2 ;  SST = suma de (y-media)^2 ;  R2=(SST-Q)/SST
function [a, C, b] = hm_regresion (op)
  if nargin < 1, op=struct(); endif
  printf ("\n1) polinomial (una x, grado n)   2) lineal multiple (varias x: x1, x2, ...)\n");
  modo = pedir ("opcion [1]: ", 1);
  if modo == 2
    X1 = pedir ("columnas de las x, una por variable. Ej [0 0; 2 1; 2.5 2; 1 3; 4 6; 7 2]  (o: excel datos.xlsx B4:C9): ");
    y = pedir ("y (columna), ej [5;10;9;0;3;27]  (o: excel datos.xlsx D4:D9): "); y = y(:);
    Xd = [ones(rows (X1), 1), X1];
    nom = ["a0", arrayfun(@(i) sprintf ("+a%d*x%d", i, i), 1:columns (X1), "UniformOutput", false){:}];
  else
    x = pedir ("x, ej 0:5  (o: excel datos.xlsx A2:A7): "); x = x(:); y = pedir ("y, ej [2.1 7.7 13.6 27.2 40.9 61.1]  (o: excel datos.xlsx B2:B7): "); y = y(:);
    n = pedir ("grado [Enter = 2]: ", 2);
    Xd = x .^ (0:n);
    nom = "a0"; for i = 1:n, nom = [nom sprintf("+a%d*x^%d", i, i)]; endfor
    X1 = x;
  endif
  if rows(Xd)~=numel(y) || rows(Xd)<columns(Xd) || ~ all(isfinite([Xd(:);y])) || rank(Xd)<columns(Xd)
    error("hm_regresion: datos incompatibles o ecuaciones normales sin solucion unica");
  endif
  C = Xd' * Xd; b = Xd' * y;
  printf ("\nC =\n"); disp (C); printf ("b =\n"); disp (b);
  a = inv (C) * b;
  printf ("a = inv(C)*b =\n"); disp (a);
  printf ("modelo: y = %s\n", nom);
  est = Xd * a; err2 = (est - y) .^ 2; Q = sum (err2); SST = sum ((y - mean (y)) .^ 2); R2 = (SST - Q) / SST;
  printf ("\nQ (suma de errores cuadrados) = %.6g\nmedia de y = %.6g\nSST = %.6g\nR^2 = %.6f\n", Q, mean (y), SST, R2);
  nuevo = pedir ("prediccion: valor(es) de x en una fila (Enter = no): ", []);
  if ~ isempty (nuevo)
    if (modo==2 && numel(nuevo)~=columns(X1)) || (modo~=2 && numel(nuevo)~=1) || ~ all(isfinite(nuevo(:)))
      error("hm_regresion: prediccion incompatible con las variables");
    endif
    if modo == 2, v = [1, nuevo(:)']; else v = nuevo(1) .^ (0:n); endif
    printf ("  y estimado = %.6f\n", v * a);
  endif
  assignin ("base", "a", a); assignin ("base", "C", C); assignin ("base", "b", b);
  T = [(1:numel (y))', X1, y, est, err2];
  hdr = [{"obs"}, arrayfun(@(i) sprintf ("x%d", i), 1:columns (X1), "UniformOutput", false), {"y", "y_estimado", "error^2"}];
  if isfield(op,"exportar"), nombre=op.exportar;
  else nombre=strtrim(hm_entrada("exportar formulas vivas? Enter = no, o nombre: ","s")); endif
  if ~ isequal(nombre,false) && ~ isempty(nombre)
    if modo==2, grado=1; else grado=n; endif
    hm_regresion_vivo(nombre,modo,X1,y,grado,nuevo);
  endif
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ~ isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

