% octavei  -  resuelve ejercicios escribiendo el codigo SOLO, una letra por tecla (como en Octave: octave:N>).
%   octavei       -> te pide el ejercicio en un prompt octave:N>  (un numero del catalogo, una palabra, o tu pregunta)
%   octavei 3     -> ejercicio 3 del catalogo (lista: octavei 0)   octavei("pregunta a la IA")  ->  Codex / API
%   Despues presiona CUALQUIER tecla: cada tecla escribe una letra; con la linea terminada otra tecla la ejecuta. Esc sale.
%   Al terminar el ejercicio el Excel se guarda solo en la carpeta actual (tambien: exportar / exportar(3)).
% Uso con IA:  octavei("como hago un plot con dos curvas")
% Necesita una clave en la variable de entorno OPENAI_API_KEY o ANTHROPIC_API_KEY.
% Opcional: OCT_IA_MODEL para cambiar de modelo.  Usa curl (viene en Windows 10/11).
function r = octavei (pregunta)
  if nargout, r = ""; endif
  if nargin < 1, pregunta = hm_entrada (sprintf ("octave:%d> ", hm_prompt_n ()), "s"); endif
  plan = false; imgs_pdf = {}; destino_pdf = "";
  if isstruct (pregunta)
    if isfield (pregunta, "ejercicio"), start_ejercicio (pregunta.ejercicio); return; endif
    if ! isfield (pregunta, "pdf"), error ("octavei: argumento no valido"); endif
    imgs_pdf = hm_pdf_paginas (pregunta.pdf); plan = true;
    [~, nb] = fileparts (pregunta.pdf); nb = regexprep (nb, '[^A-Za-z0-9_-]', "_"); if isempty (nb), nb = "ejercicios"; endif
    destino_pdf = [nb ".xlsx"]; k_ = 1;
    while exist (destino_pdf, "file"), k_++; destino_pdf = sprintf ("%s_%d.xlsx", nb, k_); endwhile
    pregunta = ["Las imagenes son las paginas, en orden, de un examen o practica en PDF (incluye sus graficos y tablas). Identifica TODOS los ejercicios y resuelvelos cada uno como pide su enunciado. ANALIZA cada enunciado antes de resolverlo (que pide, que metodo de su clase, que hay que preparar a papel, que datos cambiaron respecto a sus ejemplos); no copies un ejemplo. " ...
                "FORMATO OBLIGATORIO, un bloque por ejercicio y en orden: una linea  @@EJ n | octave | titulo corto  (o  @@EJ n | excel | titulo corto  si el ejercicio se resuelve SOLO en Excel, sin Octave: lo dice el enunciado o es una tabla de calculo que no pide Octave). " ...
                "TODOS los ejercicios llevan su bloque ```excel (tambien los de tipo octave, incluidos Jacobi/Gauss-Seidel/punto fijo/Newton: el estudiante arma un Excel por ejercicio). Para tipo octave: el bloque ```octave con los comandos y luego su bloque ```excel. Para tipo excel: su bloque ```excel y, SOLO si el ejercicio tambien se puede hacer con los comandos de su clase, ademas un bloque ```octave (queda disponible por si el estudiante lo pide). " ...
                "CUANDO ES excel: el enunciado dice que se resuelve en Excel/hoja de calculo, o no pide Octave y el tema solo tiene hoja (en su clase NO hay codigo de Octave de: regresion lineal multiple, reordenar/acondicionar a E.D.D. a mano, los calculos de L_i(x) y P(x) de Lagrange, la interpolacion de Newton por diferencias divididas; en regresion polinomial la docente solo hizo en Octave los datos, el grafico y el inline). Si el enunciado nombra Octave o comandos, es octave. En duda, octave. " ...
                "PLANTILLAS OBLIGATORIAS en el bloque excel: sistemas no lineales (Newton, punto fijo), Jacobi y Gauss-Seidel, interpolacion de Lagrange/Newton y regresion usan SIEMPRE su plantilla JSON (puntofijo, newtonsistemas, jacobi, gaussseidel, interpolacion, regresion, multiple); si una misma pregunta pide varios metodos iterativos usa la plantilla examen con la lista de metodos; NUNCA hojas con filas libres y formulas inventadas para esos temas, ni nombres como FORMULA_0. Cada ejercicio lleva su PROPIO JSON de excel con un nombre de archivo distinto (ej1_tema, ej2_tema...). Fuera de los bloques, maximo una linea por ejercicio. No escribas nada antes del primer @@EJ."];
  endif
  if isnumeric (pregunta) && isscalar (pregunta), pregunta = sprintf ("%d", pregunta); endif
  if isempty (strtrim (pregunta)), return; endif
  if ischar (pregunta) && any (strcmpi (strtrim (pregunta), {"setup", "clave", "ajustes"})), oif_setup (); return; endif
  % clave de Claude: primero la variable de entorno, luego el archivo guardado con oif_setup; la primera vez la pide una sola vez
  if isempty (getenv ("ANTHROPIC_API_KEY")) && isempty (getenv ("OCT_IA_PROVIDER"))
    fk = fullfile (oif_home (), ".oif", "anthropic_key");
    if exist (fk, "file")
      fid = fopen (fk, "r"); kk = strtrim (fread (fid, Inf, "char=>char")'); fclose (fid); setenv ("ANTHROPIC_API_KEY", kk);
    elseif ! exist (fullfile (oif_home (), ".oif", "omitido"), "file") && isempty (getenv ("OPENAI_API_KEY"))
      oif_setup ();
    endif
  endif
  % comandos del paquete escritos dentro del prompt de octavei (haz 1, haz ta1, ss2, exportar...): se ejecutan, no se mandan a la IA
  if ischar (pregunta) && ! isempty (regexp (strtrim (pregunta), '^(haz\d*|ss\d*|start|exportar|export)(\s|$)', "once"))
    evalin ("base", strtrim (pregunta)); return
  endif
  % catalogo: octavei 3 | octavei notas | octavei 0 (lista)
  if strcmp (strtrim (pregunta), "0") || strcmpi (strtrim (pregunta), "lista")
    E = hm_catalogo ();
    for k = 1:numel (E), printf ("  %2d) %s%s\n", E(k).id, E(k).nombre, merge (isempty (E(k).excel), "", "   [Excel]")); endfor
    return
  endif
  if ! plan && isempty (strfind (pregunta, "@"))
    e = hm_catalogo (pregunta);
    if ! isempty (e), catalogo (e); return; endif
  endif
  % libro: escribe @mi_libro.xlsx para que el Excel de la IA se agregue como hoja nueva a una COPIA de ese libro (lo tuyo no se toca)
  libro = "";
  [tk, rs] = regexp (pregunta, '@(?:"([^"]+\.xlsx)"|(\S+\.xlsx))', "tokens", "split", "ignorecase");
  if ! isempty (tk)
    libro = make_absolute_filename (tk{1}{find (! cellfun (@isempty, tk{1}), 1)});
    if ! exist (libro, "file"), error ("octavei: no encuentro el libro %s", libro); endif
    pregunta = strtrim (strjoin (rs, " "));
  endif
  % imagenes: escribe @archivo.png dentro de la pregunta (ej: octavei("resuelve este ejercicio @ej1.png"))
  [tok, rest] = regexp (pregunta, '@(?:"([^"]+\.(?:png|jpe?g|webp|gif))"|(\S+\.(?:png|jpe?g|webp|gif)))', "tokens", "split", "ignorecase");
  tok = cellfun (@(t) {t{find (! cellfun (@isempty, t), 1)}}, tok, "UniformOutput", false);
  imgs = cellfun (@(t) make_absolute_filename (t{1}), tok, "UniformOutput", false);
  if plan, imgs = imgs_pdf; endif
  for i = 1:numel (imgs), if ! exist (imgs{i}, "file"), error ("octavei: no encuentro la imagen %s", imgs{i}); endif, endfor
  if ! isempty (imgs), pregunta = strtrim (strjoin (rest, " ")); if isempty (pregunta), pregunta = "Resuelve lo que muestra la imagen con mis pasos de clase."; endif, endif
  sis = ["Eres un tutor de Octave para un estudiante de metodos numericos. Responde en espanol, corto. " ...
         "Usa SOLO los comandos y nombres de variables de su clase, un comando por linea, sin bucles for ni funciones propias: " ...
         "BJ=[...]; C=[...]; norm(BJ); norm(BJ,1); norm(BJ,inf); eig(BJ); radio espectral=max(abs(eig(BJ))); X0=[0;0;0]; " ...
         "X1=BJ*X0+C; E1=norm(X1-X0,inf); para no lineales: syms x y; g1=...; diff(g1,x); double(subs(...,[x y],[a b])); " ...
         "Newton: F=[f1;f2]; J=jacobian(F,[x y]); IJ=inv(J); X1=X0-double(subs(IJ,[x y],X0))*double(subs(F,[x y],X0)). " ...
         "Si hay que reordenar ecuaciones, explicalo como en papel: cada incognita se despeja de la ecuacion donde su coeficiente es mayor. " ...
         "La tabla de evidencia en Excel tiene columnas I | Xi | E (un bloque de filas por iteracion). " ...
         "Si pide resolver un metodo completo, dile que use h(\"nombre del metodo\") o octavei con la palabra ejemplo. " ...
         "ANALISIS PREVIO OBLIGATORIO (antes de escribir el codigo o el JSON, razona en silencio y no lo imprimas): los enunciados cambian de datos, de orden y de lo que preguntan, asi que NO copies un ejemplo; analiza cada ejercicio: (1) que pide exactamente cada inciso (valor, error, cota, comparar, converge?, cuantas iteraciones, a que x evaluar); (2) con cual de SUS metodos de clase y cual plantilla se resuelve; (3) que hay que preparar a papel antes: reordenar ecuaciones para E.D.D., despejar cada incognita, derivar J(x) a mano, elegir g, elegir los nodos y grados mas cercanos, decidir x0; (4) verifica los datos (J coincide con F, las g salen de despejes reales, los nodos del enunciado, el numero de iteraciones o la tolerancia pedidos); (5) llena la plantilla con SOLO los datos del enunciado y lo que se derive de ellos; agrega SOLO las partes que el enunciado pide (comparacion, cota, convergencia, interpretacion); si el ejercicio mezcla temas o no cabe en una plantilla, combina plantillas o usa el formato general siguiendo la estructura de sus hojas de clase. Ante ambiguedad elige lo que haria el estudiante en clase y dilo en UNA linea. " ...
         "REGLA PRINCIPAL: antes de responder, decide con cual de SUS metodos/scripts se resuelve el ejercicio y resuelvelo IGUAL que ellos, sin inventar otros metodos ni atajos. " ...
         "ALCANCE: SOLO la Unidad 2 (desde el 14 de septiembre). NO uses biseccion, regla falsa, secante, Muller ni scripts como Biseccion/RegulaFalsi/Punto/NewtonRaphson/Secante de 1 variable: son de clases anteriores. " ...
         "Sus metodos y comandos de la Unidad 2 son: " ...
         "GAUSS-JORDAN con filas aumentadas: f1=[3 -0.1 -0.2 7.85]; f1=f1/f1(1); f2=-f2(1)*f1+f2; f3=-f3(1)*f1+f3; f2=f2/f2(2); f1=-f1(2)*f2+f1; ... " ...
         "LU: [L,U]=lu(A); L*U; y=inv(L)*b; x=inv(U)*y; x=inv(A)*b. CHOLESKY: U=chol(A); U'*U; y=inv(U')*b; x=inv(U)*y. CRAMER: DA=det(A); X1=A con la columna 1 cambiada por b; Dx1=det(X1); x1=Dx1/DA. " ...
         "NORMAS: norm(A); norm(A,1); norm(A,inf); eig(A); radio espectral = mayor |autovalor| = max(abs(eig(A))); cond(A). " ...
         "JACOBI y GAUSS-SEIDEL: BJ=[...]; C=[...]; X0=[0;0;0]; X1=BJ*X0+C, E1=norm(X1-X0,inf); X2=BJ*X1+C, E2=norm(X2-X1,inf)... hasta E<tolerancia (en Gauss-Seidel BJ=-((D+L)\\U) y C=(D+L)\\b, con X0=[1;1;1] en su ejemplo). " ...
         "ANTES DE ITERAR (Jacobi, Gauss-Seidel, punto fijo y Newton de sistemas) SIEMPRE este orden, como en clase: (1) si hace falta, acondicionar/reordenar para E.D.D. y explicarlo en comentarios %; (2) armar BJ y C (o G y sus derivadas); (3) verificar CONVERGENCIA antes (SOLO si el enunciado lo pide o hace falta: estudiar convergencia, E.D.D., comprobar el jacobiano; si no lo pide NO lo hagas y despues de X0 se va directo a X1; cuando se hace, escribelo con comentarios % que expliquen que se esta comprobando y por que, para que el estudiante lo vea y lo capture): norm(BJ,inf), norm(BJ,1) menores que 1 o max(abs(eig(BJ))) menor que 1 (en punto fijo: sumas de columnas de las derivadas < 1 en el punto inicial); (4) recien despues iterar X1,E1,X2,E2... hasta la tolerancia o las iteraciones que pida el enunciado. " ...
         "PUNTO FIJO de sistemas: f1=inline('...','x','y'); ezplot(f1); hold on; ezplot(f2); pkg load symbolic; syms x y; g1=...; g2=...; dg1x=diff(g1,x); dg1y=diff(g1,y); dg2x=diff(g2,x); dg2y=diff(g2,y); " ...
         "double(subs(dg1x,[x y],[x0 y0])) para revisar que converge (sumas de columnas < 1; si no da punto inicial usar 0 0); luego x0=0;y0=0; X0=[x0;y0]; x1=double(subs(g1,[x y],[x0 y0])); y1=double(subs(g2,[x y],[x0 y0])); X1=[x1;y1]; E1=norm(X1-X0,inf); ... " ...
         "NEWTON de sistemas (2 o 3 variables): pkg load symbolic; syms x y z; f1=...; f2=...; f3=...; F=[f1;f2;f3]; J=jacobian(F,[x y z]); IJ=inv(J); X0=[1;0;0]; luego DIRECTO X1=X0-double(subs(IJ,[x y z],X0))*double(subs(F,[x y z],X0)); E1=norm(X1-X0,inf); X2=X1-double(subs(IJ,[x y z],X1))*double(subs(F,[x y z],X1)); E2=norm(X2-X1,inf). Usa X0 SIN transpuesta (nunca X0'), como la docente; el determinante/jacobiano/convergencia solo se comprueban si el enunciado lo pide, y entonces con comentarios % antes de X1 (det(J) evaluado en X0, norm, etc.); el vector X1 resultante es el que se copia a la tabla I | Xi | Ei. " ...
         "JACOBI y GAUSS-SEIDEL: el estudiante debe MOSTRAR EN PAPEL el despeje, asi que antes de BJ escribe lineas de comentario %: (a) si reordenaste, las ecuaciones reordenadas para E.D.D.; (b) UNA linea por incognita con su despeje (ej. % -3x - z = 2  ->  x = (-2 - z)/3), en el mismo orden de BJ; recien despues BJ=[...] y C=[...]. En el JSON de la plantilla manda esos mismos textos en \"despeje\" y \"sistema\". " ...
         "PUNTO FIJO con 3 variables: antes de g1,g2,g3 escribe un comentario % con el despeje de cada ecuacion (de cual ecuacion sale cada g); en dos iteraciones usa x0=..;y0=..;z0=..; x1=double(subs(g1,[x y z],[x0 y0 z0])); y1=..; z1=..; X0=[x0;y0;z0]; X1=[x1;y1;z1]; E1=norm(X1-X0,inf); luego x2=double(subs(g1,[x y z],[x1 y1 z1])); y2=..; z2=..; X2=[x2;y2;z2]; E2=norm(X2-X1,inf) (X1,E1 como en sus otros metodos; NUNCA XX1 ni EE1). " ...
         "REGRESION: x=[...]'; y=[...]'; plot(x,y,'*'); ecuaciones normales con sumas (C=[numel(x) sum(x); sum(x) sum(x.^2)]; b=[sum(y); sum(x.*y)]; a=inv(C)*b), Q=sum((yh-y).^2), R2=1-Q/sum((y-mean(y)).^2), error estandar=sqrt(Q/(N-(m+1))); f=inline('a0+a1*x+a2*x^2','x'); hold on; ezplot(f). " ...
         "INTERPOLACION/LAGRANGE: x=[...]'; y=[...]'; plot(x,y,'*'); hold on; f1=inline('2/pi*x+1','x'); ezplot(f1); polinomios L0,L1,L2 y P(x)=y0*L0(x)+y1*L1(x)+... " ...
         "Si hay que modificar el orden de las ecuaciones o acondicionar el sistema (E.D.D., por ejemplo F2=F2+F3) para converger, hazlo primero a papel y explicalo en comentarios %. " ...
         "Funciones con inline('...','x') y feval/ezplot; error con norm(X1-X0,inf); format long si piden precision. " ...
         "Si el ejercicio impone una regla (decimales, formula, metodo, numero de iteraciones), cumplela tal cual y dilo en un comentario %. " ...
         "Cada linea se ejecuta tal cual, una por una, en Octave: debe ser un comando completo y valido. FORMATO: pon TODOS los comandos de Octave dentro de un bloque ```octave, UN comando por linea, sin prefijo (el programa se lo agrega); los comentarios empiezan con %. Fuera del bloque solo texto muy corto. " ...
         "PLANTILLAS (preferidas): si el ejercicio es de uno de estos tipos NO escribas celdas: en el bloque ```excel manda solo los datos del enunciado y el programa arma la hoja con la forma exacta de sus hojas de clase, sin errores. " ...
         "(1) interpolacion de Newton / diferencias divididas / 'polinomios interpolantes de Newton de grado ...': {\"plantilla\":\"newton\",\"x\":[2,2.2,2.4],\"y\":[0.51,0.52,0.51],\"xe\":2.1,\"grados\":[1,2]} (xe = valor a aproximar; grados = los grados pedidos, ademas del grado maximo que siempre se calcula). " ...
         "(2) regresion de una variable (recta y/o parabola): {\"plantilla\":\"regresion\",\"titulo\":\"texto corto\",\"labs\":[\"x\",\"y\"],\"x\":[...],\"y\":[...],\"par\":true,\"pred\":2.5,\"xl\":\"X\",\"swap\":false} (par=true agrega la parabola y la comparacion; pred opcional; swap=true agrega la recta de x sobre y). " ...
         "(3) regresion lineal multiple: {\"plantilla\":\"multiple\",\"titulo\":\"texto corto\",\"x1\":[...],\"x2\":[...],\"y\":[...]}. " ...
         "(4) punto fijo (tabla I | Xi | E): {\"plantilla\":\"puntofijo\",\"titulo\":\"texto corto\",\"g\":[\"(-8-y^2)/(x-10)\",\"(-8-x)/(x*y-10)\"],\"x0\":[0,0],\"tol\":1e-4,\"despeje\":[\"x = (-8-y^2)/(x-10)  de la ecuacion 1\"]} (g en las variables x,y,z; maxit solo si piden un numero fijo de iteraciones). " ...
         "(5) Jacobi o Gauss-Seidel con B y C ya calculados: {\"plantilla\":\"jacobi\",\"B\":[[0,0.5,-0.5],[-1,0,-1.6667],[-0.3333,-0.3333,0]],\"C\":[-0.5,1.3333,0],\"x0\":[0,0,0],\"tol\":1e-3,\"sistema\":[\"ecuaciones reordenadas para E.D.D.\"],\"despeje\":[\"x1 = (...)\",\"x2 = (...)\",\"x3 = (...)\"]} (\"sistema\" y \"despeje\" = lo que el estudiante hace EN PAPEL: ecuaciones reordenadas para que sea E.D.D. y el despeje de cada incognita; el programa los escribe como comentarios % antes de la tabla, sin inventar: ponlos solo si el ejercicio los necesita; para Gauss-Seidel usa \"gaussseidel\" y la B de Gauss-Seidel). " ...
         "(6) interpolacion de Lagrange (nodos dados, P(x) de varios grados, evaluar en uno o mas x): {\"plantilla\":\"lagrange\",\"titulo\":\"texto corto\",\"x\":[0,1,2],\"y\":[1,2.71828,7.38906],\"xe\":[0.25,0.75],\"grados\":[1,2]}. " ...
         "(6b) EJERCICIO DE INTERPOLACION CON VARIAS PARTES (a, b, c... o 4.2, 4.3, Ejercicio 1...): usa SIEMPRE esta plantilla, una hoja por ejercicio, solo con lo que el enunciado pide (sin columnas de error, valor exacto ni textos de 'me piden' si no los piden). {\"plantilla\":\"interpolacion\",\"titulo\":\"Ej 4.2\",\"x\":[0,0.5,1,1.5],\"y\":[1,1.6487,2.7183,4.4817],\"fexacta\":\"exp(x)\",\"partes\":[...]} con partes en el orden del enunciado y cada una asi: " ...
         "{\"tipo\":\"lagrange\",\"casos\":[{\"xe\":0.25,\"idx\":[1,2],\"rotulo\":\"P1\"},{\"xe\":0.25,\"idx\":[1,2,3],\"rotulo\":\"P2\"}]} (idx = posiciones 1..n de los nodos que usa ese polinomio; arma la tabla NODOS y las cajas L_i(x) como su hoja Ejemplo2, el valor de P en amarillo); " ...
         "{\"tipo\":\"newton\",\"xe\":0.25,\"grados\":[1,2]} (diferencias divididas como su hoja newthonRapshon; se muestra el grado maximo y los grados indicados); " ...
         "{\"tipo\":\"comparacion\",\"a\":[1,2],\"b\":[3,4],\"etiquetas\":[\"Lineal\",\"Cuadratica\"]} (SOLO si el enunciado pregunta cual aproximacion es mejor o pide el error: a y b son las posiciones, dentro de los casos de Lagrange, de las dos aproximaciones a comparar; usa fexacta); " ...
         "{\"tipo\":\"cota\",\"caso\":3,\"nodos\":4,\"derivada\":\"(32*x^5+160*x^3+120*x)*exp(x^2-1)\",\"xmax\":1.4} (SOLO si piden la cota teorica del error: caso = posicion del caso Lagrange con todos los nodos, nodos = cantidad de nodos, derivada = f^(n)(x) derivada por ti escrita en x con funciones de Excel, xmax = x donde se acota). " ...
         "En 'lagrange' toda parte tiene que venir antes de comparacion/cota. Los xe y y son numeros del enunciado; todo lo demas lo calcula el programa con formulas vivas. " ...
         "(7) EXAMEN con varios metodos iterativos de la misma pregunta (Newton y punto fijo con X0 dado, Jacobi, Gauss-Seidel): {\"plantilla\":\"examen\",\"metodos\":[{\"metodo\":\"newton\",\"titulo\":\"Metodo de Newton\",\"F\":[\"x^2+y^2-z\",\"x^2+y^2+z^2-2\",\"3*y+z-1\"],\"J\":[[\"2*x\",\"2*y\",\"-1\"],[\"2*x\",\"2*y\",\"2*z\"],[\"0\",\"3\",\"1\"]],\"x0\":[1,0,0],\"maxit\":2},{\"metodo\":\"puntofijo\",\"titulo\":\"Punto fijo\",\"g\":[\"(2-y^2-z^2)/x\",\"(1-z)/3\",\"x^2+y^2\"],\"x0\":[1,0,0],\"maxit\":2},{\"metodo\":\"jacobi\",\"titulo\":\"Metodo de Jacobi\",\"B\":[[0,0,-0.3333],[0.25,0,0.5],[0,0.5,0]],\"C\":[-0.6667,1.75,0],\"x0\":[0,0,0],\"maxit\":2}]} (una tabla I | Xi | Ei por metodo, lado a lado, en la forma de su hoja de examen; J son las derivadas parciales escritas por ti, una por celda, en x,y,z; usa maxit solo si el enunciado pide un numero de iteraciones). Una hoja por pregunta. " ...
         "Para cualquier otro tipo de ejercicio usa el formato general que sigue. " ...
         "FORMULAS EN EL FORMATO GENERAL: solo funciones de Excel en ingles (SUM, SUMPRODUCT, IF, ABS, SQRT, MAX, MIN, EXP, LN, SIN, COS, MMULT, MINVERSE...) y referencias de celda (B5, $C$3); NUNCA nombres propios como P(0.25), f(x), L_i, ni sintaxis de Octave: eso da #NAME? en Excel. Una comparacion con texto va asi: =IF(F34<G34,\"Lineal\",\"Cuadratica\"). SUMPRODUCT solo con rangos de la misma orientacion (dos columnas o dos filas); para mezclar fila y columna escribe la suma de productos (=C5*B11+C6*C11). Los valores de f(x) exactos, calculalos con funciones de Excel (=EXP(0.25)), no como texto. " ...
         "EXCEL: si el ejercicio tiene varias partes, o piden excel/hoja/evidencia, agrega al final UN bloque ```excel con JSON valido y nada mas: " ...
         "{\"archivo\":\"nombre_corto\",\"hojas\":[{\"nombre\":\"recta\",\"filas\":[[\"Titulo del ejercicio\"],[],[\"x\",\"y\"],[0,1],[0.5,1.64872]]}]}. " ...
         "REGLA DE COMPACTACION (siempre): hoja pequena y pegada como las de clase. NUNCA dejes una fila ni una columna vacia entre un subtitulo/rotulo y la tabla que va debajo (la tabla empieza en la fila siguiente); entre bloques distintos deja a lo mas UNA fila vacia; no pongas rotulos como NODOS (los nodos son solo la tabla x | y); todo texto en ASCII simple (x^2, e^(x^2-1), f^(5)(c)), sin letras griegas, superindices ni signo menos largo; ancho de columna normal. Los bordes son SOLO para las tablas de datos: los rotulos, subtitulos y lineas como L0(0.25)=, P(x)=, GRADO1 x= van sin borde (marca {n} al inicio del texto). " ...
         "TODO el ejercicio va en UNA sola hoja: pon cada parte (a, b, c...) como un elemento de \"hojas\" y el programa las apila una debajo de otra en una sola hoja (1 fila de separacion), moviendo las referencias de celda por ti. Escribe cada parte como si empezara en A1 de su propio bloque. Cada fila es una lista; un texto que empieza con = es una formula de Excel VIVA que usa referencias de celda de ESA parte (A1 es la primera celda; la fila 1 es la primera fila de filas; el programa deja margen: columna A y fila 1 vacias, como sus hojas). " ...
         "ESTILO como sus hojas de clase: un solo titulo por parte (primera fila, UN texto corto, sin repetirlo en el nombre de la parte); encabezados de tabla en negrita con {b} (ej. \"{b}x\"); los datos del enunciado en una tabla con bordes con {k} (ej. \"{k}Tiempo\"); las tablas de calculo SIN bordes (no pongas marca); cajitas pequenas (Q, Media de y, R^2) con {k}; respuestas finales en amarillo: {Y} sin borde o {K} con borde; {n} fuerza sin borde. " ...
         "ESTRUCTURA de regresion (la de su hoja tarea): tabla i | x | y | x^2 | x*y | P(x) | error^2 | (y-media)^2 con fila \"suma\"; matriz C y vector b armados con las sumas (=COUNT(...), =E12, ...); coeficientes con =INDEX(MMULT(MINVERSE(rangoC),rangob),k,1) (a0, a1, a2); Q =SUM(error^2); Media de y =AVERAGE(...); R^2 =(SUMPRODUCT((y-media)^2)-Q)/SUMPRODUCT((y-media)^2) (SIN celda SST); m y N+1 en celdas; Error estandar =SQRT(Q/(N+1-(m+1))) en amarillo; para varias variables, una columna por cada x1*x2, x1^2, x1*y... y los mismos bloques. Si piden recta y parabola, la parabola va en su propia parte y al final un bloque \"Comparacion\" (R2 de cada una, error estandar de cada una, \"Mas preciso\" con =IF(...) en amarillo, e \"Interpretacion\" como formula de texto). Al final un bloque \"Me piden:\" con cada inciso del enunciado (etiqueta a, b, c, d...) y su respuesta como formula que jala de la tabla. " ...
         "REGLA DE ORO: ninguna respuesta se escribe a mano como numero ni como texto con el valor: TODO resultado (sumas, medias, R^2, matrices inversas, coeficientes, P(x), errores, intervalos, tablas de iteraciones) es una formula que JALA los datos de las celdas de la tabla (AVERAGE, SUM, SUMPRODUCT, MMULT, MINVERSE, referencias). Solo son numeros fijos los DATOS del enunciado. Las interpretaciones/conclusiones pueden ser formulas de texto, ej. =\"El modelo explica el \"&TEXT(B20*100,\"0.00\")&\"% de la variabilidad\". Lee bien lo que pide cada inciso (ej. \"intervalo de longitud dos errores estandar centrado en la estimacion\" es estimado +/- 1 error estandar). " ...
         "CAPTURAS: lo hecho a mano NO se inventa ni se simula: imagenes de formulas, graficos de Octave y capturas de la consola los pega el estudiante. SOLO si el enunciado pide grafico, diagrama de dispersion o que se muestre lo hecho en Octave, deja un espacio para pegarlo: una fila de titulo en negrita (ej. \"{b}Captura del diagrama de dispersion (pegar aqui)\") seguida de 20 filas vacias ([]) dentro de esa misma parte, para que lo que siga no quede tapado. Si no lo piden, no dejes espacio ni notas. Si trae su propio libro, nada de lo suyo se toca: tu hoja es nueva. " ...
         "funciones en ingles (EXP, SQRT, SIN, ABS, SUMPRODUCT, MMULT, MINVERSE). " ...
         "Interpolacion/Lagrange: nodos x|y, una columna por cada L_i(x) como formula del tipo =($E$4-A6)/(A5-A6) y P(x)=SUMPRODUCT(y,L). Newton por diferencias divididas (SOLO Excel, no hay Octave de clase): como su hoja newthonRapshon, en este orden: fila de encabezados Diferencias | Diferencias 1..n-1 (con borde); columnas A=xk, B=f[xk]= (etiquetas f[x0], f[x1]...), C=f(xk) (datos con borde); luego, por cada orden j, una columna de etiquetas f[xk,...,xk+j] y a su derecha la columna de valores como formulas escalonadas: la primera diferencia en la fila de x0 es =(C9-C8)/(A9-A8), la segunda =(E9-E8)/(A10-A8), la tercera =(G9-G8)/(A11-A8)...; abajo: a) x= (dato), el polinomio con todos los coeficientes (grado n-1) escrito como texto P(x)=f[x0]+f[x0,x1](x-x0)+..., y luego P(x)= como formula amarilla con el valor para grado n-1 y para cada grado pedido (los nodos mas cercanos a x, empezando en la fila de su primer nodo), con la etiqueta gradoK a la derecha. " ...
         "Nunca pongas valores calculados a mano donde se pueda poner la formula. Evita TRANSPOSE y formulas matriciales: SUMPRODUCT solo con rangos del mismo tamano y orientacion."];
  % atajo: pide un ejemplo resuelto de un metodo -> se resuelve con los pasos de clase, sin llamar a la IA
  q = lower (pregunta);
  if ! isempty (regexp (q, "ejemplo")) && isempty (imgs)   % solo si pides explicitamente el EJEMPLO
    if ! isempty (regexp (q, "seidel|gauss.?sei")), hm_gaussseidel ("ejemplo"); return; endif
    if ! isempty (strfind (q, "jacobi")), hm_jacobi ("ejemplo"); return; endif
    if ! isempty (strfind (q, "newton")), hm_newton ("ejemplo"); return; endif
    if ! isempty (regexp (q, "punto.?fijo")), hm_puntofijo2 ("ejemplo"); return; endif
  endif
  ko = getenv ("OPENAI_API_KEY"); ka = getenv ("ANTHROPIC_API_KEY");
  modelo = getenv ("OCT_IA_MODEL"); url = getenv ("OCT_IA_URL");
  forz = lower (getenv ("OCT_IA_PROVIDER"));
  if ! any (strcmp(forz,{"","codex","openai","anthropic"})), error("octavei: proveedor desconocido"); endif
  if strcmp(forz,"openai") && isempty(ko), error("octavei: falta OPENAI_API_KEY"); endif
  if strcmp(forz,"anthropic") && isempty(ka), error("octavei: falta ANTHROPIC_API_KEY"); endif
  if strcmp (forz, "codex") || (isempty (forz) && isempty (ka) && isempty (ko) && tiene_codex ())
    printf ("  ...\n"); fflush (stdout);
    r0 = ia_codex ([sis "\n\nPregunta: " pregunta], modelo, imgs);
    if plan, armar_plan (r0, libro, destino_pdf); else, mostrar (r0, libro); endif
    if nargout, r = r0; endif
    return
  endif
  if strcmp(forz,"anthropic") || (isempty(forz) && ! isempty(ka))
    prov = "anthropic"; if isempty (modelo), modelo = "claude-sonnet-4-5"; endif
    if isempty (url), url = "https://api.anthropic.com/v1/messages"; endif
    cab = {["x-api-key: " ka], "anthropic-version: 2023-06-01"};
    body = struct ("model", modelo, "max_tokens", 8192, "system", sis, ...
                   "messages", {{struct("role", "user", "content", {cont_anthropic(pregunta, imgs)})}});
    piensa = ! strcmp (getenv ("OCT_IA_THINK"), "0");   % razonamiento extendido: analiza el enunciado antes de llenar la plantilla
    if piensa, body.thinking = struct ("type", "enabled", "budget_tokens", 6000); body.max_tokens = 16000; endif
  elseif strcmp(forz,"openai") || (isempty(forz) && ! isempty(ko))
    prov = "openai"; if isempty (modelo), modelo = "gpt-4o-mini"; endif
    if isempty (url), url = "https://api.openai.com/v1/chat/completions"; endif
    cab = {["Authorization: Bearer " ko]};
    body = struct ("model", modelo, "messages", {{struct("role", "system", "content", sis), ...
                                                 struct("role", "user", "content", {cont_openai(pregunta, imgs)})}});
  else
    error ("octavei: sin clave ni codex. Opcion A: instala codex y haz  codex login.  Opcion B (cmd):  setx OPENAI_API_KEY \"sk-...\"  y reinicia Octave");
  endif
  carpeta = tempname(); [ok,msg] = mkdir(carpeta);
  if ! ok, error("octavei: no pude crear carpeta temporal: %s",msg); endif
  limpieza = onCleanup(@() limpiar_temporal(carpeta));
  fb = fullfile(carpeta,"peticion.json"); fr = fullfile(carpeta,"respuesta.json"); fc = fullfile(carpeta,"curl.conf");
  intento = 0;
  do
  intento++; reintentar = false;
  escribir(fb,jsonencode(body));
  cfg = sprintf('url = "%s"\nrequest = "POST"\nsilent\nshow-error\nmax-time = 280\nheader = "Content-Type: application/json"\n',curl_esc(url));
  for i=1:numel(cab), cfg=[cfg sprintf('header = "%s"\n',curl_esc(cab{i}))]; endfor
  cfg=[cfg sprintf('data-binary = "@%s"\noutput = "%s"\nwrite-out = "%%{http_code}"\n',curl_esc(fb),curl_esc(fr))];
  escribir(fc,cfg);
  [st,codigo] = system(["curl --config " hm_shellquote(fc)]);
  if st != 0 || ! exist(fr,"file"), error("octavei: curl fallo (codigo %d)",st); endif
  txt = fileread(fr);
  http = str2double(strtrim(codigo));
  if (! isfinite(http) || http < 200 || http >= 300) && strcmp (prov, "anthropic") && isfield (body, "thinking") && http == 400 && intento == 1
    body = rmfield (body, "thinking"); body.max_tokens = 8192; reintentar = true; continue;   % el modelo no admite razonamiento extendido: reintenta sin el
  endif
  if ! isfinite(http) || http < 200 || http >= 300, error("octavei: respuesta HTTP %s %s",strtrim(codigo), txt(1:min (end, 300))); endif
  until ! reintentar
  j = jsondecode (txt);
  if isfield (j, "error")
    e = j.error; if isstruct (e) && isfield (e, "message"), e = e.message; endif
    error ("octavei: %s", e);
  endif
  if strcmp (prov, "anthropic")
    B = j.content; if ! iscell (B), B = num2cell (B); endif
    t = ""; for b = 1:numel (B), if isfield (B{b}, "text") && ! isempty (B{b}.text), t = [t B{b}.text]; endif, endfor
    if isempty (t), error ("octavei: la API no devolvio texto"); endif
  else
    t = j.choices(1).message.content;
  endif
  if plan, armar_plan (t, libro, destino_pdf); else, mostrar (t, libro); endif
  if nargout, r = t; endif
endfunction

function armar_plan (t, libro, destino)
  % separa la respuesta en ejercicios (@@EJ n | octave|excel | titulo) y los guarda para  ss1, ss2, ...
  L = strsplit (t, "\n"); P = {}; cur = [];
  for i = 1:numel (L)
    tk = regexp (L{i}, '^\s*@@EJ\s*(\d+)\s*\|\s*(\w+)\s*\|\s*(.*)$', "tokens", "once");
    if ! isempty (tk)
      if ! isempty (cur), P{end+1} = titular (cur); endif
      cur = struct ("n", numel (P) + 1, "tipo", lower (tk{2}), "titulo", strtrim (tk{3}), "texto", "", "libro", libro, "acum", []);
    elseif ! isempty (cur)
      cur.texto = [cur.texto L{i} "\n"];
    endif
  endfor
  if ! isempty (cur), P{end+1} = titular (cur); endif
  if isempty (P)
    printf ("\n  (no pude separar los ejercicios del PDF; se muestra todo junto)\n"); mostrar (t, libro); return
  endif
  for i = 1:numel (P), P{i}.acum = struct ("archivo", fullfile (pwd (), destino), "n", P{i}.n, "titulo", P{i}.titulo); endfor
  setappdata (0, "oi_hojas", {});
  setappdata (0, "oi_plan", P);
  printf ("\n");
  for i = 1:numel (P)
    printf ("  ss%d   %s%s\n", i, P{i}.titulo, merge (strcmp (P{i}.tipo, "excel"), "   [solo Excel]", ""));
  endfor
  printf ("\n");
endfunction

function e = titular (e)
  % si la IA dejo el titulo vacio, usa la primera linea de texto o "Ejercicio n"
  e.titulo = strtrim (regexprep (e.titulo, '[\*`#]', ""));
  if isempty (e.titulo)
    L = strsplit (e.texto, "\n");
    dentro = false;
    for i = 1:numel (L)
      l = strtrim (L{i});
      if strncmp (l, "```", 3), dentro = ! dentro; continue; endif
      if ! dentro && ! isempty (l), e.titulo = l(1:min (end, 60)); break; endif
    endfor
  endif
  if isempty (e.titulo), e.titulo = sprintf ("Ejercicio %d", e.n); endif
endfunction

function start_ejercicio (e)
  if strcmp (e.tipo, "excel")
    setappdata (0, "oi_ultimo", struct ("tipo", "ia", "texto", e.texto, "libro", e.libro, "acum", e.acum));
    exportar ();
  else
    if isempty (regexp (e.texto, '```octave\s*\n')), error ("ss: ese ejercicio no trae codigo de Octave (usa  ss %d e  para solo Excel)", e.n); endif
    mostrar (e.texto, e.libro, true, e.acum);
  endif
endfunction

function ok = tiene_codex ()
  [st, ~] = system ("codex --version");
  ok = (st == 0);
endfunction

function t = ia_codex (prompt, modelo, imgs)
  carpeta=tempname(); [ok,msg]=mkdir(carpeta);
  if ! ok, error("octavei: no pude crear carpeta temporal: %s",msg); endif
  limpieza=onCleanup(@() limpiar_temporal(carpeta));
  fp=fullfile(carpeta,"prompt.txt"); fo=fullfile(carpeta,"salida.txt");
  escribir(fp,prompt);
  c="codex exec --skip-git-repo-check --sandbox read-only";
  for i=1:numel(imgs), c=[c " -i " hm_shellquote(imgs{i})]; endfor
  if ! isempty(modelo), c=[c " -m " hm_shellquote(modelo)]; endif
  c=[c " -o " hm_shellquote(fo) " - < " hm_shellquote(fp) " 2>&1"];
  % NO se usa cd de Octave (el explorador de archivos de la GUI saltaria a la carpeta temporal): el cd va dentro del comando
  if ispc (), c=["cd /d " hm_shellquote(carpeta) " && " c]; else, c=["cd " hm_shellquote(carpeta) " && " c]; endif
  [st,out]=system(c);
  if st != 0, error("octavei: codex fallo (codigo %d): %s",st,strtrim(out(max(1,end-600):end))); endif
  if ! exist(fo,"file"), error("octavei: codex termino sin crear el archivo de salida (-o)"); endif
  t=strtrim(fileread(fo));
  if isempty(t), error("octavei: codex genero una respuesta vacia"); endif
endfunction

function escribir (archivo, texto)
  fid=fopen(archivo,"w","n","UTF-8");
  if fid<0, error("octavei: no pude escribir %s",archivo); endif
  cierre=onCleanup(@() fclose(fid));
  fputs(fid,texto);
  if ferror(fid), error("octavei: fallo al escribir %s",archivo); endif
endfunction

function s = curl_esc (s)
  s=strrep(s,char(92),[char(92) char(92)]);
  s=strrep(s,char(34),[char(92) char(34)]);
  s=strrep(s,char(10),[char(92) "n"]);
  s=strrep(s,char(13),[char(92) "r"]);
endfunction

function limpiar_temporal (carpeta)
  if exist(carpeta,"dir"), vc = confirm_recursive_rmdir (false); rmdir(carpeta,"s"); confirm_recursive_rmdir (vc); endif
endfunction

function c = cont_openai (txt, imgs)
  if isempty (imgs), c = txt; return; endif
  c = {struct("type", "text", "text", txt)};
  for i = 1:numel (imgs), c{end+1} = struct ("type", "image_url", "image_url", struct ("url", ["data:" mime(imgs{i}) ";base64," b64(imgs{i})])); endfor
endfunction

function c = cont_anthropic (txt, imgs)
  if isempty (imgs), c = txt; return; endif
  c = {};
  for i = 1:numel (imgs), c{end+1} = struct ("type", "image", "source", struct ("type", "base64", "media_type", mime(imgs{i}), "data", b64(imgs{i}))); endfor
  c{end+1} = struct ("type", "text", "text", txt);
endfunction

function m = mime (f)
  e = lower (f(find (f == ".", 1, "last")+1:end));
  m = ["image/" merge(strcmp(e,"jpg"), "jpeg", e)];
endfunction

function s = b64 (f)
  fid = fopen (f, "rb"); d = fread (fid, Inf, "uint8=>uint8"); fclose (fid);
  s = strrep (base64_encode (d(:)'), "\n", "");
endfunction

function o = con_prompt (t)
  % pone "octave:N>" (o ">>") delante de cada linea de codigo, como en tus diarios.
  % Cambiar:  setenv("OCT_IA_PROMPT",">>")  (version vieja)   |   setenv("OCT_IA_PROMPT","octave")  y  setenv("OCT_IA_N","8")  (numero inicial)
  est = getenv ("OCT_IA_PROMPT"); if isempty (est), est = "octave"; endif
  n = str2double (getenv ("OCT_IA_N")); if isnan (n), n = 1; endif
  L = strsplit (t, "\n"); dentro = false; o = {};
  for i = 1:numel (L)
    l = L{i};
    if strncmp (strtrim (l), "```", 3), dentro = ! dentro; continue; endif
    if dentro && ! isempty (strtrim (l))
      if strcmp (est, ">>"), o{end+1} = [">> " l];
      else, o{end+1} = sprintf ("octave:%d> %s", n, l); n++; endif
    else
      o{end+1} = l;
    endif
  endfor
  if ! strcmp (est, ">>"), setenv ("OCT_IA_N", num2str (n)); endif
  o = strjoin (o, "\n");
endfunction


function catalogo (e)
  printf ("\n");
  setappdata (0, "oi_ultimo", struct ("tipo", "catalogo", "id", e.id));
  if hm_teclear (e.lineas, hm_prompt_n ()) && ! isempty (e.excel), exportar (); endif
endfunction

function mostrar (t, libro, quiet, acum)
  if nargin < 3, quiet = false; endif
  if nargin < 4, acum = []; endif
  % guarda el bloque excel (para "exportar"), y escribe el codigo con teclas
  excel = ! isempty (regexp (t, '```excel\s*\n'));
  setappdata (0, "oi_ultimo", struct ("tipo", "ia", "texto", merge (excel, t, ""), "libro", libro, "acum", acum));
  t = strtrim (regexprep (t, '```excel\s*\n[\s\S]*?```', ""));
  L = strsplit (t, "\n"); dentro = false; cod = {}; txt = {};
  for i = 1:numel (L)
    l = L{i};
    if strncmp (strtrim (l), "```", 3), dentro = ! dentro; continue; endif
    if dentro, if ! isempty (strtrim (l)), cod{end+1} = l; endif
    else, txt{end+1} = l; endif
  endfor
  if strcmpi (getenv ("OCT_IA_TECLAS"), "texto") || isempty (cod)
    printf ("\n%s\n\n", con_prompt (t));
  else
    tx = strtrim (strjoin (txt, "\n"));
    if ! quiet
      if ! isempty (tx), printf ("\n%s\n", tx); endif
      printf ("\n  Presiona cualquier tecla para ir escribiendo (Esc sale).\n\n");
    else
      printf ("\n");
    endif
    completo = hm_teclear (cod, hm_prompt_n ());
    if ! completo, return; endif
  endif
  if excel, exportar (); endif
endfunction
