% h  -  menu paso a paso de metodos (Unidad 2).   h  o  h("jacobi")
% Tip: donde pida una matriz o vector puedes escribir  excel archivo.xlsx B4:D9  (o .ods / .csv)
function h (clave)
  g_ = hm_silenciar ();            % sin avisos de Octave mientras corre
  hm_ocultar ();                   % el comando escrito no queda en el historial
  m = {"hm_gaussjordan",  "Gauss-Jordan (filas)", "gaussjordan";
       "hm_inversa",      "Metodo directo: matriz inversa", "inversa";
       "hm_lu",           "Factorizacion LU", "lu";
       "hm_cholesky",     "Cholesky", "cholesky";
       "hm_normas",       "Normas, radio espectral, condicion", "normas";
       "hm_reordenar",    "Reordenar ecuaciones para converger", "reordenar";
       "hm_jacobi",       "Jacobi", "jacobi";
       "hm_gaussseidel",  "Gauss-Seidel", "gaussseidel";
       "hm_directos",     "Directos: Cramer, eliminacion gaussiana, progresiva/regresiva", "directos";
       "hm_puntofijo2",   "Punto fijo (sistema no lineal)", "puntofijo";
       "hm_newton",       "Newton-Raphson (sistema no lineal)", "newton";
       "hm_regresion",    "Regresion (ecuaciones normales: polinomial / multiple)", "regresion";
       "hm_ajuste",       "Ajuste rapido con polyfit", "ajuste";
       "hm_interpola",    "Interpolacion (Lagrange, Newton, polyfit)", "interpola";
       "octavei",         "octavei: ejercicios con teclas / preguntar a la IA", ""};
  if nargin == 0
    for i = 1:rows (m), printf ("  %2d) %s\n", i, m{i,2}); endfor
    s = strtrim (hm_entrada ("  opcion: ", "s"));
    k = str2double (s);
  else
    k = NaN; c = lower (clave);
    for i = 1:rows (m)
      if ~ isempty (strfind (lower (m{i,1}), c)) || ~ isempty (strfind (lower (m{i,2}), c)), k = i; break; endif
    endfor
  endif
  if isnan (k) || k < 1 || k > rows (m), disp ("  (no existe)"); return; endif
  f = m{k,1};
  if ~ strcmp (f, "octavei")
    printf ("\n--- %s ---\n", m{k,2});
    if exist (f, "file") == 2, chuleta (which (f)); endif
    r = lower (strtrim (hm_entrada ("\nEnter = te pido los datos y lo escribo con tus teclas (como octavei, sin IA)   g = modo guiado (todo de golpe)   n = solo la chuleta: ", "s")));
    if strcmp (r, "n"), return; endif
    if ~ strcmp (r, "g"), hm_h_teclas (m{k,3}); return; endif
  endif
  feval (f);
endfunction

function chuleta (ruta)
  l = strsplit (fileread (ruta), "\n");
  for i = 1:numel (l)
    if strncmp (l{i}, "%", 1), disp (regexprep (l{i}, '^% ?', '  ')); elseif i > 1, break; endif
  endfor
endfunction
