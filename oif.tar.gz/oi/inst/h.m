% h  -  menu paso a paso de metodos (Unidad 2).   h  o  h("jacobi")
% Tip: donde pida una matriz o vector puedes escribir  excel archivo.xlsx B4:D9  (o .ods / .csv)
function h (clave)
  m = {"hm_gaussjordan",  "Gauss-Jordan (filas)";
       "hm_inversa",      "Metodo directo: matriz inversa";
       "hm_lu",           "Factorizacion LU";
       "hm_cholesky",     "Cholesky";
       "hm_normas",       "Normas, radio espectral, condicion";
       "hm_reordenar",    "Reordenar ecuaciones para converger";
       "hm_jacobi",       "Jacobi";
       "hm_gaussseidel",  "Gauss-Seidel";
       "hm_directos",     "Directos: Cramer, eliminacion gaussiana, progresiva/regresiva";
       "hm_puntofijo2",   "Punto fijo (sistema no lineal)";
       "hm_newton",       "Newton-Raphson (sistema no lineal)";
       "hm_regresion",    "Regresion (ecuaciones normales: polinomial / multiple)";
       "hm_ajuste",       "Ajuste rapido con polyfit";
       "hm_interpola",    "Interpolacion";
       "octavei",         "octavei: ejercicios con teclas / preguntar a la IA"};
  if nargin == 0
    for i = 1:rows (m), printf ("  %2d) %s\n", i, m{i,2}); endfor
    s = strtrim (hm_entrada ("  opcion: ", "s"));
    k = str2double (s);
  else
    k = NaN; c = lower (clave);
    for i = 1:rows (m)
      if ! isempty (strfind (lower (m{i,1}), c)) || ! isempty (strfind (lower (m{i,2}), c)), k = i; break; endif
    endfor
  endif
  if isnan (k) || k < 1 || k > rows (m), disp ("  (no existe)"); return; endif
  f = m{k,1};
  if ! strcmp (f, "octavei")
    printf ("\n--- %s ---\n", m{k,2});
    if exist (f, "file") == 2, chuleta (which (f)); endif
    r = hm_entrada ("\nEnter = modo guiado, n = solo la chuleta: ", "s");
    if strcmpi (strtrim (r), "n"), return; endif
  endif
  feval (f);
endfunction

function chuleta (ruta)
  l = strsplit (fileread (ruta), "\n");
  for i = 1:numel (l)
    if strncmp (l{i}, "%", 1), disp (regexprep (l{i}, '^% ?', '  ')); elseif i > 1, break; endif
  endfor
endfunction
