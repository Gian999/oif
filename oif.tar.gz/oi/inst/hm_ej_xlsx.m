% hm_ej_xlsx (archivo, d)  -  arma el Excel de un ejercicio de regresion con FORMULAS VIVAS, con la forma de las hojas de clase
% (tabla, matriz C, vector b, coeficientes con INDEX(MMULT(MINVERSE(...))), Q, media, R^2, error estandar).
% Solo los datos del enunciado son numeros fijos; todo lo demas se calcula en la propia hoja (sirve aunque no uses Octave).
%   d.titulo  texto del ejercicio       d.x, d.y  datos (recta/parabola)     d.x1, d.x2, d.y  datos (regresion multiple)
%   d.labs    {"x","y"} nombres          d.par     true: agrega la parabola y la comparacion
%   d.pred    valor de x a estimar       d.xl      nombre de x en "Si X ="     d.swap  true: segunda recta intercambiando x e y
%   d.resp    numero de ejercicio del catalogo (0 = sin bloque "Me piden")
function [C, info] = hm_ej_xlsx (archivo, d)
  g_ = hm_silenciar ();
  info = struct ();
  % usos internos (los llama hm_octave_plantilla): datos normalizados de un metodo / revision de puntos solucion
  if ischar (archivo) && strcmp (archivo, "@norm"), C = normaliza (d); return; endif
  if ischar (archivo) && strcmp (archivo, "@pf"), C = nota_pf (d.s, d.Fref); return; endif
  if ischar (archivo) && strcmp (archivo, "@verif")
    Fs = cellstr (d.F)(:)'; P = d.puntos; if iscell (P), P = cell2mat (cellfun (@(v) v(:)', P(:), "UniformOutput", false)); endif
    if columns (P) == 1 && rows (P) > 1, P = P'; endif
    vv = {"x", "y", "z"}(1:min (columns (P), 3)); if isfield (d, "vars"), vv = cellstr (d.vars)(:)'; endif
    [C, info.Pc] = revisar_puntos (Fs, vv, P); return
  endif
  if isfield (d, "interp"), C = interp (d);
  elseif isfield (d, "examen"), C = examen (d);
  elseif isfield (d, "lagrange"), [C, info] = lagrange (d);
  elseif isfield (d, "iter")
    s_ = normaliza (d);
    if strcmp (s_.iter, "puntofijo") && isfield (s_, "F"), s_ = nota_pf (s_, cellstr (s_.F)(:)'); endif
    C = iterativa (s_);
  elseif isfield (d, "newton"), [C, info] = newton (d);
  elseif isfield (d, "x1"), C = multiple (d); else, C = lineal (d); endif
  if ~ isempty (archivo), hm_xlsx (archivo, {C}, {"Ejercicio"}); endif
endfunction

% Ejercicio de interpolacion con varias partes (a, b, c...) en UNA hoja, con la forma de tus hojas y solo lo que pide el enunciado:
%   d.interp true   d.x, d.y nodos   d.fexacta (opcional, ej. "exp(x)": solo para comparar errores)
%   d.partes = lista de partes, cada una con tipo y nombre:
%     tipo "lagrange":    casos = lista de (xe, idx = nodos 1-based, rotulo opcional)
%     tipo "newton":      xe, grados (ademas del maximo)
%     tipo "comparacion": a = casos de la primera aproximacion, b = los de la segunda, etiquetas {"Lineal","Cuadratica"}  (necesita fexacta)
%     tipo "cota":        caso (el de Lagrange con todos los nodos), derivada (f^(n)(x) como texto Excel, ej. "(32*x^5+160*x^3+120*x)*exp(x^2-1)"), xmax (x donde es maxima en el intervalo), texto (opcional)
function C = interp (d)
  P = d.partes; if isstruct (P), P = num2cell (P); endif
  x = d.x(:)'; y = d.y(:)'; Cs = {}; nm = {}; lag = struct ("nom", "", "info", []);
  for k = 1:numel (P)
    p = P{k}; tipo = lower (p.tipo);
    nom = sprintf ("%c)", 96 + k); if isfield (p, "nombre") && ~ isempty (p.nombre), nom = p.nombre; endif
    switch tipo
      case "lagrange"
        K = p.casos; if isstruct (K), K = num2cell (K); endif
        for q = 1:numel (K)
          if ~ isfield (K{q}, "rotulo"), K{q}.rotulo = ""; endif
          K{q}.idx = K{q}.idx(:)';
        endfor
        dl = struct ("x", x, "y", y, "casos", {K}); if isfield (d, "labs"), dl.labs = d.labs; endif
        [Ck, inf] = lagrange (dl); lag.nom = nom; lag.info = inf;
      case "newton"
        g = []; if isfield (p, "grados"), g = p.grados(:)'; endif
        Ck = newton (struct ("x", x, "y", y, "xe", p.xe, "grados", g, "rotulo", ""));
      case "comparacion"
        if ~ isfield (d, "fexacta"), error ("hm_ej_xlsx: comparacion necesita fexacta"); endif
        ia = p.a(:)'; ib = p.b(:)'; et = {"Aproximacion 1", "Aproximacion 2"}; if isfield (p, "etiquetas"), et = cellstr (p.etiquetas); endif
        Ck = cell (4 + numel (ia), 8); Ck{1,1} = "";
        h = {"x", et{1}, et{2}, "Valor exacto", ["Error " lower(et{1})], ["Error " lower(et{2})]}; for j = 1:6, Ck{2,1+j} = h{j}; endfor
        for m = 1:numel (ia)
          r = 2 + m;
          Ck{r,2} = ref (lag, lag.info.X(ia(m),:)); Ck{r,3} = ref (lag, lag.info.P(ia(m),:)); Ck{r,4} = ref (lag, lag.info.P(ib(m),:));
          Ck{r,5} = strcat ("=", sustx (d.fexacta, sprintf("B%d", r))); Ck{r,6} = sprintf ("=ABS(E%d-C%d)", r, r); Ck{r,7} = sprintf ("=ABS(E%d-D%d)", r, r);
        endfor
        r1 = 3; r2 = 2 + numel (ia);
        Ck{r2+2,2} = struct ("v", sprintf ("=IF(SUMPRODUCT(--(F%d:F%d<G%d:G%d))=%d,\"Mejor: %s (menor error absoluto)\",IF(SUMPRODUCT(--(G%d:G%d<F%d:F%d))=%d,\"Mejor: %s (menor error absoluto)\",\"Depende del punto\"))", ...
                  r1, r2, r1, r2, numel (ia), et{1}, r1, r2, r1, r2, numel (ia), et{2}), "s", 3);
      case "cota"
        n = numel (lag.info.P(:,1)); cs = p.caso; kk = lag.info; ncas = p.caso;
        idxn = numel (x); if isfield (p, "nodos"), idxn = p.nodos; endif
        Ck = cell (10, 4);
        xs = ""; for m = 0:idxn-1, xs = [xs sprintf("(x-x%d)", m)]; endfor
        tx = sprintf ("E(x)=f^(%d)(c)/%d! %s", idxn, idxn, xs); if isfield (p, "texto") && ~ isempty (p.texto), tx = p.texto; endif
        if isempty (regexp (tx, '^\s*%')), tx = ["% " tx]; endif
        Ck{1,1} = "Cota teorica del error"; Ck{2,1} = tx;
        Ck{4,1} = struct ("v", "x=", "s", 0); Ck{4,2} = struct ("v", p.xmax, "s", 0);
        Ck{5,1} = struct ("v", sprintf ("M=f^(%d)(%g)", idxn, p.xmax), "s", 0); Ck{5,2} = struct ("v", strcat ("=", sustx (p.derivada, "B4")), "s", 0);
        pr = ""; for m = 0:idxn-1, pr = [pr sprintf("*('%s'!$%s$%d-'%s'!A%d)", lag.nom, hm_col_excel (lag.info.X(ncas,2)), lag.info.X(ncas,1), lag.nom, lag.info.N0 + m)]; endfor
        Ck{6,1} = struct ("v", "|(x-x0)...(x-xn)|", "s", 0); Ck{6,2} = struct ("v", ["=ABS(" pr(2:end) ")"], "s", 0);
        Ck{7,1} = struct ("v", "Cota del error", "s", 0); Ck{7,2} = struct ("v", sprintf ("=B5/FACT(%d)*B6", idxn), "s", 3);
      otherwise
        error ("hm_ej_xlsx: parte desconocida: %s", p.tipo);
    endswitch
    Cs{end+1} = Ck; nm{end+1} = nom;
  endfor
  C = hm_apilar (Cs, nm);
endfunction

function s = sustx (f, r)
  s = regexprep (f, '\<x\>', r);
endfunction

function s = ref (lag, p)
  s = sprintf ("='%s'!%s%d", lag.nom, hm_col_excel (p(2)), p(1));
endfunction

% Lagrange con la forma de tu hoja Ejemplo2 (clase.xlsx): tabla NODOS (A14) y, a la derecha, una cajita por caso:
%   "GRADOn | x= | valor", nodos x0 y0 ..., P(x)=y0L0(x)+..., L0(x)=(x-x1)/(x0-x1) con su valor, y P(valor)= (amarillo).
%   Las cajitas van de dos en dos (columnas E y L), hacia abajo.   Todo con formulas vivas; solo los datos del enunciado son numeros.
%   d.lagrange true   d.x, d.y nodos
%   d.xe puntos y d.grados (nodos mas cercanos)   --o--   d.casos = lista de struct (xe, idx = nodos 1-based, rotulo opcional)
%   info.P = [fila col] de cada P(valor), info.X = [fila col] de cada x evaluado
function [C, info] = lagrange (d)
  n = numel (d.x);
  vx = "x"; vy = "y"; if isfield (d, "labs") && numel (d.labs) >= 2, vx = d.labs{1}; vy = d.labs{2}; endif
  if isfield (d, "casos")
    K = d.casos; if isstruct (K), K = num2cell (K); endif
  else
    gr = d.grados(:)'; if isempty (gr), gr = n-1; endif
    K = {};
    for xe = d.xe(:)'
      for g = gr
        best = Inf; s0 = 0;
        for s = 0:n-1-g, c_ = sum (abs (d.x(s+1:s+g+1) - xe)); if c_ < best, best = c_; s0 = s; endif, endfor
        K{end+1} = struct ("xe", xe, "idx", s0+1:s0+g+1);
      endfor
    endfor
  endif
  C = cell (1, 1);
  C = put (C, 1, 1, vx, 1); C = put (C, 1, 2, vy, 1);
  for i = 1:n, C = put (C, 1+i, 1, d.x(i), 1); C = put (C, 1+i, 2, d.y(i), 1); endfor
  info = struct ("P", zeros (numel (K), 2), "X", zeros (numel (K), 2), "N0", 2);
  r = 1; alto = 0;
  for q = 1:numel (K)
    xe = K{q}.xe; idx = K{q}.idx(:)'; g = numel (idx) - 1;
    c = 4 + 6 * mod (q-1, 2);
    if mod (q-1, 2) == 0 && q > 1, r = r + (alto + 1); alto = 0; endif
    rot = sprintf ("GRADO%d", g); if isfield (K{q}, "rotulo") && ~ isempty (K{q}.rotulo), rot = K{q}.rotulo; endif
    C = pn (C, r, c, rot); C = pn (C, r, c+1, [vx "="]); C = pn (C, r, c+2, xe);
    xr = sprintf ("$%s$%d", L (c+2), r); info.X(q,:) = [r c+2];
    for i = 0:g
      C = put (C, r+1+i, c, sprintf ("%s%d", vx, i), 1); C = put (C, r+1+i, c+1, sprintf ("=A%d", 1+idx(i+1)), 1);
      C = put (C, r+1+i, c+2, sprintf ("%s%d", vy, i), 1); C = put (C, r+1+i, c+3, sprintf ("=B%d", 1+idx(i+1)), 1);
    endfor
    pt = strjoin (arrayfun (@(i) sprintf ("%s%dL%d(%s)", vy, i, i, vx), 0:g, "UniformOutput", false), "+");
    base = g + 3;
    C = put (C, r+base, c, sprintf ("P%d(%s)=%s", g, vx, pt), 0);
    terms = cell (1, g+1);
    for i = 0:g
      nu = ""; de = ""; nr = ""; dr = "";
      for m = 0:g
        if m == i, continue; endif
        nu = [nu sprintf("(%s-%s%d)", vx, vx, m)]; de = [de sprintf("(%s%d-%s%d)", vx, i, vx, m)];
        nr = [nr sprintf("*(%s-%s%d)", xr, L (c+1), r+1+m)]; dr = [dr sprintf("*(%s%d-%s%d)", L (c+1), r+1+i, L (c+1), r+1+m)];
      endfor
      C = put (C, r+base+2+3*i, c, sprintf ("L%d(%s)=%s/%s", i, vx, nu, de), 0);
      C = pn (C, r+base+3+3*i, c, sprintf ("L%d(%g)=", i, xe));
      C = pn (C, r+base+3+3*i, c+1, sprintf ("=(%s)/(%s)", nr(2:end), dr(2:end)));
      terms{i+1} = sprintf ("%s%d*%s%d", L (c+3), r+1+i, L (c+1), r+base+3+3*i);
    endfor
    rp = r + base + 2 + 3*(g+1);
    C = pn (C, rp, c, sprintf ("P%d(%g)=", g, xe)); C = put (C, rp, c+1, ["=" strjoin(terms, "+")], 3);
    info.P(q,:) = [rp c+1];
    alto = max (alto, rp - r + 1);
  endfor
endfunction

% Metodos iterativos con tabla  I | Xi | E  (formato de tus hojas, formulas vivas):
%   d.iter = "puntofijo": d.g (cellstr g1,g2[,g3] en x,y[,z])
%   d.iter = "matricial" (Jacobi / Gauss-Seidel): d.B, d.Cv
%   d.iter = "newton": d.F (cellstr f1..fn), d.J (celdas n x n con las derivadas parciales, en x,y[,z])
%   d.x0 punto inicial   d.tol tolerancia   d.maxit iteraciones fijas (opcional)   d.titulo
%   d.despeje (cellstr) y d.sistema (cellstr): se escriben como notas (el despeje "en papel")
%   op (interno): c0, r0, tpos, notas, hc (columna de las celdas auxiliares del jacobiano)
function C = iterativa (d, op)
  if nargin < 2, op = struct (); endif
  x0 = d.x0(:); n = numel (x0); tol = 1e-3; if isfield (d, "tol"), tol = d.tol; endif
  maxit = 200; fijo = false; if isfield (d, "maxit") && ~ isempty (d.maxit), maxit = d.maxit; fijo = true; endif
  vars = {"x", "y", "z"}(1:min (n, 3)); if isfield (d, "vars"), vars = cellstr (d.vars)(:)'; endif
  c0 = 7; r0 = 7; if isfield (op, "c0"), c0 = op.c0; endif; if isfield (op, "r0"), r0 = op.r0; endif
  hc = c0 + 4; if isfield (op, "hc"), hc = op.hc; endif
  sc = @(s) regexprep (s, '(?<![.])([*/^])', '.$1');
  if strcmp (d.iter, "puntofijo")
    gts = hm_normexpr (cellstr (d.g), vars); if numel (gts) ~= n, error ("hm_ej_xlsx: g debe tener %d expresiones", n); endif
    gh = cellfun (@(s) str2func (["@(" strjoin(vars, ",") ") " sc(s)]), gts, "UniformOutput", false);
    paso = @(X) cellfun (@(h) h (num2cell (X)(:){:}), gh)(:);
    ff = @(j, prev, cur) hm_fexcel (gts{j}, vars, prev);
    texto = arrayfun (@(j) sprintf ("g%d = %s", j, gts{j}), 1:n, "UniformOutput", false);
  elseif strcmp (d.iter, "newton")
    Fs = hm_normexpr (cellstr (d.F), vars); Js = d.J; if ~ iscell (Js), error ("hm_ej_xlsx: J debe ser una matriz n x n de textos"); endif
    if iscell (Js), Js = cellfun (@(t) hm_normexpr (t, vars), Js, "UniformOutput", false); endif
    if numel (Fs) ~= n || ~ isequal (size (Js), [n n]), error ("hm_ej_xlsx: F debe tener %d expresiones y J ser %dx%d", n, n, n); endif
    va = strjoin (vars, ",");
    Fh = str2func (["@(" va ") [" strjoin(cellfun (sc, Fs(:)', "UniformOutput", false), ";") "]"]);
    Jh = cell (n, n); for a = 1:n, for b = 1:n, Jh{a,b} = sc (Js{a,b}); endfor, endfor
    Jf = str2func (["@(" va ") [" strjoin(arrayfun (@(a) strjoin (Jh(a,:), ","), 1:n, "UniformOutput", false), ";") "]"]);
    paso = @(X) X - Jf (num2cell (X)(:){:}) \ Fh (num2cell (X)(:){:});
    rb = @(k) r0 + 1 + k*n;
    Jr = @(k) sprintf ("$%s$%d:$%s$%d", hm_col_excel (hc), rb(k), hm_col_excel (hc+n-1), rb(k)+n-1);
    Fr = @(k) sprintf ("$%s$%d:$%s$%d", hm_col_excel (hc+n), rb(k), hm_col_excel (hc+n), rb(k)+n-1);
    ff = @(j, prev, cur, k) sprintf ("%s-INDEX(MMULT(MINVERSE(%s),%s),%d)", prev{j}, Jr (k), Fr (k), j);
    texto = [arrayfun(@(j) sprintf ("f%d = %s", j, Fs{j}), 1:n, "UniformOutput", false)];
  elseif isfield (d, "A") && isfield (d, "b")
    % sistema A x = b (ya reordenado). Las formulas de la hoja NO llevan numeros del sistema: apuntan a las celdas de A y b
    % (bloque "Sistema" a la derecha), como x_j = (b_j - sum a_jm x_m)/a_jj  (Jacobi: iteracion anterior; Gauss-Seidel: usa lo ya calculado)
    A = d.A; bb = d.b(:); gs = isfield (d, "gs") && d.gs;
    if rows (A) ~= n || columns (A) ~= n || numel (bb) ~= n || any (diag (A) == 0)
      if rows (A) == n && columns (A) == n && numel (bb) == n
        error ("hm_ej_xlsx: el sistema no se puede reordenar para que la diagonal no tenga ceros: revisa que A y b esten bien leidos del enunciado (una fila por ecuacion, columnas x,y,z)");
      endif
      error ("hm_ej_xlsx: A es %dx%d, b tiene %d y x0 tiene %d datos; hace falta A cuadrada del tamano de x0", rows (A), columns (A), numel (bb), n);
    endif
    sysp = [r0 + 1, c0 + 4]; if isfield (op, "sys"), sysp = op.sys; endif
    paso = @(X) paso_sis (A, bb, X, gs);
    ff = @(j, prev, cur) fila_sis_ref (n, j, prev, cur, gs, sysp);
    texto = arrayfun (@(j) sprintf ("%% %s = %s", vars{min (j, numel (vars))}, fila_sis (A, bb, j, vars, vars, gs)), 1:n, "UniformOutput", false);
  else
    B = d.B; Cv = d.Cv(:);
    paso = @(X) B * X + Cv;
    ff = @(j, prev, cur) fila_lin (B(j,:), Cv(j), prev);
    texto = {sprintf("BJ = %s", mat2str (B, 4)), sprintf("C = %s", mat2str (Cv', 4))};
  endif
  % lo que va "en papel" (ecuaciones reordenadas para E.D.D., despeje de cada incognita) se escribe como comentario %
  cm = @(c) cellfun (@(t) merge (~ isempty (regexp (t, '^\s*%')), t, ["% " t]), cellstr (c)(:)', "UniformOutput", false);
  if isfield (d, "sistema"), texto = [cm(d.sistema), texto]; endif
  if isfield (d, "despeje"), texto = [cm(d.despeje), texto]; endif
  if fijo, texto{end+1} = sprintf ("X0 = %s ;  %d iteraciones", mat2str (x0', 3), maxit);
  else, texto{end+1} = sprintf ("X0 = %s ;  criterio E < %g", mat2str (x0', 3), tol); endif
  X = x0; K = 0;
  do
    Xn = paso (X); E = norm (Xn - X, inf); X = Xn; K = K + 1;
  until (~ fijo && E < tol) || K >= maxit || ~ all (isfinite (X))
  tit = "Resolucion metodo iterativo"; if isfield (d, "titulo"), tit = d.titulo; endif
  % encabezado del error como en tus hojas: Gauss-Seidel "E"; punto fijo y Newton "Ei"
  if ~ isfield (op, "hdrE"), op.hdrE = merge (any (strcmp (d.iter, {"puntofijo", "newton"})), "Ei", "E"); endif
  C = hm_bloques_vivo ("", tit, x0, ff, texto, K, "inf", [], op);
  if exist ("sysp", "var")
    if sysp(1) >= 3, C = pn (C, sysp(1) - 2, sysp(2), "Sistema (reordenado)"); endif
    C = bloque_sistema (C, sysp(1) - 1, sysp(2), A, bb);
  endif
  if strcmp (d.iter, "newton")
    cx = hm_col_excel (c0 + 1);
    for b = 0:n, C{r0, hc+b} = "{h}"; endfor; C{r0, hc} = "{h}J(Xk-1)"; C{r0, hc+n} = "{h}F(Xk-1)";
    for k = 1:K
      r = rb (k);
      prev = arrayfun (@(m) sprintf ("%s%d", cx, r - n + m - 1), 1:n, "UniformOutput", false);
      for a = 1:n
        for b = 1:n, C{r+a-1, hc+b-1} = ["=" hm_fexcel(Js{a,b}, vars, prev)]; endfor
        C{r+a-1, hc+n} = ["=" hm_fexcel(Fs{a}, vars, prev)];
      endfor
    endfor
  endif
endfunction

% Layout de tu ods del examen modelo: por pregunta, titulo del metodo en la fila 18, tabla I | Xi | Ei desde la fila 22
% (B:D el primero, F:H el segundo...), un bloque de n filas por iteracion. Arriba queda el espacio para pegar el enunciado.
%   d.examen true   d.metodos = lista de metodos (cada uno con los campos de iterativa, mas d.titulo = "Metodo de Newton")
function C = examen (d)
  % Varios metodos de la misma pregunta, pegados a la esquina de la hoja (A1): titulo en la fila 1, tabla I | Xi | Ei debajo,
  % una tabla al lado de otra (una columna libre entre ellas). Bloques "verificar" (comprobar que unos puntos son solucion) debajo.
  M = d.metodos; if isstruct (M), M = num2cell (M); endif
  C = cell (1, 1); it = {}; vf = {};
  for m = 1:numel (M)
    s = normaliza (M{m});
    if isfield (s, "metodo") && strcmpi (s.metodo, "verificar"), vf{end+1} = s; else, it{end+1} = s; endif
  endfor
  % F de referencia (la del primer Newton o verificar): permite comprobar que los g de punto fijo salen de esas ecuaciones
  Fref = {};
  for m = 1:numel (M), if isfield (M{m}, "F") && isempty (Fref), Fref = cellstr (M{m}.F)(:)'; endif, endfor
  for m = 1:numel (it)
    if isfield (it{m}, "iter") && strcmp (it{m}.iter, "puntofijo"), it{m} = nota_pf (it{m}, Fref); endif
  endfor
  nm = numel (it); fin = 1;
  % columna donde va el bloque "Sistema" (A | b): a la derecha de las tablas y de las columnas ocultas del jacobiano de Newton
  ult = 0; for m = 1:nm, if isfield (it{m}, "iter") && strcmp (it{m}.iter, "newton"), ult = m; endif, endfor
  cs = 1 + 4*nm + merge (ult > 0, 1 + 6*ult, 0);
  for m = 1:nm
    s = it{m}; if ~ isfield (s, "iter"), error ("hm_ej_xlsx: cada metodo necesita el campo iter"); endif
    c0 = 1 + 4*(m-1);
    op = struct ("c0", c0, "r0", 2, "tpos", [1 c0], "notas", [], "hc", 1 + 4*nm + 1 + 6*(m-1), "sys", [3 cs], "hdrE", "Ei");
    Cm = iterativa (s, op);
    C = fusionar (C, Cm);
    fin = max (fin, find (any (~ cellfun (@isempty, Cm), 2), 1, "last"));
  endfor
  r = fin + 2;
  % lo que el estudiante hace en papel (reordenar para E.D.D., despejes): comentarios %, una sola vez
  vistos = {};
  for m = 1:nm
    for campo = {"sistema", "despeje"}
      if ~ isfield (it{m}, campo{1}), continue; endif
      for t = cellstr (it{m}.(campo{1}))(:)'
        tt = t{1}; if isempty (regexp (tt, '^\s*%')), tt = ["% " tt]; endif
        if ~ any (strcmp (vistos, tt)), vistos{end+1} = tt; C = pn (C, r, 1, tt); r = r + 1; endif
      endfor
    endfor
  endfor
  if ~ isempty (vistos), r = r + 1; endif
  for m = 1:nm
    s = it{m};
    if isfield (s, "conv") && s.conv && isfield (s, "A") && isfield (s, "b")
      [C, fc] = convergencia (C, r, 1, [3 cs], rows (s.A)); r = fc + 2; break
    endif
  endfor
  for q = 1:numel (vf)
    s = vf{q}; Fs = cellstr (s.F)(:)'; P = s.puntos; if iscell (P), P = cell2mat (cellfun (@(v) v(:)', P(:), "UniformOutput", false)); endif
    if columns (P) == 1 && rows (P) > 1, P = P'; endif
    n = columns (P); vars = {"x", "y", "z"}(1:min (n, 3));
    tit = "Verificacion"; if isfield (s, "titulo"), tit = s.titulo; endif
    Cv = cell (1, 1); Cv{1,1} = ["{n}" tit];
    for j = 1:n, Cv{2,j} = struct ("v", vars{j}, "s", 1); endfor
    for j = 1:numel (Fs), Cv{2,n+j} = struct ("v", sprintf ("f%d", j), "s", 1); endfor
    % si F no se anula en algun punto (errata del enunciado), se avisa y se agregan los puntos cercanos que SI son solucion
    [aviso, Pc] = revisar_puntos (Fs, vars, P);
    P0 = rows (P); P = [P; Pc];
    for i = 1:rows (P)
      for j = 1:n, Cv{2+i,j} = struct ("v", P(i,j), "s", 1); endfor
      refs = arrayfun (@(j) sprintf ("%s%d", hm_col_excel (j), r + 1 + i), 1:n, "UniformOutput", false);
      for j = 1:numel (Fs), Cv{2+i,n+j} = struct ("v", ["=" hm_fexcel(Fs{j}, vars, refs)], "s", 1); endfor
    endfor
    for q = 1:rows (Pc), Cv{2+P0+q,n+numel (Fs)+1} = struct ("v", "% punto corregido", "s", 0); endfor
    nn = ""; if isfield (s, "nota") && ~ isempty (s.nota), nn = regexprep (s.nota, '^\s*%\s*', ""); endif
    if ~ isempty (aviso), nn = aviso; endif
    if ~ isempty (nn), Cv{rows(P)+3,1} = struct ("v", ["% " nn], "s", 0); endif
    Cd = cell (r - 1 + rows (Cv), columns (Cv)); Cd(r:end, :) = Cv;
    C = fusionar (C, Cd); r = r + (rows (Cv) + 1);
  endfor
endfunction

% Evalua F en cada punto; devuelve un aviso (texto) si alguno no da cero y los puntos solucion mas cercanos (Newton numerico).
function [aviso, Pc] = revisar_puntos (Fs, vars, P)
  aviso = ""; Pc = zeros (0, columns (P));
  sc_ = @(t) regexprep (hm_normexpr (t, vars), '(?<![.])([*/^])', '.$1');
  try
    Fh = str2func (["@(" strjoin(vars, ",") ") [" strjoin(cellfun (sc_, Fs(:)', "UniformOutput", false), ";") "]"]);
    ev = @(x) Fh (num2cell (x(:)'){:});
    malos = {}; mal = zeros (0, columns (P));
    for i = 1:rows (P)
      v = ev (P(i,:)); v = v(:)';
      if any (abs (v) > 1e-9)
        malos{end+1} = sprintf ("F(%s)=(%s)", strjoin (arrayfun (@(a) sprintf ("%g", a), P(i,:), "UniformOutput", false), ","), strjoin (arrayfun (@(a) sprintf ("%g", a), v, "UniformOutput", false), ","));
        mal(end+1,:) = P(i,:);
      endif
    endfor
    if isempty (malos), return; endif
    % punto cercano que si anula F (Newton con jacobiano numerico, solo si converge a un valor limpio)
    for i = 1:rows (mal)
      x = mal(i,:)(:); ok = false;
      for it = 1:60
        f = ev (x)(:); if norm (f, inf) < 1e-12, ok = true; break; endif
        J = zeros (numel (f), numel (x));
        for q = 1:numel (x), h = 1e-7 * max (1, abs (x(q))); xp = x; xp(q) = xp(q) + (h); J(:,q) = (ev (xp)(:) - f) / h; endfor
        dx = J \ f;
        if any (~ isfinite (dx)), break; endif
        x = x - (dx);
      endfor
      if ok
        x = round (x' * 1e6) / 1e6 + 0;
        if norm (ev (x)(:), inf) < 1e-9 && ~ any (all (abs (Pc - x) < 1e-6, 2)) && ~ any (all (abs (P - x) < 1e-6, 2)), Pc(end+1,:) = x; endif
      endif
    endfor
    aviso = ["OJO: " strjoin(malos, " ; ") " no se anula: esos puntos NO son solucion (posible errata del enunciado)"];
    if ~ isempty (Pc)
      aviso = [aviso ". Si son solucion: " strjoin(arrayfun (@(i) sprintf ("(%s)", strjoin (arrayfun (@(a) sprintf ("%g", a), Pc(i,:), "UniformOutput", false), ",")), 1:rows (Pc), "UniformOutput", false), " y ")];
    endif
  catch
    aviso = ""; Pc = zeros (0, columns (P));
  end_try_catch
endfunction

% Si A no es E.D.D. (o tiene ceros en la diagonal) busca el orden de filas que si lo es, o el mas parecido (mayor cociente |ajj|/suma|ajm|).
function [A, b, nota] = reordenar_sis (A, b)
  n = rows (A); nota = "";
  razon = @(M) min (abs (diag (M)) ./ max (sum (abs (M), 2) - abs (diag (M)), eps));
  if all (diag (A) ~= 0) && razon (A) > 1, return; endif
  P = perms (1:n); mejor = -Inf; pm = 1:n;
  for k = 1:rows (P)
    M = A(P(k,:), :); if any (diag (M) == 0), continue; endif
    q = razon (M) - 1e-6 * sum (P(k,:) ~= (1:n));   % a igualdad, el que menos mueve
    if q > mejor, mejor = q; pm = P(k,:); endif
  endfor
  if isinf (mejor) || isequal (pm, 1:n), return; endif
  A = A(pm, :); b = b(pm);
  nota = ["Filas reordenadas para E.D.D.: " strjoin(arrayfun (@(i) sprintf ("ec%d", i), pm, "UniformOutput", false), ", ")];
  if razon (A) <= 1, nota = [nota " (lo mas parecido posible a E.D.D.)"]; endif
endfunction

function s = normaliza (s)
  % lo que viene de JSON: J como lista de listas -> celdas n x n; cadenas -> cellstr; B/C numericos
  if isfield (s, "J") && iscell (s.J) && ~ isempty (s.J) && iscell (s.J{1}), s.J = vertcat (cellfun (@(r) r(:)', s.J(:), "UniformOutput", false){:}); endif
  if isfield (s, "J") && ischar (s.J), s.J = cellstr (s.J); endif
  for f = {"F", "g", "despeje", "sistema"}
    if isfield (s, f{1}), s.(f{1}) = cellstr (s.(f{1}))(:)'; endif
  endfor
  if isfield (s, "x0"), s.x0 = s.x0(:)'; endif
  if isfield (s, "A") && iscell (s.A), s.A = cell2mat (cellfun (@(r) r(:)', s.A(:), "UniformOutput", false)); endif
  if isfield (s, "A") && isfield (s, "b") && ~ isempty (s.A) && rows (s.A) == columns (s.A) && rows (s.A) <= 7 && numel (s.b) == rows (s.A)
    [s.A, s.b, nota] = reordenar_sis (s.A, s.b(:));
    if ~ isempty (nota)
      if isfield (s, "sistema"), s.sistema = [cellstr(s.sistema)(:)', {nota}]; else, s.sistema = {nota}; endif
    endif
    % el despeje a papel (ecuacion -> incognita) lo escribe el programa desde A y b: asi nunca contradice a la hoja
    vv = {"x", "y", "z"}; if isfield (s, "vars"), vv = cellstr (s.vars)(:)'; endif
    if numel (vv) >= rows (s.A) && all (diag (s.A) ~= 0), s.despeje = despeje_sis (s.A, s.b(:), vv); endif
  endif
  if isfield (s, "C") && ~ isfield (s, "Cv"), s.Cv = s.C; s = rmfield (s, "C"); endif
  if isfield (s, "metodo") && ~ isfield (s, "iter")
    m = lower (s.metodo);
    if any (strcmp (m, {"newton", "newton-raphson"})), s.iter = "newton";
    elseif any (strcmp (m, {"puntofijo", "punto fijo"})), s.iter = "puntofijo";
    elseif any (strcmp (m, {"jacobi", "gaussseidel", "gauss-seidel"})), s.iter = "matricial"; if ~ strcmp (m, "jacobi"), s.gs = true; endif; endif
  endif
  if isfield (s, "iter") && strcmp (s.iter, "newton") && isfield (s, "F"), s = revisar_newton (s); endif
endfunction

% Ecuacion reordenada -> despeje de la incognita de la diagonal, como en papel:  -3x - z = 2  ->  x = (-2 - z)/3
function T = despeje_sis (A, b, vv)
  n = rows (A); T = cell (1, n);
  for j = 1:n
    eq = ""; for m = 1:n, eq = suma_txt (eq, A(j,m), vv{m}); endfor
    sg = sign (A(j,j)); num = "";
    if b(j) ~= 0, num = suma_txt (num, sg * b(j), ""); endif
    nt = (b(j) ~= 0);
    for m = 1:n
      if m == j || A(j,m) == 0, continue; endif
      num = suma_txt (num, -sg * A(j,m), vv{m}); nt = nt + 1;
    endfor
    den = abs (A(j,j));
    if isempty (num), r = "0";
    elseif den == 1, r = merge (nt > 1, ["(" num ")"], num);
    else, r = merge (nt > 1, ["(" num ")/" gnum(den)], [num "/" gnum(den)]); endif
    T{j} = sprintf ("%s = %s  ->  %s = %s", eq, gnum (b(j)), vv{j}, r);
  endfor
endfunction

function s = suma_txt (s, c, v)
  % agrega el termino c*v a la suma s en estilo de papel (coeficiente 1 no se escribe; el primer termino lleva su signo)
  if c == 0, return; endif
  a = abs (c); t = merge (strcmp (v, "") || a ~= 1, [gnum(a) v], v);
  if isempty (s), s = merge (c < 0, ["-" t], t);
  else, s = [s merge(c < 0, " - ", " + ") t]; endif
endfunction

function t = gnum (v)
  if v == round (v), t = sprintf ("%d", v); else, t = sprintf ("%.10g", v); endif
endfunction

% Punto fijo: si se conoce F, en una solucion de F=0 debe cumplirse g(x*)=x*; si no, el despeje esta mal y se avisa en "sistema" (comentario %).
function s = nota_pf (s, Fref)
  Fs = {}; if isfield (s, "F"), Fs = cellstr (s.F)(:)'; elseif ~ isempty (Fref), Fs = Fref; endif
  gs = cellstr (s.g)(:)'; n = numel (gs);
  if isempty (Fs) || numel (Fs) ~= n, return; endif
  vars = {"x", "y", "z"}(1:min (n, 3)); if isfield (s, "vars"), vars = cellstr (s.vars)(:)'; endif
  aviso = "";
  try
    va = strjoin (vars, ","); scc = @(t) regexprep (hm_normexpr (t, vars), '(?<![.])([*/^])', '.$1');
    Fh = str2func (["@(" va ") [" strjoin(cellfun (scc, Fs(:)', "UniformOutput", false), ";") "]"]);
    gh = cellfun (@(t) str2func (["@(" va ") " scc(t)]), gs, "UniformOutput", false);
    ev = @(x) Fh (num2cell (x(:)'){:});
    x = s.x0(:); ok = false;
    for it = 1:80
      f = ev (x)(:); if norm (f, inf) < 1e-12, ok = true; break; endif
      Jn = zeros (n, n);
      for q = 1:n, h = 1e-7 * max (1, abs (x(q))); xp = x; xp(q) = xp(q) + (h); Jn(:,q) = (ev (xp)(:) - f) / h; endfor
      if any (~ isfinite (Jn(:))) || rcond (Jn) < 1e-14, break; endif
      x = x - (Jn \ f);
    endfor
    if ok
      g = zeros (n, 1); for j = 1:n, g(j) = gh{j} (num2cell (x'){:}); endfor
      if norm (g - x, inf) > 1e-6
        pt = @(v) ["(" strjoin(arrayfun (@(a) sprintf ("%g", a + 0), round (v(:)' * 1e6) / 1e6, "UniformOutput", false), ",") ")"];
        aviso = sprintf ("OJO: con estos g, en una solucion de F=0 (por ejemplo %s) g(x) da %s, no el mismo punto: revisar el despeje", pt (x), pt (g));
      endif
    endif
  catch
    aviso = "";
  end_try_catch
  if ~ isempty (aviso)
    if isfield (s, "sistema"), s.sistema = [cellstr(s.sistema)(:)', {aviso}]; else, s.sistema = {aviso}; endif
  endif
endfunction

% Newton: el jacobiano que escribio la IA se compara con la derivada exacta de F (hm_derivar); si no coincide se usa la exacta.
% Tambien avisa si J(X0) es singular (Newton no se puede aplicar desde ese punto).
function s = revisar_newton (s)
  Fs = cellstr (s.F)(:)'; n = numel (Fs);
  vars = {"x", "y", "z"}(1:min (n, 3)); if isfield (s, "vars"), vars = cellstr (s.vars)(:)'; endif
  if numel (vars) < n, return; endif
  Fs = hm_normexpr (Fs, vars);
  Jd = cell (n, n); ok = true;
  try
    for a = 1:n, for b = 1:n, Jd{a,b} = hm_derivar (Fs{a}, vars{b}); endfor, endfor
  catch
    ok = false;
  end_try_catch
  sc = @(t) regexprep (t, '(?<![.])([*/^])', '.$1');
  va = strjoin (vars, ",");
  ev = @(M, X) cellfun (@(t) str2func (["@(" va ") " sc(hm_normexpr (t, vars))]) (num2cell (X(:)'){:}), M);
  nota = "";
  tiene = isfield (s, "J") && iscell (s.J) && isequal (size (s.J), [n n]);
  if ~ tiene
    if ~ ok, error ("hm_ej_xlsx: falta J y no pude derivarla de F"); endif
    s.J = Jd; nota = "J = matriz de derivadas parciales de F (calculada por el programa)";
  elseif ok
    P = [reshape(s.x0, 1, []); 0.37+(1:n); 1.9-0.31*(1:n); 0.7+0.13*(1:n)];
    malo = false;
    for k = 1:rows (P)
      try
        d1 = ev (s.J, P(k,:)); d2 = ev (Jd, P(k,:));
        if any (abs (d1(:) - d2(:)) > 1e-8 * (1 + abs (d2(:)))), malo = true; break; endif
      catch
        malo = true; break;
      end_try_catch
    endfor
    if malo, s.J = Jd; nota = "OJO: la J escrita no coincidia con las derivadas de F; se usa J = dF/dx exacta"; endif
  endif
  % J(X0) singular?
  try
    J0 = ev (s.J, s.x0);
    if any (~ isfinite (J0(:))) || rcond (J0) < 1e-12
      nota = [nota merge(isempty (nota), "", ". ") sprintf("OJO: J(X0) es singular, Newton no se puede aplicar desde X0=(%s)", strjoin (arrayfun (@(a) sprintf ("%g", a), s.x0, "UniformOutput", false), ","))];
    endif
  catch
  end_try_catch
  if ~ isempty (nota)
    if isfield (s, "sistema"), s.sistema = [cellstr(s.sistema)(:)', {nota}]; else, s.sistema = {nota}; endif
  endif
endfunction

function A = fusionar (A, B)
  A(end+1:rows (B), :) = {[]}; if columns (B) > columns (A), A(:, end+1:columns (B)) = {[]}; endif
  for r = 1:rows (B), for c = 1:columns (B), if ~ isempty (B{r,c}), A{r,c} = B{r,c}; endif, endfor, endfor
endfunction

function Xn = paso_sis (A, b, X, gs)
  Xn = X(:); n = numel (Xn);
  for j = 1:n
    src = X(:); if gs, src(1:j-1) = Xn(1:j-1); endif
    t = b(j); for m = 1:n, if m ~= j, t = t - (A(j,m) * src(m)); endif, endfor
    Xn(j) = t / A(j,j);
  endfor
endfunction

function f = fila_sis (A, b, j, prev, cur, gs)
  n = columns (A); t = "";
  if b(j) ~= 0, t = sprintf ("%.15g", b(j)); endif
  for m = 1:n
    if m == j || A(j,m) == 0, continue; endif
    ref = prev{m}; if gs && m < j, ref = cur{m}; endif
    c = abs (A(j,m)); term = ref; if c ~= 1, term = sprintf ("%.15g*%s", c, ref); endif
    if A(j,m) > 0, sg = "-"; else, sg = "+"; endif          % x_j = (b - sum a_jm x_m)/a_jj
    if isempty (t), t = merge (sg == "-", ["-" term], term); else, t = [t sg term]; endif
  endfor
  if isempty (t), t = "0"; endif
  if A(j,j) == 1, f = t;
  elseif A(j,j) < 0, f = sprintf ("(%s)/(%.15g)", t, A(j,j));
  else, f = sprintf ("(%s)/%.15g", t, A(j,j)); endif
endfunction

% formula de la fila j con REFERENCIAS a las celdas de A y b:  (b_j - a_j1*x1 - a_j2*x2 ...)/a_jj
function f = fila_sis_ref (n, j, prev, cur, gs, sysp)
  ar = @(i, m) sprintf ("$%s$%d", hm_col_excel (sysp(2) + m - 1), sysp(1) + i - 1);
  t = sprintf ("$%s$%d", hm_col_excel (sysp(2) + n), sysp(1) + j - 1);
  for m = 1:n
    if m == j, continue; endif
    ref = prev{m}; if gs && m < j, ref = cur{m}; endif
    t = [t sprintf("-%s*%s", ar (j, m), ref)];
  endfor
  f = sprintf ("(%s)/%s", t, ar (j, j));
endfunction

% Bloque "Sistema": A | b | E.D.D. por filas (fila de encabezado en r, datos desde r+1, frase de E.D.D. debajo). Devuelve C.
function C = bloque_sistema (C, r, c, A, b)
  n = rows (A); b = b(:);
  C = put (C, r, c, "A", 1); for j = 2:n, C = put (C, r, c+j-1, "", 1); endfor
  C = put (C, r, c+n, "b", 1); C = put (C, r, c+n+1, "E.D.D.", 1);
  ra = r + 1;
  for i = 1:n
    for j = 1:n, C = put (C, ra+i-1, c+j-1, A(i,j), 1); endfor
    C = put (C, ra+i-1, c+n, b(i), 1);
    rg = sprintf ("%s%d:%s%d", L (c), ra+i-1, L (c+n-1), ra+i-1); dg = sprintf ("%s%d", L (c+i-1), ra+i-1);
    C = put (C, ra+i-1, c+n+1, sprintf ('=IF(ABS(%s)>SUMPRODUCT(ABS(%s))-ABS(%s),"si","no")', dg, rg, dg), 1);
  endfor
  rE = sprintf ("%s%d:%s%d", L (c+n+1), ra, L (c+n+1), ra+n-1);
  C = pn (C, ra+n, c, sprintf ('=IF(COUNTIF(%s,"si")=%d,"A es E.D.D. por filas: Jacobi y Gauss-Seidel convergen","A no es E.D.D. en todas las filas: se revisan las normas de BJ y BGS")', rE, n));
endfunction

% Bloque "Convergencia": D+L | U ; BJ y BGS con sus normas infinito; todo con formulas vivas sobre el bloque Sistema (A en pos = [fila col]).
% Escribe en C desde la fila r, columna c; devuelve la ultima fila usada.
function [C, fin] = convergencia (C, r, c, pos, n)
  ra = pos(1); ca = pos(2);
  C = pn (C, r, c, "Convergencia: normas de BJ y BGS (si ||B||inf < 1 el metodo converge)");
  r = r + (1);
  c2 = c + n + 2;
  C = put (C, r, c, "D+L", 1); for j = 2:n, C = put (C, r, c+j-1, "", 1); endfor
  C = put (C, r, c2, "U", 1); for j = 2:n, C = put (C, r, c2+j-1, "", 1); endfor
  rd = r + 1;
  for i = 1:n
    for j = 1:n
      ar = sprintf ("$%s$%d", L (ca+j-1), ra+i-1);
      if j <= i, C = put (C, rd+i-1, c+j-1, ["=" ar], 1); else, C = put (C, rd+i-1, c+j-1, 0, 1); endif
      if j > i, C = put (C, rd+i-1, c2+j-1, ["=" ar], 1); else, C = put (C, rd+i-1, c2+j-1, 0, 1); endif
    endfor
  endfor
  DL = sprintf ("%s%d:%s%d", L (c), rd, L (c+n-1), rd+n-1); U = sprintf ("%s%d:%s%d", L (c2), rd, L (c2+n-1), rd+n-1);
  r = rd + n + 1;
  C = put (C, r, c, "BJ", 1); for j = 2:n, C = put (C, r, c+j-1, "", 1); endfor; C = put (C, r, c+n, "suma|fila|", 1);
  C = put (C, r, c2, "BGS", 1); for j = 2:n, C = put (C, r, c2+j-1, "", 1); endfor; C = put (C, r, c2+n, "suma|fila|", 1);
  rb = r + 1;
  for i = 1:n
    for j = 1:n
      if i == j, C = put (C, rb+i-1, c+j-1, 0, 1);
      else, C = put (C, rb+i-1, c+j-1, sprintf ("=-$%s$%d/$%s$%d", L (ca+j-1), ra+i-1, L (ca+i-1), ra+i-1), 1); endif
      C = put (C, rb+i-1, c2+j-1, sprintf ("=-INDEX(MMULT(MINVERSE(%s),%s),%d,%d)", DL, U, i, j), 1);
    endfor
    C = put (C, rb+i-1, c+n, sprintf ("=SUMPRODUCT(ABS(%s%d:%s%d))", L (c), rb+i-1, L (c+n-1), rb+i-1), 1);
    C = put (C, rb+i-1, c2+n, sprintf ("=SUMPRODUCT(ABS(%s%d:%s%d))", L (c2), rb+i-1, L (c2+n-1), rb+i-1), 1);
  endfor
  r = rb + n;
  nj = sprintf ("MAX(%s%d:%s%d)", L (c+n), rb, L (c+n), rb+n-1); ng = sprintf ("MAX(%s%d:%s%d)", L (c2+n), rb, L (c2+n), rb+n-1);
  C = pn (C, r, c, sprintf ('="||BJ||inf = "&TEXT(%s,"0.0000")&IF(%s<1,"  < 1: Jacobi converge","  >= 1: esta norma no concluye (ver radio espectral)")', nj, nj));
  C = pn (C, r+1, c, sprintf ('="||BGS||inf = "&TEXT(%s,"0.0000")&IF(%s<1,"  < 1: Gauss-Seidel converge","  >= 1: esta norma no concluye (ver radio espectral)")', ng, ng));
  fin = r + 1;
endfunction

function f = fila_lin (Bj, Cj, prev)
  t = {};
  for m = 1:numel (Bj), if Bj(m) ~= 0, t{end+1} = sprintf ("(%.17g)*%s", Bj(m), prev{m}); endif, endfor
  if isempty (t), f = sprintf ("(%.17g)", Cj); else, f = ["(" strjoin(t, "+") ")+(" sprintf("%.17g", Cj) ")"]; endif
endfunction

% Interpolacion de Newton por diferencias divididas, con la forma de tu hoja "newthonRapshon":
%   d.newton true   d.x, d.y nodos   d.xe punto a evaluar   d.grados grados "mas apropiados" (ej. [1 2 3])
function [C, info] = newton (d)
  n = numel (d.x); C = cell (1, 1); info = struct ("P", []);
  C = put (C, 4, 4, "(f[xk+1]-f[xk])/(xk+1-xk)", 0);
  C = put (C, 5, 2, "{M}Diferencias", 1);
  for j = 1:n-1, C = put (C, 5, 4+2*(j-1), sprintf ("{M}Diferencias %d", j), 1); endfor
  C = put (C, 6, 1, "xk", 1); C = put (C, 6, 2, "f[xk]=", 1); C = put (C, 6, 3, "f(xk)", 1);
  for j = 1:n-1, C = put (C, 6, 4+2*(j-1), ["{M}" nomk(j)], 1); endfor
  for i = 0:n-1
    r = 7 + i;
    C = put (C, r, 1, d.x(i+1), 1); C = put (C, r, 2, sprintf ("f[x%d]", i), 1); C = put (C, r, 3, d.y(i+1), 1);
  endfor
  for j = 1:n-1
    vc = 5 + 2*(j-1); pc = merge (j == 1, 3, vc - 2);
    for i = 0:n-1-j
      r = 7 + i;
      C = put (C, r, vc-1, nom (i, j), 1);
      C = put (C, r, vc, sprintf ("=(%s%d-%s%d)/(A%d-A%d)", L (pc), r+1, L (pc), r, r+j, r), 1);
    endfor
  endfor
  rb = 7 + n + 1;
  xe = d.xe; xr = sprintf ("D%d", rb + 1);
  rot_ = "a)"; if isfield (d, "rotulo"), rot_ = d.rotulo; endif
  if ~ isempty (rot_), C = put (C, rb + 1, 2, ["{n}" rot_], 0); endif
  C = pn (C, rb + 1, 3, "x="); C = pn (C, rb + 1, 4, xe);
  C = put (C, rb + 2, 2, sprintf ("Polinomio con todos los coeficientes: grado %d", n-1), 0);
  t = "f[x0]";
  for j = 1:n-1
    xs = ""; for m = 0:j-1, xs = [xs sprintf("(x-x%d)", m)]; endfor
    t = [t "+" nom(0, j)(1:end) xs];
  endfor
  C = put (C, rb + 4, 2, [sprintf("P%d(x)=", n-1) t], 0);
  r = rb + 6;
  gr = [n-1, d.grados(:)']; filasP = [];
  for k = 1:numel (gr)
    g = gr(k);
    if g == n-1, s0 = 0;
    else
      best = Inf; s0 = 0;
      for s = 0:n-1-g, c_ = sum (abs (d.x(s+1:s+g+1) - xe)); if c_ < best, best = c_; s0 = s; endif, endfor
    endif
    f = sprintf ("C%d", 7 + s0);
    for j = 1:g
      prod_ = ""; for m = 0:j-1, prod_ = [prod_ sprintf("*(%s-A%d)", xr, 7+s0+m)]; endfor
      f = [f sprintf("+%s%d%s", L (5+2*(j-1)), 7+s0, prod_)];
    endfor
    C = pn (C, r, 2, sprintf ("P(%g)=", xe)); C = put (C, r, 3, ["=" f], 3); C = pn (C, r, 4, sprintf ("grado%d", g));
    info.P(k,:) = [r 3];
    if isfield (d, "fexacta") && ~ isempty (d.fexacta)
      if k == 1, C = put (C, r-1, 5, "f(x) exacto", 1); C = put (C, r-1, 6, "Error absoluto", 1); endif
      C = put (C, r, 5, ["=" hm_fexcel(d.fexacta, "x", xr)], 1); C = put (C, r, 6, sprintf ("=ABS(E%d-C%d)", r, r), 1);
    endif
    filasP(end+1) = r;
    r = r + (1);
  endfor
  if isfield (d, "fexacta") && ~ isempty (d.fexacta) && numel (filasP) > 1
    % el mas apropiado = el de menor error absoluto
    mn = strjoin (arrayfun (@(q) sprintf ("F%d", q), filasP, "UniformOutput", false), ",");
    f = sprintf ("D%d", filasP(end));
    for q = numel (filasP)-1:-1:1, f = sprintf ("IF(F%d=MIN(%s),D%d,%s)", filasP(q), mn, filasP(q), f); endfor
    C = put (C, r, 2, "Mas apropiado (menor error absoluto)=", 0); C = put (C, r, 3, ["=" f], 3);
    v = sprintf ("C%d", filasP(end));
    for q = numel (filasP)-1:-1:1, v = sprintf ("IF(F%d=MIN(%s),C%d,%s)", filasP(q), mn, filasP(q), v); endfor
    C = put (C, r, 4, ["=" v], 3);
    r = r + (1);
  endif
  if isfield (d, "extra") && ~ isempty (d.extra)
    X = d.extra; if isstruct (X), X = num2cell (X); endif
    for q = 1:numel (X)
      r = r + (1);
      C = pn (C, r, 1, X{q}.rotulo);
      C = put (C, r, 3, ["=" hm_fexcel(X{q}.expr, "P", sprintf ("C%d", info.P(1,1)))], 3);
    endfor
  endif
endfunction

function s = nomk (j)
  s = "f[xk"; for m = 1:j, s = [s merge(m == 1, ",xk+1", sprintf(",xk+%d", m))]; endfor; s = [s "]"];
endfunction

function s = nom (i, j)
  s = "f["; for m = 0:j, s = [s sprintf("x%d", i+m) merge(m < j, ",", "")]; endfor; s = [s "]"];
endfunction

function C = pn (C, r, c, v)
  C{r,c} = struct ("v", v, "s", 0);
endfunction

function C = put (C, r, c, v, s)
  if nargin < 5 || s == 0, C{r,c} = v; else, C{r,c} = struct ("v", v, "s", s); endif
endfunction

function s = L (c), s = hm_col_excel (c); endfunction

function C = lineal (d)
  n = numel (d.x); C = cell (1, 1);
  labs = {"X", "Y"}; if isfield (d, "labs"), labs = d.labs; endif
  if isfield (d, "solo") && strcmpi (d.solo, "parabola")
    % el enunciado pide SOLO la parabola: tabla de la hoja "Regresion polinomial", datos directamente en las columnas x | y, pegada a A1
    pred = []; if isfield (d, "pred"), pred = d.pred; endif
    xl = "X"; if isfield (d, "xl"), xl = d.xl; endif
    [C, ~] = parabola (C, 1, 3, n, pred, struct ("x", d.x, "y", d.y, "tit", d.titulo, "xl", xl));
    return
  endif
  C = put (C, 1, 1, d.titulo, 2);
  C = put (C, 2, 1, labs{1}, 1); C = put (C, 2, 2, labs{2}, 1);
  for i = 1:n, C = put (C, 2+i, 1, d.x(i), 1); C = put (C, 2+i, 2, d.y(i), 1); endfor
  r0 = 3; pred = []; if isfield (d, "pred"), pred = d.pred; endif
  xl = "X"; if isfield (d, "xl"), xl = d.xl; endif
  [C, o1] = recta (C, 2, "A", "B", r0, n, merge (isfield (d, "swap") && d.swap, ["Recta de " labs{2} " sobre " labs{1}], "Recta"), pred, xl);
  fin = o1.fin; o2 = []; o3 = [];
  if isfield (d, "par") && d.par
    [C, o2] = parabola (C, fin + 2, r0, n, pred); fin = o2.fin;
  endif
  if isfield (d, "swap") && d.swap
    [C, o3] = recta (C, fin + 2, "B", "A", r0, n, ["Recta de " labs{1} " sobre " labs{2}], [], xl); fin = o3.fin;
  endif
  r = fin + 2;
  if ~ isempty (o2)
    C = put (C, r, 1, "Comparación", 2);
    C = put (C, r+1, 1, "R2 recta"); C = put (C, r+1, 2, ["=" o1.R2]);
    C = put (C, r+2, 1, "R2 parábola"); C = put (C, r+2, 2, ["=" o2.R2]);
    C = put (C, r+3, 1, "Error est. recta"); C = put (C, r+3, 2, ["=" o1.EE]);
    C = put (C, r+4, 1, "Error est. parábola"); C = put (C, r+4, 2, ["=" o2.EE]);
    C = put (C, r+5, 1, "Más preciso"); C = put (C, r+5, 2, sprintf ('=IF(B%d>B%d,"Parábola","Recta")', r+2, r+1), 3);
    C = put (C, r+7, 1, sprintf (['="Interpretación: la "&LOWER(B%d)&" tiene mayor R^2 ("&TEXT(MAX(B%d,B%d),"0.0000")&" frente a "&TEXT(MIN(B%d,B%d),"0.0000")&")"&' ...
      'IF((B%d<B%d)<>(B%d>B%d),"; pero el error estándar es menor en la "&IF(B%d<B%d,"parábola","recta")&", así que la mejora es mínima.",".")'], ...
      r+5, r+1, r+2, r+1, r+2, r+4, r+3, r+2, r+1, r+4, r+3));
    r = r + (9);
  endif
  if isfield (d, "resp") && d.resp > 0
    R = respuestas (d.resp, o1, o2, o3);
    if ~ isempty (R)
      C = put (C, r, 1, "Me piden:", 2);
      for i = 1:rows (R)
        C = put (C, r+i, 1, R{i,1}); C = put (C, r+i, 5, R{i,2}, R{i,3});
      endfor
      % el enunciado pide un grafico: se deja el titulo para que pegues tu captura debajo (no se inventa)
      if d.resp == 6, C = put (C, r + rows (R) + 2, 1, "Captura del diagrama de dispersión (pegar aquí)", 2); endif
    endif
  endif
endfunction

function [C, o] = recta (C, top, xc, yc, r0, N, titulo, pred, xl)
  h = top + 1; r1 = h + 1; rN = h + N; rs = rN + 1;
  C = put (C, top, 4, titulo, 2);
  enc = {"i", "x", "y", "x^2", "x*y", "P(x)", "error^2", "(y-media)^2"};
  for k = 1:8, C = put (C, h, 3+k, enc{k}, 2); endfor
  a0 = sprintf ("$M$%d", h+4); a1 = sprintf ("$M$%d", h+5); med = sprintf ("$Q$%d", h+2);
  for i = 1:N
    r = r1 + i - 1; q = r0 + i - 1;
    C = put (C, r, 4, i); C = put (C, r, 5, sprintf ("=%s%d", xc, q)); C = put (C, r, 6, sprintf ("=%s%d", yc, q));
    C = put (C, r, 7, sprintf ("=E%d^2", r)); C = put (C, r, 8, sprintf ("=E%d*F%d", r, r));
    C = put (C, r, 9, sprintf ("=%s+%s*E%d", a0, a1, r)); C = put (C, r, 10, sprintf ("=(I%d-F%d)^2", r, r));
    C = put (C, r, 11, sprintf ("=(F%d-%s)^2", r, med));
  endfor
  C = put (C, rs, 4, "suma");
  for c = [5 6 7 8 10 11], C = put (C, rs, c, sprintf ("=SUM(%s%d:%s%d)", L(c), r1, L(c), rN)); endfor
  C = put (C, h, 14, "b", 2);
  C = put (C, h+1, 12, sprintf ("=COUNT(E%d:E%d)", r1, rN)); C = put (C, h+1, 13, sprintf ("=E%d", rs)); C = put (C, h+1, 14, sprintf ("=F%d", rs));
  C = put (C, h+2, 12, sprintf ("=E%d", rs)); C = put (C, h+2, 13, sprintf ("=G%d", rs)); C = put (C, h+2, 14, sprintf ("=H%d", rs));
  C = put (C, h+3, 12, "coef.");
  M = sprintf ("L%d:M%d", h+1, h+2); B = sprintf ("N%d:N%d", h+1, h+2);
  for k = 0:1
    C = put (C, h+4+k, 12, sprintf ("a%d", k));
    C = put (C, h+4+k, 13, sprintf ("=INDEX(MMULT(MINVERSE(%s),%s),%d,1)", M, B, k+1));
  endfor
  C = put (C, h+1, 16, "Q", 1); C = put (C, h+1, 17, sprintf ("=SUM(J%d:J%d)", r1, rN), 1);
  C = put (C, h+2, 16, "Media de y", 1); C = put (C, h+2, 17, sprintf ("=AVERAGE(F%d:F%d)", r1, rN), 1);
  C = put (C, h+3, 16, "R^2", 1);
  C = put (C, h+3, 17, sprintf ("=(SUMPRODUCT((F%d:F%d-%s)^2)-Q%d)/SUMPRODUCT((F%d:F%d-%s)^2)", r1, rN, med, h+1, r1, rN, med), 1);
  C = pn (C, h+4, 16, "m ="); C = put (C, h+4, 17, 1);
  C = pn (C, h+5, 16, "N+1 ="); C = put (C, h+5, 17, sprintf ("=L%d", h+1));
  C = put (C, h+6, 16, "Error estándar"); C = put (C, h+6, 17, sprintf ("=SQRT(Q%d/(Q%d-(Q%d+1)))", h+1, h+5, h+4), 3);
  C = put (C, h+7, 16, "r"); C = put (C, h+7, 17, sprintf ("=SIGN(M%d)*SQRT(Q%d)", h+5, h+3));
  o = struct ("a0", sprintf ("M%d", h+4), "a1", sprintf ("M%d", h+5), "R2", sprintf ("Q%d", h+3), "EE", sprintf ("Q%d", h+6), "r", sprintf ("Q%d", h+7), "pred", "", "fin", max (rs, h+7));
  if ~ isempty (pred)
    C = pn (C, h+7, 12, sprintf ("Si %s =", xl)); C = put (C, h+7, 13, pred);
    C = pn (C, h+8, 12, "y ="); C = put (C, h+8, 13, sprintf ("=M%d+M%d*M%d", h+4, h+5, h+7), 3);
    o.pred = sprintf ("M%d", h+8); o.fin = max (o.fin, h+8);
  endif
endfunction

function [C, o] = parabola (C, top, r0, N, pred, solo)
  % solo (opcional): struct x,y,tit,xl -> los datos van como numeros en las columnas x|y y las estadisticas se apilan bajo "coef." (hoja mas angosta)
  es_solo = nargin > 5 && isstruct (solo);
  h = top + 1; r1 = h + 1; rN = h + N; rs = rN + 1;
  xl = "X"; if es_solo, xl = solo.xl; endif
  tp = "Parábola"; if es_solo, tp = solo.tit; endif
  C = put (C, top, 1, tp, 2);
  enc = {"i", "x", "y", "x^2", "x^3", "x^4", "x*y", "x^2*y", "P(x)", "error^2", "(y-media)^2"};
  for k = 1:11, C = put (C, h, k, enc{k}, 2); endfor
  if es_solo, cq = 13; cv = 14; hq = h + 9; else, cq = 17; cv = 18; hq = h + 1; endif
  V = L (cv); Lq = L (cq);
  A = arrayfun (@(k) sprintf ("$N$%d", h+5+k), 0:2, "UniformOutput", false); med = sprintf ("$%s$%d", V, hq+1);
  for i = 1:N
    r = r1 + i - 1; q = r0 + i - 1;
    C = put (C, r, 1, i);
    if es_solo, C = put (C, r, 2, solo.x(i)); C = put (C, r, 3, solo.y(i));
    else, C = put (C, r, 2, sprintf ("=$A$%d", q)); C = put (C, r, 3, sprintf ("=$B$%d", q)); endif
    C = put (C, r, 4, sprintf ("=B%d^2", r)); C = put (C, r, 5, sprintf ("=B%d^3", r)); C = put (C, r, 6, sprintf ("=B%d^4", r));
    C = put (C, r, 7, sprintf ("=B%d*C%d", r, r)); C = put (C, r, 8, sprintf ("=D%d*C%d", r, r));
    C = put (C, r, 9, sprintf ("=%s+%s*B%d+%s*D%d", A{1}, A{2}, r, A{3}, r));
    C = put (C, r, 10, sprintf ("=(I%d-C%d)^2", r, r)); C = put (C, r, 11, sprintf ("=(C%d-%s)^2", r, med));
  endfor
  C = put (C, rs, 1, "suma");
  for c = [2 3 4 5 6 7 8 10 11], C = put (C, rs, c, sprintf ("=SUM(%s%d:%s%d)", L(c), r1, L(c), rN)); endfor
  C = put (C, h, 12, "C parábola", 2); C = put (C, h, 15, "b", 2);
  F = {sprintf("=COUNT(B%d:B%d)", r1, rN), sprintf("=B%d", rs), sprintf("=D%d", rs), sprintf("=C%d", rs);
       sprintf("=B%d", rs), sprintf("=D%d", rs), sprintf("=E%d", rs), sprintf("=G%d", rs);
       sprintf("=D%d", rs), sprintf("=E%d", rs), sprintf("=F%d", rs), sprintf("=H%d", rs)};
  for i = 1:3, for j = 1:4, C = put (C, h+i, 11+j, F{i,j}); endfor, endfor
  C = put (C, h+4, 13, "coef.");
  M = sprintf ("L%d:N%d", h+1, h+3); B = sprintf ("O%d:O%d", h+1, h+3);
  for k = 0:2
    C = put (C, h+5+k, 13, sprintf ("a%d", k)); C = put (C, h+5+k, 14, sprintf ("=INDEX(MMULT(MINVERSE(%s),%s),%d,1)", M, B, k+1));
  endfor
  if es_solo
    C = pn (C, rs + 2, 1, sprintf (['="a) P2(%s) = "&TEXT(N%d,"0.0000")&TEXT(N%d,"+0.0000;-0.0000")&"*%s"&TEXT(N%d,"+0.0000;-0.0000")&"*%s^2"'], xl, h+5, h+6, xl, h+7, xl));
  endif
  C = put (C, hq, cq, "Q", 1); C = put (C, hq, cv, sprintf ("=SUM(J%d:J%d)", r1, rN), 1);
  C = put (C, hq+1, cq, "Media de y", 1); C = put (C, hq+1, cv, sprintf ("=AVERAGE(C%d:C%d)", r1, rN), 1);
  C = put (C, hq+2, cq, "R^2", 1);
  C = put (C, hq+2, cv, sprintf ("=(SUMPRODUCT((C%d:C%d-%s)^2)-%s%d)/SUMPRODUCT((C%d:C%d-%s)^2)", r1, rN, med, V, hq, r1, rN, med), 1);
  C = pn (C, hq+3, cq, "m ="); C = put (C, hq+3, cv, 2);
  C = pn (C, hq+4, cq, "N+1 ="); C = put (C, hq+4, cv, sprintf ("=L%d", h+1));
  C = put (C, hq+5, cq, "Error estándar"); C = put (C, hq+5, cv, sprintf ("=SQRT(%s%d/(%s%d-(%s%d+1)))", V, hq, V, hq+4, V, hq+3), 3);
  o = struct ("R2", sprintf ("%s%d", V, hq+2), "EE", sprintf ("%s%d", V, hq+5), "pred", "", "fin", max (rs, hq+7), "a0", sprintf ("N%d", h+5));
  if ~ isempty (pred)
    C = pn (C, hq+6, cq, sprintf ("Si %s =", xl)); C = put (C, hq+6, cv, pred);
    C = pn (C, hq+7, cq, "y ="); C = put (C, hq+7, cv, sprintf ("=%s+%s*%s%d+%s*%s%d^2", A{1}, A{2}, V, hq+6, A{3}, V, hq+6), 3);
    o.pred = sprintf ("%s%d", V, hq+7);
  endif
endfunction

function R = respuestas (id, a, b, c)
  R = {};
  switch id
    case 1
      R = {"Pérdida de peso a los 2.5 meses (modelo más preciso)", sprintf("=IF(%s>%s,%s,%s)", b.R2, a.R2, b.pred, a.pred), 3};
    case 3
      R = {"Nota esperada en Biología con 8.3 en Matemáticas", ["=" a.pred], 3};
    case 6
      R = {"a) Diagrama de dispersión: ver la captura al final (columnas A y B)", "", 0;
           "b) ¿Relación lineal?", sprintf('=IF(ABS(%s)>=0.7,"Sí (r = "&TEXT(%s,"0.0000")&")","Evidencia débil (r = "&TEXT(%s,"0.0000")&")")', a.r, a.r, a.r), 0;
           "c) Triglicéridos con colesterol 6.10", ["=" a.pred], 3;
           "d) % de variación explicada (R^2 x 100)", ["=100*" a.R2], 3};
    case 7
      R = {"a) m", ["=" a.a1], 3; "a) b", ["=" a.a0], 3;
           "b) Calidad del ajuste", sprintf('="R^2 = "&TEXT(%s,"0.0000")&" y r = "&TEXT(%s,"0.0000")&": ajuste "&IF(%s>=0.95,"muy bueno","regular")', a.R2, a.r, a.R2), 0;
           "c) ¿Más temperatura, más solubilidad?", sprintf('=IF(%s>0,"Sí: m = "&TEXT(%s,"0.0000")&" > 0","No: m <= 0")', a.a1, a.a1), 0;
           "d) Error estándar de estimación", ["=" a.EE], 3;
           "d) Y(25) (intervalo de longitud 2 errores estándar, centrado en Y(25))", ["=" a.pred], 3;
           "d) límite inferior (Y-EE)", sprintf("=%s-%s", a.pred, a.EE), 3;
           "d) límite superior (Y+EE)", sprintf("=%s+%s", a.pred, a.EE), 3};
    case 8
      R = {"a) Recta: a0", ["=" a.a0], 3; "a) Recta: a1", ["=" a.a1], 3; "b) Error estándar de estimación", ["=" a.EE], 3;
           "c) % de variación explicada (R^2 x 100)", ["=100*" a.R2], 3};
  endswitch
endfunction

function C = multiple (d)
  x1 = d.x1; x2 = d.x2; y = d.y; N = numel (y); C = cell (1, 1);
  r1 = 5; rN = 4 + N; rs = rN + 1; rm = rs + 2;
  C = put (C, 2, 2, d.titulo, 2);
  C = put (C, 3, 11, "(a0+a1x*x1+a2*x2-yi)^2");
  enc = {"I", "x1i", "x2i", "yi", "X1^2", "x1i*x2i", "X2i^2", "x1i*yi", "x2i*yi", "(P(x)-yi)^2", "(yi -y(med) )^2"};
  for k = 1:11, C = put (C, 4, 1+k, enc{k}, 2); endfor
  for i = 1:N
    r = r1 + i - 1;
    C = put (C, r, 2, i, 1); C = put (C, r, 3, x1(i), 1); C = put (C, r, 4, x2(i), 1); C = put (C, r, 5, y(i), 1);
    C = put (C, r, 6, sprintf ("=C%d^2", r)); C = put (C, r, 7, sprintf ("=C%d*D%d", r, r)); C = put (C, r, 8, sprintf ("=D%d^2", r));
    C = put (C, r, 9, sprintf ("=C%d*E%d", r, r)); C = put (C, r, 10, sprintf ("=D%d*E%d", r, r));
    C = put (C, r, 11, sprintf ("=($O$30+$O$31*C%d+$O$32*D%d-E%d)^2", r, r, r));
    C = put (C, r, 12, sprintf ("=(E%d-$B$%d)^2", r, rm));
  endfor
  for c = [3 4 5 6 7 8 9 10 11 12], C = put (C, rs, c, sprintf ("=SUM(%s%d:%s%d)", L(c), r1, L(c), rN)); endfor
  C = put (C, 11, 14, "Objetivo: y=a0+a1x*x1+a2*x2", 3); C = put (C, 13, 14, "Nodos"); C = put (C, 15, 14, "C", 2);
  M = {sprintf("=COUNT(C%d:C%d)", r1, rN), sprintf("=C%d", rs), sprintf("=D%d", rs);
       "=O16", sprintf("=F%d", rs), sprintf("=G%d", rs);
       "=P16", "=P17", sprintf("=H%d", rs)};
  for i = 1:3, for j = 1:3, C = put (C, 15+i, 13+j, M{i,j}, 1); endfor, endfor
  C = put (C, 20, 14, "b", 2);
  C = put (C, 21, 14, sprintf ("=E%d", rs), 1); C = put (C, 22, 14, sprintf ("=I%d", rs), 1); C = put (C, 23, 14, sprintf ("=J%d", rs), 1);
  C = put (C, 25, 14, "inv( C)", 2);
  % inversa y coeficientes celda por celda (formulas de una celda, sin matriciales de varias celdas)
  for i = 1:3, for j = 1:3
    f = sprintf ("=INDEX(MINVERSE($N$16:$P$18),%d,%d)", i, j);
    C = put (C, 25+i, 13+j, f, 3);
  endfor, endfor
  C = put (C, 30, 14, "a", 2);
  for k = 1:3
    C = put (C, 29+k, 15, sprintf ("=INDEX(MMULT(MINVERSE($N$16:$P$18),$N$21:$N$23),%d,1)", k), 1);
    C = put (C, 29+k, 16, sprintf ("a%d", k-1));
  endfor
  C = put (C, rm, 1, "Media de y"); C = put (C, rm, 2, sprintf ("=AVERAGE(E%d:E%d)", r1, rN));
  C = put (C, rm, 6, "R^2"); C = put (C, rm, 7, sprintf ("=(SUMPRODUCT((E%d:E%d-$B$%d)^2)-SUM(K%d:K%d))/SUMPRODUCT((E%d:E%d-$B$%d)^2)", r1, rN, rm, r1, rN, r1, rN, rm));
  if isfield (d, "resp") && d.resp
  C = put (C, rm+1, 6, "Error estándar"); C = put (C, rm+1, 7, sprintf ("=SQRT(SUM(K%d:K%d)/(N16-3))", r1, rN), 3);
  C = put (C, rm+2, 6, "r"); C = put (C, rm+2, 7, sprintf ("=SQRT(G%d)", rm));
  C = put (C, rm+4, 1, "Me piden:", 2);
  F = {"a0", "=O30"; "a1", "=O31"; "a2", "=O32"; "Error estándar de la estimación", sprintf("=G%d", rm+1); "Coeficiente de correlación r", sprintf("=G%d", rm+2)};
  for i = 1:5, C = put (C, rm+4+i, 1, F{i,1}); C = put (C, rm+4+i, 5, F{i,2}, 3); endfor
  C = put (C, rm+11, 1, sprintf ('="Interpretación: y = "&TEXT(O30,"0.0000")&" + "&TEXT(O31,"0.0000")&"*x1 + "&TEXT(O32,"0.0000")&"*x2; explica el "&TEXT(G%d*100,"0.00")&"%% de la variabilidad de y."', rm));
  endif
endfunction
