% haz9  ->  haz 9
function haz9 ()
  haz ("9");
endfunction
