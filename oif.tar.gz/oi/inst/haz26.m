% haz26  ->  haz 26
function haz26 ()
  haz ("26");
endfunction
