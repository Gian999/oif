% hm_teclear (lineas, n0)  -  escribe el codigo SOLO, una letra por cada tecla que presiones.
%   lineas = comandos (cellstr); n0 = numero del primer prompt (octave:n0>).
%   Cualquier tecla escribe la siguiente letra; al terminar la linea, otra tecla la ejecuta (como Enter) y
%   sigue la siguiente.  Esc (o Ctrl-C) sale.  Variables: OCT_IA_TECLAS=0 -> ejecuta todo sin esperar teclas.
%   Si el terminal no deja leer teclas (GUI de Octave), escribe cada linea completa con Enter.
function completo = hm_teclear (lineas, n0)
  completo = false;
  if nargin < 2 || isempty (n0), n0 = 1; endif
  modo = getenv ("OCT_IA_TECLAS");
  if isempty (modo), modo = "1"; endif
  auto = strcmp (modo, "0");
  gui = false;
  try, gui = isguirunning (); catch, end
  sin_graf = ~ isempty (getenv ("OCT_IA_SINGRAF"));
  n = n0;
  for i = 1:numel (lineas)
    l = lineas{i};
    % sin ; al final para que siempre se vea el resultado (OCT_IA_PUNTOYCOMA=1 los conserva)
    if isempty (getenv ("OCT_IA_PUNTOYCOMA")) && ~ isempty (strtrim (l)) && strtrim (l)(1) ~= '%'
      l = regexprep (l, '[\s;]+$', "");
    endif
    if ~ gui && ~ auto, printf ("octave:%d> ", n); fflush (stdout); endif
    if auto
      printf ("octave:%d> ", n);
      printf ("%s\n", l);
    elseif gui
      % sin lectura de teclas: una tecla = Enter, y se escribe la linea completa
      try, input (sprintf ("octave:%d> %s", n, l), "s"); catch, printf ("octave:%d> %s\n", n, l); end_try_catch
    else
      [ok, quedan] = escribir (l);
      if ~ ok, printf ("\n  (modo teclas detenido)\n"); return; endif
      if ~ esperar (), printf ("\n  (modo teclas detenido)\n"); return; endif
      printf ("\n");
    endif
    ejecutar (l, sin_graf);
    hm_historial (l);
    n = n + 1;
  endfor
  completo = true;
endfunction

function [ok, quedan] = escribir (l)
  % una letra por tecla (se agrupan los bytes de un caracter UTF-8 para no cortarlo)
  ok = true; quedan = 0; k = 1; N = numel (l);
  while k <= N
    if ~ esperar (), ok = false; quedan = N - k + 1; return; endif
    b = double (l(k)); m = 1;
    if b >= 240, m = 4; elseif b >= 224, m = 3; elseif b >= 192, m = 2; endif
    m = min (m, N - k + 1);
    fputs (stdout, l(k:k+m-1)); fflush (stdout);
    k = k + (m);
  endwhile
endfunction

function ok = esperar ()
  % bloquea hasta una tecla; Esc cancela
  k = kbhit ();
  ok = ~ isempty (k) && double (k(1)) ~= 27;
endfunction

function ejecutar (l, sin_graf)
  s = strtrim (l);
  if isempty (s) || s(1) == "%", return; endif
  if sin_graf && ~ isempty (regexp (s, '^(plot|ezplot|hold|figure|axis|grid|legend|title|xlabel|ylabel)(?![A-Za-z0-9_])'))
    return
  endif
  try
    ws_ = warning (); warning ("off", "all");   % avisos de sym con numeros decimales: ensucian la pantalla
    evalin ("base", l);
    warning (ws_);
  catch e
    warning (ws_);
    printf ("error: %s\n", e.message);
  end_try_catch
endfunction
