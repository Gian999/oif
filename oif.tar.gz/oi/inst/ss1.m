% ss1  ->  ss 1
function ss1 ()
  ss (1);
endfunction
