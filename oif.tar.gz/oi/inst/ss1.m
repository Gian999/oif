% ss1 [nota]  ->  ss 1 [nota]
function ss1 (varargin)
  ss (1, varargin{:});
endfunction
