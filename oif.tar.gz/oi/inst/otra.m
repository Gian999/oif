% otra N [nota]  ==  repensar N [nota]
function otra (varargin)
  repensar (varargin{:});
endfunction
