% Metodos directos Ax=b: Cramer, eliminacion gaussiana, sustitucion progresiva/regresiva
% TUS COMANDOS (S5C7):
%   A=[0.3 0.52 1;0.5 1 1.9;0.1 0.3 0.5]; b=[-0.01;0.67;-0.44]; X=inv(A)*b
%   DA=det(A); X1=A; X1(:,1)=b; Dx1=det(X1); x1f=Dx1/DA      % Cramer
%   f1=1/f1(1)*f1; f2=-f2(1)*f1+f2; f3=-f3(1)*f1+f3 ; ...     % eliminacion (filas aumentadas)
%   x3=f3(4)/f3(3); x2=f2(4)-f2(3)*x3; x1=f1(4)-f1(2)*x2-f1(3)*x3   % sustitucion regresiva
% Uso: hm_directos   o   hm_directos("ejemplo")
function hm_directos (ej)
  if nargin && strcmpi (ej, "ejemplo")
    A = [0.3 0.52 1; 0.5 1 1.9; 0.1 0.3 0.5]; b = [-0.01; 0.67; -0.44]; m = 1;
  else
    disp ("  1) Cramer   2) Eliminacion gaussiana (como tus filas f1,f2,f3)   3) Sustitucion progresiva/regresiva");
    m = str2double (strtrim (hm_entrada ("  metodo: ", "s")));
    A = hm_entrada ("A = ", "s"); A = eval (A); b = eval (hm_entrada ("b = ", "s")); b = b(:);
  endif
  n = rows (A);
  dec = hm_entrada ("decimales por paso (Enter = completo): ", "s"); dec = str2double (dec);
  rd = @(v) merge (isnan (dec), v, round (v * 10^dec) / 10^dec);
  switch m
    case 1
      DA = det (A); printf ("DA = %.6g\n", DA);
      for j = 1:n, Aj = A; Aj(:,j) = b; Dj = det (Aj); X(j,1) = rd (Dj / DA); printf ("Dx%d = %.6g   x%d = Dx%d/DA = %.6g\n", j, Dj, j, j, X(j)); endfor
    case 2
      F = [A b]; disp ("matriz aumentada:"); disp (F);
      for j = 1:n
        F(j,:) = rd (F(j,:) / F(j,j)); printf ("f%d = 1/f%d(%d)*f%d\n", j, j, j, j); disp (F(j,:));
        for i = j+1:n, F(i,:) = rd (F(i,:) - F(i,j) * F(j,:)); printf ("f%d = -f%d(%d)*f%d + f%d\n", i, i, j, j, i); disp (F(i,:)); endfor
      endfor
      X = zeros (n, 1);
      for i = n:-1:1, X(i) = rd (F(i,end) - F(i,i+1:n) * X(i+1:n)); printf ("x%d = %.6g\n", i, X(i)); endfor
    case 3
      printf ("A debe ser triangular. Resuelvo segun su forma.\n");
      X = zeros (n, 1);
      if istriu (A), for i = n:-1:1, X(i) = rd ((b(i) - A(i,i+1:n) * X(i+1:n)) / A(i,i)); printf ("x%d = %.6g\n", i, X(i)); endfor
      elseif istril (A), for i = 1:n, X(i) = rd ((b(i) - A(i,1:i-1) * X(1:i-1)) / A(i,i)); printf ("x%d = %.6g\n", i, X(i)); endfor
      else, disp ("  no es triangular: usa la opcion 2"); return; endif
  endswitch
  printf ("\nX = "); disp (X'); printf ("comprobacion A*X-b = "); disp ((A*X - b)');
  assignin ("base", "X", X);
endfunction
