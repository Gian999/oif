% ss N   (o  ss1, ss2, ...)  -  resuelve el ejercicio N del PDF que cargaste con  haz archivo.pdf
%   Escribe el codigo con teclas y, al terminar, guarda el Excel solo. Si el ejercicio es solo de Excel, solo lo guarda.
%   Si la lista marco mal un ejercicio, lo puedes forzar:   ss 2 e   (solo Excel)    ss 2 o   (con codigo de Octave)
function ss (n, modo)
  if nargin < 1, error ("ss: usa  ss 1  (antes carga el PDF con  haz archivo.pdf)"); endif
  if nargin < 2, modo = ""; endif
  if ischar (n), n = str2double (n); endif
  plan = [];
  try, plan = getappdata (0, "oi_plan"); catch, end
  if isempty (plan), error ("ss: primero carga el PDF con  haz archivo.pdf"); endif
  if ! isscalar (n) || isnan (n) || n < 1 || n > numel (plan), error ("ss: elige un ejercicio de 1 a %d", numel (plan)); endif
  e = plan{n};
  if any (strcmpi (modo, {"e", "excel"})), e.tipo = "excel";
  elseif any (strcmpi (modo, {"o", "octave"})), e.tipo = "octave";
  elseif ! isempty (modo), error ("ss: el segundo dato es e (solo Excel) u o (con Octave)"); endif
  octavei (struct ("ejercicio", e));
endfunction
