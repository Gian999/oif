% hm_ocultar ()        quita del historial de comandos (flecha arriba, panel Command History, ~/.octave_hist) el comando del paquete que acabas de
%                      escribir (haz, ss2, anss2, octavei, exportar, repensar, h, oifs ...), para que solo queden las lineas de codigo.
% hm_ocultar ("todo")  quita TODOS los comandos del paquete que ya estaban en el historial (lo usa  oifs limpiar).
% Octave no trae un borrar-una-linea: se vacia el historial (history -c) y se vuelven a cargar las demas lineas (history -r). El numero del
% prompt (octave:N>) no cambia: lo cuenta Octave aparte; solo se corrige hm_prompt_n (appdata oi_extra).
function q = hm_ocultar (modo)
  q = 0;
  try
    h = history ();
    if isempty (h), return; endif
    h = h(:);
    esp = cellfun (@(s) ~ isempty (regexp (s, '^\s*(haz\d*|ss\d*|anss\d*|octavei|exportar|export|repensar|otra|rehacer|ia|oifs|oif_setup)(\s.*|\(.*|;.*)?$', "once")) ...
                        || ~ isempty (regexp (s, '^\s*h\s*;?\s*$', "once")), h);
    if nargin >= 1 && strcmpi (modo, "todo")
      marca = esp;
    else
      marca = false (size (esp)); k = numel (h);
      while k >= 1 && esp(k), marca(k) = true; k = k - 1; endwhile
    endif
    q = sum (marca);
    if q == 0, return; endif
    % cuantas de las quitadas cuenta hm_prompt_n (las de esta sesion: despues del ultimo encabezado "# Octave ...")
    ini = find (strncmp (h, "# Octave ", 9));
    if isempty (ini), ini = 0; else, ini = ini(end); endif
    de_sesion = sum (marca(ini+1:end));
    keep = h(~ marca);
    history ("-c");
    if ~ isempty (keep)
      f = [tempname() ".txt"];
      fid = fopen (f, "w"); fprintf (fid, "%s\n", keep{:}); fclose (fid);
      history ("-r", f);
      delete (f);
    endif
    if de_sesion > 0
      ex = getappdata (0, "oi_extra"); if isempty (ex), ex = 0; endif
      setappdata (0, "oi_extra", ex - de_sesion);
    endif
  catch
  end_try_catch
endfunction
