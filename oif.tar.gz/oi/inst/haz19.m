% haz19  ->  haz 19
function haz19 ()
  haz ("19");
endfunction
