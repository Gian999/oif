% haz5  ->  haz 5
function haz5 ()
  haz ("5");
endfunction
