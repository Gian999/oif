% hm_derivar (expr, var)  -  derivada simbolica (texto) de una expresion en las variables x,y,z... (solo + - * / ^ y exp, sin, cos, tan, log, ln, sqrt, atan).
% Devuelve el texto de la derivada ya simplificada (ej. hm_derivar("x^2+y^2-z","x") -> "2*x").  Si no sabe derivar algo, da error.
% Lo usa hm_ej_xlsx para comprobar (y corregir) el jacobiano que escribe la IA, sin depender de ella.
function s = hm_derivar (expr, v)
  ast = analizar (strtrim (expr));
  s = texto (deriv (ast, v), 0);
endfunction

% ---------- analizador:  nodos {tipo, ...} ----------
function ast = analizar (e)
  t = tokens (e); pos = 1;
  [ast, pos] = suma (t, pos);
  if pos <= numel (t), error ("hm_derivar: sobra '%s' en la expresion", t{pos}); endif
endfunction

function t = tokens (e)
  t = {}; i = 1; n = numel (e);
  while i <= n
    c = e(i);
    if isspace (c), i = i + 1; continue; endif
    if isdigit (c) || (c == "." && i < n && isdigit (e(i+1)))
      m = regexp (e(i:end), '^(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?', "match", "once");
      t{end+1} = m; i = i + (numel (m));
    elseif isletter (c) || c == "_"
      m = regexp (e(i:end), '^[A-Za-z_][A-Za-z_0-9]*', "match", "once");
      t{end+1} = m; i = i + (numel (m));
    elseif c == "*" && i < n && e(i+1) == "*"
      t{end+1} = "^"; i = i + (2);
    elseif any (c == "+-*/^(),")
      t{end+1} = c; i = i + 1;
    else
      error ("hm_derivar: caracter no valido '%s'", c);
    endif
  endwhile
endfunction

function [a, p] = suma (t, p)
  [a, p] = producto (t, p);
  while p <= numel (t) && any (strcmp (t{p}, {"+", "-"}))
    op = t{p}; [b, p] = producto (t, p + 1);
    a = {merge(strcmp (op, "+"), "add", "sub"), a, b};
  endwhile
endfunction

function [a, p] = producto (t, p)
  [a, p] = unario (t, p);
  while p <= numel (t) && any (strcmp (t{p}, {"*", "/"}))
    op = t{p}; [b, p] = unario (t, p + 1);
    a = {merge(strcmp (op, "*"), "mul", "div"), a, b};
  endwhile
endfunction

function [a, p] = unario (t, p)
  if p <= numel (t) && strcmp (t{p}, "-")
    [b, p] = unario (t, p + 1); a = {"neg", b};
  elseif p <= numel (t) && strcmp (t{p}, "+")
    [a, p] = unario (t, p + 1);
  else
    [a, p] = potencia (t, p);
  endif
endfunction

function [a, p] = potencia (t, p)
  [a, p] = atomo (t, p);
  if p <= numel (t) && strcmp (t{p}, "^")
    [b, p] = unario (t, p + 1);          % asociativa a la derecha; el exponente puede llevar signo
    a = {"pow", a, b};
  endif
endfunction

function [a, p] = atomo (t, p)
  if p > numel (t), error ("hm_derivar: expresion incompleta"); endif
  w = t{p};
  if ~ isempty (regexp (w, '^(\d|\.)'))
    a = {"num", str2double(w)}; p = p + 1;
  elseif strcmp (w, "(")
    [a, p] = suma (t, p + 1);
    if p > numel (t) || ~ strcmp (t{p}, ")"), error ("hm_derivar: falta )"); endif
    p = p + 1;
  elseif isletter (w(1)) || w(1) == "_"
    if p < numel (t) && strcmp (t{p+1}, "(")
      [b, p] = suma (t, p + 2);
      if p > numel (t) || ~ strcmp (t{p}, ")"), error ("hm_derivar: falta ) en %s(", w); endif
      p = p + 1; a = {"fn", lower(w), b};
    elseif strcmpi (w, "pi")
      a = {"num", pi}; p = p + 1;
    else
      a = {"var", w}; p = p + 1;
    endif
  else
    error ("hm_derivar: no esperaba '%s'", w);
  endif
endfunction

% ---------- constructores que simplifican ----------
function r = esnum (a, v), r = strcmp (a{1}, "num") && (nargin < 2 || a{2} == v); endfunction

function r = c_add (a, b)
  if esnum (a, 0), r = b; elseif esnum (b, 0), r = a;
  elseif esnum (a) && esnum (b), r = {"num", a{2} + b{2}};
  else, r = {"add", a, b}; endif
endfunction

function r = c_sub (a, b)
  if esnum (b, 0), r = a; elseif esnum (a, 0), r = c_neg (b);
  elseif esnum (a) && esnum (b), r = {"num", a{2} - b{2}};
  else, r = {"sub", a, b}; endif
endfunction

function r = c_neg (a)
  if esnum (a), r = {"num", -a{2}}; elseif strcmp (a{1}, "neg"), r = a{2};
  else, r = {"neg", a}; endif
endfunction

function r = c_mul (a, b)
  if esnum (a, 0) || esnum (b, 0), r = {"num", 0};
  elseif esnum (a, 1), r = b; elseif esnum (b, 1), r = a;
  elseif esnum (a, -1), r = c_neg (b); elseif esnum (b, -1), r = c_neg (a);
  elseif esnum (a) && esnum (b), r = {"num", a{2} * b{2}};
  elseif esnum (b) && ~ esnum (a), r = {"mul", b, a};          % el numero primero:  2*x
  else, r = {"mul", a, b}; endif
endfunction

function r = c_div (a, b)
  if esnum (a, 0), r = {"num", 0}; elseif esnum (b, 1), r = a;
  elseif esnum (a) && esnum (b) && b{2} ~= 0 && a{2} / b{2} == round (a{2} / b{2}), r = {"num", a{2} / b{2}};
  else, r = {"div", a, b}; endif
endfunction

function r = c_pow (a, b)
  if esnum (b, 0), r = {"num", 1}; elseif esnum (b, 1), r = a;
  elseif esnum (a) && esnum (b), r = {"num", a{2} ^ b{2}};
  else, r = {"pow", a, b}; endif
endfunction

function r = c_fn (f, a), r = {"fn", f, a}; endfunction

% ---------- ¿depende de v? ----------
function r = dep (a, v)
  switch a{1}
    case "num", r = false;
    case "var", r = strcmp (a{2}, v);
    case "neg", r = dep (a{2}, v);
    case "fn", r = dep (a{3}, v);
    otherwise, r = dep (a{2}, v) || dep (a{3}, v);
  endswitch
endfunction

% ---------- derivada ----------
function d = deriv (a, v)
  if ~ dep (a, v), d = {"num", 0}; return; endif
  switch a{1}
    case "var", d = {"num", 1};
    case "neg", d = c_neg (deriv (a{2}, v));
    case "add", d = c_add (deriv (a{2}, v), deriv (a{3}, v));
    case "sub", d = c_sub (deriv (a{2}, v), deriv (a{3}, v));
    case "mul"
      d = c_add (c_mul (deriv (a{2}, v), a{3}), c_mul (a{2}, deriv (a{3}, v)));
    case "div"
      u = a{2}; w = a{3};
      if ~ dep (w, v), d = c_div (deriv (u, v), w);
      else, d = c_div (c_sub (c_mul (deriv (u, v), w), c_mul (u, deriv (w, v))), c_pow (w, {"num", 2})); endif
    case "pow"
      b = a{2}; e = a{3};
      if ~ dep (e, v)
        if esnum (e), ne = {"num", e{2} - 1}; else, ne = c_sub (e, {"num", 1}); endif
        d = c_mul (c_mul (e, c_pow (b, ne)), deriv (b, v));
      elseif ~ dep (b, v)
        d = c_mul (c_mul (a, c_fn ("log", b)), deriv (e, v));
      else
        d = c_mul (a, c_add (c_mul (deriv (e, v), c_fn ("log", b)), c_div (c_mul (e, deriv (b, v)), b)));
      endif
    case "fn"
      f = a{2}; u = a{3}; du = deriv (u, v);
      switch f
        case "sin", d = c_mul (c_fn ("cos", u), du);
        case "cos", d = c_neg (c_mul (c_fn ("sin", u), du));
        case "tan", d = c_div (du, c_pow (c_fn ("cos", u), {"num", 2}));
        case "exp", d = c_mul (a, du);
        case {"log", "ln"}, d = c_div (du, u);
        case "sqrt", d = c_div (du, c_mul ({"num", 2}, a));
        case "atan", d = c_div (du, c_add ({"num", 1}, c_pow (u, {"num", 2})));
        otherwise, error ("hm_derivar: no se derivar %s()", f);
      endswitch
  endswitch
endfunction

% ---------- texto (parentesis solo donde hacen falta) ----------
% prec: 0 suma/resta, 1 producto/cociente, 2 negativo, 3 potencia, 4 atomo
function s = texto (a, ctx)
  switch a{1}
    case "num"
      s = num (a{2}); if a{2} < 0 && ctx >= 2, s = ["(" s ")"]; endif
    case "var", s = a{2};
    case "neg"
      s = ["-" texto(a{2}, 2)]; if ctx >= 2, s = ["(" s ")"]; endif
    case "add"
      s = [texto(a{2}, 0) "+" texto(a{3}, 0)]; if ctx >= 1, s = ["(" s ")"]; endif
    case "sub"
      s = [texto(a{2}, 0) "-" texto(a{3}, 1)]; if ctx >= 1, s = ["(" s ")"]; endif
    case "mul"
      s = [texto(a{2}, 1) "*" texto(a{3}, 2)]; if ctx >= 3, s = ["(" s ")"]; endif
    case "div"
      s = [texto(a{2}, 1) "/" texto(a{3}, 3)]; if ctx >= 3, s = ["(" s ")"]; endif
    case "pow"
      s = [texto(a{2}, 3) "^" texto(a{3}, 3)];
    case "fn"
      s = sprintf ("%s(%s)", a{2}, texto (a{3}, 0));
  endswitch
endfunction

function s = num (v)
  if v == round (v) && abs (v) < 1e15, s = sprintf ("%d", v); else, s = sprintf ("%.15g", v); endif
endfunction
