% haz18  ->  haz 18
function haz18 ()
  haz ("18");
endfunction
