% ss12 [nota]  ->  ss 12 [nota]
function ss12 (varargin)
  ss (12, varargin{:});
endfunction
