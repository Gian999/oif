% ss12  ->  ss 12
function ss12 ()
  ss (12);
endfunction
