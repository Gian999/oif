% r = hm_validar (L, chk)  -  ejecuta las lineas de codigo (celda de comandos) en un espacio AISLADO, sin tocar tu sesion, y dice si algo falla.
%   L     celda de lineas (un comando completo por linea)
%   chk   opcional: lo que devuelve hm_octave_plantilla ({linea, var, valor}); tras ejecutar esa linea se compara la variable con el valor esperado
% r.ok         true si ninguna linea dio error (y los valores esperados coinciden)
% r.validado   false si no se pudo comprobar (por ejemplo falta el paquete symbolic): no es una falla del codigo
% r.fallas     celda de {numero de linea, texto de la linea, mensaje}  (se detiene en la primera)
% r.nan        celda de {numero de linea, texto} de las lineas cuya salida tiene NaN o Inf
% r.avisos     celda de textos (no se pudo comprobar con symbolic, etc.)
% r.omitidas   lineas que NO se ejecutaron (peligrosas o bloques de varias lineas)
% r.salidas    celda con lo que imprimio cada linea
% Nada de esto toca archivos, carpetas ni ventanas tuyas: las lineas peligrosas (system, delete, fopen, cd, clear, close...) NO se ejecutan.
function r = hm_validar (L, chk)
  if nargin < 2, chk = struct ("linea", {}, "var", {}, "valor", {}); endif
  g_ = hm_silenciar ();
  r = struct ("ok", true, "validado", true, "fallas", {{}}, "avisos", {{}}, "nan", {{}}, "salidas", {{}}, "omitidas", {{}});
  r.salidas = cell (1, numel (L));
  % estado global que el codigo podria cambiar: se restaura al salir
  op0 = output_precision (); fm0 = ""; sp0 = "";
  try, [fm0, sp0] = format (); catch, end
  fv0 = ""; try, fv0 = get (0, "defaultfigurevisible"); catch, end
  fig0 = []; try, fig0 = findall (0, "type", "figure"); catch, end
  rest = onCleanup (@() restaurar (op0, fm0, sp0, fv0, fig0));
  try, set (0, "defaultfigurevisible", "off"); catch, end
  % la matriz singular debe ser un error (si no, solo saldria un aviso que no vemos)
  for id = {"Octave:singular-matrix", "Octave:nearly-singular-matrix"}, try, warning ("error", id{1}); catch, end, endfor
  r = correr (L, chk, r);
endfunction

function restaurar (op0, fm0, sp0, fv0, fig0)
  g2_ = hm_silenciar ();     % esta limpieza corre al salir, cuando el silenciador de arriba ya pudo restaurarse
  try, output_precision (op0); catch, end
  try, if ~ isempty (fm0), format (fm0); if ~ isempty (sp0), format (sp0); endif, endif, catch, end
  try, if ~ isempty (fv0), set (0, "defaultfigurevisible", fv0); endif, catch, end
  try
    f = findall (0, "type", "figure");
    for h = f(:)', if ~ any (h == fig0), close (h); endif, endfor
  catch
  end_try_catch
endfunction

% Todo el codigo del estudiante corre aqui dentro (espacio de trabajo propio); los nombres internos son raros para no chocar.
function oi_r__ = correr (oi_L__, oi_chk__, oi_r__)
  oi_peli__ = '^\s*(system|shell_cmd|unix|dos|delete|unlink|rmdir|rename|movefile|copyfile|fopen|fclose|fwrite|fputs|fdisp|save|load|urlread|urlwrite|webread|webwrite|exit|quit|input|keyboard|cd|chdir|mkdir|pause|clear|clearvars|close|clc|more|diary|dbstop|evalin|assignin|eval|evalc|run|source|addpath|rmpath|setenv|putenv|pkg\s+(install|uninstall|update|unload))\>';
  oi_peli2__ = '\<(system|shell_cmd|unlink|rmdir|delete|movefile|copyfile|urlread|urlwrite|webread|webwrite|fopen|exit|quit|input|keyboard|evalin|assignin)\s*\(';
  oi_multi__ = '^\s*(while|for|do|if|switch|function|try|parfor)\>';
  for oi_i__ = 1:numel (oi_L__)
    oi_l__ = strtrim (oi_L__{oi_i__});
    if isempty (oi_l__) || oi_l__(1) == "%" || oi_l__(1) == "#", continue; endif
    if ~ isempty (regexp (oi_l__, oi_peli__, "once")) || ~ isempty (regexp (oi_l__, oi_peli2__, "once"))
      oi_r__.omitidas{end+1} = oi_l__; continue;
    endif
    if ~ isempty (regexp (oi_l__, oi_multi__, "once"))
      oi_r__.omitidas{end+1} = oi_l__; continue;      % bloques de varias lineas: el programa los teclea tal cual, no se prueban aqui
    endif
    try
      oi_out__ = evalc (oi_l__);
      oi_r__.salidas{oi_i__} = oi_out__;
    catch oi_err__
      oi_msg__ = strtok (oi_err__.message, "\n");
      oi_simb__ = ~ isempty (regexp (oi_l__, '^(pkg load symbolic|syms\>)', "once")) || ~ isempty (regexp (oi_msg__, 'symbolic|sympy|python|OctSymPy', "ignorecase", "once"));
      if oi_simb__ && ~ isempty (regexp (oi_msg__, 'package|symbolic|python|sympy|OctSymPy|undefined', "ignorecase", "once")) && ~ isempty (regexp (oi_l__, 'syms|pkg|sym\s*\(|subs|jacobian|diff', "once"))
        oi_r__.validado = false;
        oi_r__.avisos{end+1} = sprintf ("no pude comprobar con symbolic (%s)", oi_msg__);
        return
      endif
      oi_r__.ok = false;
      oi_r__.fallas{end+1} = {oi_i__, oi_l__, oi_msg__};
      return
    end_try_catch
    % NaN / Inf en lo que imprimio la linea
    if ~ isempty (regexp (oi_out__, '\<(NaN|Inf|zoo|nan|inf)\>', "once"))
      oi_r__.nan{end+1} = {oi_i__, oi_l__};
    endif
    % valores esperados que se comprueban justo despues de esta linea (tolerancia 1e-5: subs de symbolic convierte los decimales a racionales y arrastra ~1e-8)
    for oi_c__ = 1:numel (oi_chk__)
      if oi_chk__(oi_c__).linea ~= oi_i__, continue; endif
      if ~ exist (oi_chk__(oi_c__).var, "var")
        oi_r__.ok = false; oi_r__.fallas{end+1} = {oi_i__, oi_l__, sprintf("no quedo definida la variable %s", oi_chk__(oi_c__).var)}; return
      endif
      oi_v__ = eval ([oi_chk__(oi_c__).var ";"]); oi_e__ = oi_chk__(oi_c__).valor;
      if numel (oi_v__) ~= numel (oi_e__) || any (abs (double (oi_v__(:)) - oi_e__(:)) > 1e-5 * (1 + abs (oi_e__(:))))
        oi_r__.ok = false;
        oi_r__.fallas{end+1} = {oi_i__, oi_l__, sprintf("%s no da lo esperado (esperado %s)", oi_chk__(oi_c__).var, mat2str (oi_e__(:)', 6))}; return
      endif
    endfor
  endfor
  % codigo de IA sin valores esperados: NaN/Inf se toman como falla (en el generado solo se avisa)
endfunction
