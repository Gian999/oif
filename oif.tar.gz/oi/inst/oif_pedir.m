% s = oif_pedir (prompt)  -  pide un texto en UNA sola linea, sin mostrar lo que escribes (contrasena / clave).
%   Enter termina (y la linea se borra, no queda rastro); Esc deja el texto vacio; Retroceso borra.
%   Si el terminal no deja leer teclas sueltas, usa input normal.
function s = oif_pedir (prompt)
  if nargin < 1, prompt = "  > "; endif
  s = ""; vacios = 0;
  printf ("%s", prompt); fflush (stdout);
  try
    while true
      c = kbhit ();
      if isempty (c)
        vacios = vacios + 1;
        if vacios > 200, error ("oif_pedir: sin teclado"); endif
        continue
      endif
      vacios = 0;
      v = double (c(1));
      if v == 10 || v == 13, break;
      elseif v == 27, s = ""; break;
      elseif v == 8 || v == 127, if ~ isempty (s), s(end) = []; endif
      elseif v >= 32, s(end+1) = c(1);
      endif
    endwhile
    printf ("\r%s\r", blanks (numel (prompt))); fflush (stdout);      % borra la linea del prompt
  catch
    s = input ("", "s");
  end_try_catch
endfunction
