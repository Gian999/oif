% Gauss-Seidel: igual que Jacobi pero usa los valores nuevos al instante
% TUS COMANDOS (clase S3C9):
%   BJ=[0 1/2 -1/2; 0 -1/2 -7/6; 0 0 5/9]      % primera columna de ceros
%   max(abs(eig(BJ)))        % radio espectral < 1  ->  converge
%   C=[-1/2; 11/6; -4/9]; X0=[1;1;1]
%   X1=BJ*X0+C, E1=norm(X1-X0,inf)
%   X2=BJ*X1+C, E2=norm(X2-X1,inf)   ... (repetir hasta que E sea pequeno)
function [T, estado] = hm_gaussseidel (ej, op)
  if nargin < 1, ej = ""; endif
  if nargin < 2, [T, estado] = hm_iterativo ("gs", ej);
  else, [T, estado] = hm_iterativo ("gs", ej, op); endif
endfunction
