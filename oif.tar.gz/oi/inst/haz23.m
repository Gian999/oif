% haz23  ->  haz 23
function haz23 ()
  haz ("23");
endfunction
