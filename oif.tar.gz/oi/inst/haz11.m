% haz11  ->  haz 11
function haz11 ()
  haz ("11");
endfunction
