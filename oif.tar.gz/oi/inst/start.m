% start N  -  igual que  ss N  (nombre anterior)
function start (varargin)
  ss (varargin{:});
endfunction
