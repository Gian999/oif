% anss8 [lo que quieres]  ->  anss 8 [lo que quieres]  (analiza de nuevo el ejercicio 8 con tu nota y lo resuelve)
function anss8 (varargin)
  anss (8, varargin{:});
endfunction
