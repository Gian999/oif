% haz14  ->  haz 14
function haz14 ()
  haz ("14");
endfunction
