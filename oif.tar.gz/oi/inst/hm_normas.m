% Normas, radio espectral y condicionamiento de una matriz
% TUS COMANDOS (clase S2C8):
%   A=[-1 2 0; 5 -3 2; -1 -2 -4]
%   norm(A)  (=norm(A,2))      norm(A,1)      norm(A,inf)
%   eig(A)                     % radio espectral = mayor |autovalor|
%   L=sqrt((-4.4681)^2+(1.1839)^2)   % modulo si el autovalor es complejo
%   cond(A)                    % cond grande = mal condicionada
%   B=[1 2; 1.0001 2]; cond(B)   % ejemplo mal condicionado (5e4)
function hm_normas ()
  A = pedir ("A, ej [-1 2 0; 5 -3 2; -1 -2 -4]: ");
  printf ("\nnorm(A,1)   = %g   (max suma de columnas)\n", norm (A, 1));
  printf ("norm(A)     = %g   (norma 2)\n", norm (A));
  printf ("norm(A,inf) = %g   (max suma de filas)\n", norm (A, inf));
  e = eig (A); printf ("\neig(A) =\n"); disp (e);
  printf ("radio espectral = max(abs(eig(A))) = %g\n", max (abs (e)));
  c = cond (A); printf ("cond(A) = %g  -> %s\n", c, ...
        merge (c > 100, "mal condicionada (pequenos cambios en los datos cambian mucho x)", "bien condicionada"));
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
