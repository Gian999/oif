% haz27  ->  haz 27
function haz27 ()
  haz ("27");
endfunction
