% haz15  ->  haz 15
function haz15 ()
  haz ("15");
endfunction
