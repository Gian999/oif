% haz6  ->  haz 6
function haz6 ()
  haz ("6");
endfunction
