% ss2  ->  ss 2
function ss2 ()
  ss (2);
endfunction
