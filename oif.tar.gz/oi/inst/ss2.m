% ss2 [nota]  ->  ss 2 [nota]
function ss2 (varargin)
  ss (2, varargin{:});
endfunction
