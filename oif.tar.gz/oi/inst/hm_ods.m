% hm_ods (archivo.xlsx)  -  junto al .xlsx deja una copia .ods (LibreOffice), en la misma carpeta, si LibreOffice esta instalado.
% El .xlsx es el principal (abre igual en Excel y en LibreOffice). Desactivar:  setenv("OCT_IA_ODS","0")
function hm_ods (archivo)
  if strcmp (getenv ("OCT_IA_ODS"), "0"), return; endif
  so = buscar_soffice ();
  if isempty (so), return; endif
  archivo = make_absolute_filename (archivo); [d, n] = fileparts (archivo);
  perfil = tempname (); mkdir (perfil);
  lim = onCleanup (@() limpiar (perfil));
  up = strrep (perfil, "\\", "/"); if up(1) != "/", up = ["/" up]; endif
  cmd = sprintf ("%s -env:UserInstallation=file://%s --headless --convert-to ods --outdir %s %s", ...
                 hm_shellquote (so), up, hm_shellquote (d), hm_shellquote (archivo));
  try, [st, ~] = system (cmd); catch, st = 1; end_try_catch
  if st == 0 && exist (fullfile (d, [n ".ods"]), "file")
    printf ("  [%s.ods]\n", n);
  endif
endfunction

function so = buscar_soffice ()
  persistent cache = [];
  if ! isempty (cache), so = cache{1}; return; endif
  so = "";
  cand = {getenv("SOFFICE"), "soffice"};
  for v = {"ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"}
    b = getenv (v{1}); if ! isempty (b), cand{end+1} = fullfile (b, "LibreOffice", "program", "soffice.exe"); endif
  endfor
  cand{end+1} = "/Applications/LibreOffice.app/Contents/MacOS/soffice";
  for i = 1:numel (cand)
    c = cand{i}; if isempty (c), continue; endif
    if any (c == filesep ()) && exist (c, "file") != 2, continue; endif
    try, [st, ~] = system ([hm_shellquote(c) " --version"]); catch, st = 1; end_try_catch
    if st == 0, so = c; break; endif
  endfor
  cache = {so};
endfunction

function limpiar (c)
  try, confirm_recursive_rmdir (false, "local"); rmdir (c, "s"); catch, end_try_catch
endfunction
