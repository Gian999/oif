% anss3 [lo que quieres]  ->  anss 3 [lo que quieres]  (analiza de nuevo el ejercicio 3 con tu nota y lo resuelve)
function anss3 (varargin)
  anss (3, varargin{:});
endfunction
