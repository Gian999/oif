% Metodos iterativos lineales: Jacobi y Gauss-Seidel  (X_{k+1} = B*X_k + C)
% TUS COMANDOS (clases S2C8 / Clase 04):
%   BJ=[0 1/2 -1/2; -1 0 -5/3; -1/3 -1/3 0]; C=[-1/2; 4/3; 0]
%   norm(BJ)  norm(BJ,1)  norm(BJ,inf)      % normas
%   eig(BJ)  ->  radio espectral = mayor |autovalor| < 1  ->  converge
%   X0=[0;0;0]
%   X1=BJ*X0+C ; X2=BJ*X1+C ; X3=BJ*X2+C ...
%   E1=norm(X1-X0,inf)      % criterio: E < 0.001
function [T, estado] = hm_iterativo (metodo, ej, op)
  con_op = nargin >= 3; if ! con_op, op = struct (); endif
  T = []; estado = "sin iterar";
  if nargin < 1, metodo = "jacobi"; endif
  ej = nargin > 1 && strcmp (ej, "ejemplo");
  nombre = merge (strcmp (metodo, "gs"), "Gauss-Seidel", "Jacobi");
  printf ("\n[%s]   X(k+1)=B*X(k)+C\n", upper (nombre));
  texto = {}; orden = [];
  if ej
    modo = 3; A = [2 -1 1; 1 1 3; 3 3 5]; b = [-1; 0; 4];
    printf ("Sistema de ejemplo (tu Clase 04):  2x1-x2+x3=-1 ; x1+x2+3x3=0 ; 3x1+3x2+5x3=4\n");
  else
    printf ("1) tengo A y b (en el orden dado)\n2) ya tengo B y C (como BJ y C en clase)\n3) tengo A y b pero las ecuaciones hay que REORDENAR para converger\n");
    modo = pedir ("opcion [1]: ", 1);
  endif
  if modo == 2
    B = pedir ("B (BJ), ej [0 1/2 -1/2; -1 0 -5/3; -1/3 -1/3 0]: ");
    C = pedir ("C (columna), ej [-1/2; 4/3; 0]: ");
  else
    if ! ej
      A = pedir ("A, ej [2 -1 1; 1 1 3; 3 3 5]: ");
      b = pedir ("b (columna), ej [-1;0;4]: ");
    endif
    if modo == 3
      [A, b, orden] = hm_reordenar (A, b);
      texto = [{sprintf("Reorganizacion: se ordenan las ecuaciones como [%s] (cada incognita de la ecuacion donde su coeficiente es mayor)", num2str (orden))}, despejes(A, b)];
    endif
    b=b(:);
    if ! isnumeric(A) || rows(A)!=columns(A) || numel(b)!=rows(A) || ! all(isfinite([A(:);b]))
      error("hm_iterativo: A cuadrada y b compatible con datos finitos");
    endif
    if any (abs (diag (A)) < 1e-12), disp ("  hay un cero en la diagonal: usa la opcion 3 para reordenar"); return; endif
    D = diag (diag (A)); Lo = tril (A, -1); Up = triu (A, 1);
    if strcmp (metodo, "gs"), B = -((D + Lo) \ Up); C = (D + Lo) \ b;
    else, B = -(D \ (Lo + Up)); C = D \ b; endif
    printf ("\nB =\n"); disp (B); printf ("C =\n"); disp (C);
  endif
  C = C(:);
  if ! isnumeric (B) || rows (B) != columns (B) || numel (C) != rows (B) || ! all (isfinite ([B(:); C]))
    error ("hm_iterativo: B debe ser cuadrada y C una columna compatible, con datos finitos");
  endif
  B(B == 0) = 0; n = rows (B); rho = max (abs (eig (B)));
  printf ("\nnorm(B)=%g  norm(B,1)=%g  norm(B,inf)=%g\n", norm (B), norm (B, 1), norm (B, inf));
  printf ("radio espectral = %g\n", rho);
  if rho < 1, disp ("  radio espectral < 1: CONVERGE");
  else, disp ("  radio espectral >= 1: NO converge (prueba la opcion 3: reordenar ecuaciones)"); endif
  if ej, X = merge (strcmp (metodo, "gs"), ones (n, 1), zeros (n, 1)); tol = 1e-3;
  else
    X = pedir (sprintf ("X0 (columna) [Enter = ceros(%d,1)]: ", n), zeros (n, 1));
    tol = pedir ("tolerancia [Enter = 1e-3]: ", 1e-3);
  endif
  X = X(:);
  if numel (X) != n || ! all (isfinite (X)) || ! isscalar (tol) || ! isfinite (tol) || tol <= 0
    error ("hm_iterativo: revisa dimension de X0 y tolerancia positiva finita");
  endif
  reglas = hm_reglas (op, tol, 300, ! ej && ! con_op);
  tol = reglas.tolerancia;
  printf ("Reglas: decimales=%s; iteraciones=%s; tolerancia=%g\n", mat2str(reglas.decimales), mat2str(reglas.iteraciones), tol);
  % --- los pasos de la miss, para que los copies en tu Octave ---
  printf ("\nPASOS DE CLASE (copialos asi en tu Octave):\n");
  printf ("  %% Metodo de %s\n  BJ=%s\n  C=%s\n", nombre, mat2str (B, 15), mat2str (C, 15));
  printf ("  norm(BJ)\n  norm(BJ,1)\n  norm(BJ,inf)\n  eig(BJ)\n  %% Radio espectral = %.4f %s 1, por lo tanto %s\n", rho, merge (rho < 1, "<", ">="), merge (rho < 1, "converge", "no converge"));
  printf ("  X0=%s\n  X1=BJ*X0+C\n  X2=BJ*X1+C\n  X3=BJ*X2+C\n  E1=norm(X1-X0,inf)\n  E2=norm(X2-X1,inf)   ... (hasta E < %g)\n", mat2str (X(:), 5), tol);
  X0v = X(:);
  printf ("\n   k    X(k)'                                error (norma inf)\n");
  T = [0, X(:)', NaN];
  for k = 1:reglas.limite
    Xn = hm_redondear (B*X + C, reglas.decimales); E = norm (Xn - X, inf);
    printf ("  %3d   %s   %.3e\n", k, sprintf ("%10.5f", Xn'), E);
    T(end+1,:) = [k, Xn(:)', E];
    X = Xn; if (isempty (reglas.iteraciones) && E < tol) || ! all (isfinite (X)), break; endif
  endfor
  ok = E < tol && all (isfinite (X));
  estado = "limite sin tolerancia";
  if ! all (isfinite (X)), estado = "valores no finitos";
  elseif ok, estado = "tolerancia alcanzada";
  elseif ! isempty (reglas.iteraciones), estado = "iteraciones solicitadas completadas";
  endif
  printf ("Estado: %s; iteraciones realizadas=%d\n", estado, rows(T)-1);

  if ! isempty(reglas.decimales)
    printf("  %% En cada paso, ANTES de calcular E:\n  X1=round(X1*10^%d)/10^%d\n",reglas.decimales,reglas.decimales);
  endif
  if ! isempty(reglas.iteraciones), printf("  %% Se realizaron las %d iteraciones solicitadas; la tolerancia se informa al final.\n",reglas.iteraciones); endif
  if ok, printf ("\nsolucion ~ "); else, printf ("\n%s: ultimo valor X = ", merge (all (isfinite (X)), "NO se alcanzo la tolerancia en el limite de iteraciones", "DIVERGIO (valores no finitos)")); endif
  printf ("%.6f  ", X); printf ("\n");
  assignin ("base", "BJ", B); assignin ("base", "C", C); assignin ("base", "X", X);
  disp ("(quedaron en el workspace: BJ, C, X)");
  texto = [texto, {sprintf("BJ = %s", mat2str (B, 4)), sprintf("C = %s", mat2str (C, 4)), ...
                   sprintf("Radio espectral = %.4f %s 1 -> %s", rho, merge (rho < 1, "<", ">="), merge (rho < 1, "converge", "no converge")), ...
                   sprintf("X0 = %s ;  criterio E < %g", mat2str (X0v, 3), tol)}];
  texto{end+1} = merge (ok, sprintf ("Conclusion: solucion aproximada X = %s en %d iteraciones.", mat2str (X, 4), k), sprintf ("Conclusion: tolerancia NO alcanzada (con iteraciones fijas es lo esperado) en %d iteraciones (ultimo X = %s). Revisa el orden de las ecuaciones.", k, mat2str (X, 4)));
  texto{end+1} = sprintf ("Estado: %s; decimales=%s; iteraciones=%s; tolerancia=%g", estado, mat2str(reglas.decimales), mat2str(reglas.iteraciones), tol);
  nom = merge (ej, [lower(strrep (nombre, "-", "")) "_ejemplo"], "");
  if isfield (op, "exportar"), nom = op.exportar; endif
  if isequal (nom, false), return; endif
  if isempty (nom), nom = strtrim (hm_entrada ("exportar en el formato de tus hojas (formulas vivas)? Enter = no, o nombre (ej. gs1): ", "s")); endif
  if ! isempty (nom)
    ff = @(j, prev, cur) fila_lineal (B(j,:), C(j), prev);
    hm_bloques_vivo (nom, ["Resolucion metodo de " lower(nombre)], T(1,2:end-1)', ff, texto, rows (T) - 1, "inf", reglas.decimales);
  endif
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction

function exportar_bloques (nombre, titulo, hdrE, T, texto)
  % Formato de tus hojas: A3 titulo | notas en B | G7:I7 = I, Xi, E | un bloque de filas por iteracion
  if isempty (nombre)
    nombre = strtrim (hm_entrada ("exportar en el formato de tus hojas de Excel/ODS? Enter = no, o escribe un nombre (ej. gs1): ", "s"));
    if isempty (nombre), return; endif
  endif
  n = columns (T) - 2; K = rows (T);
  Cl = cell (max (8 + K*n + 1, 6 + numel (texto)), 9);
  Cl{3,1} = titulo;
  for i = 1:numel (texto), Cl{4+i,2} = texto{i}; endfor
  Cl{7,7} = "I"; Cl{7,8} = "Xi"; Cl{7,9} = hdrE;
  for i = 1:K
    r = 8 + (i-1)*n; Cl{r,7} = T(i,1);
    for j = 1:n, Cl{r+j-1,8} = round (T(i,1+j) * 1e6) / 1e6; endfor
    if i > 1 && ! isnan (T(i,end)), Cl{r,9} = T(i,end); endif
  endfor
  arch = [nombre ".csv"]; fid = fopen (arch, "w");
  fprintf (fid, "I,%s,E\n", strjoin (arrayfun (@(i) sprintf ("x%d", i), 1:n, "UniformOutput", false), ","));
  fclose (fid); dlmwrite (arch, T, "-append", "precision", "%.10g");
  try
    pkg load io; xlswrite ([nombre ".xlsx"], Cl); odswrite ([nombre ".ods"], Cl);
    printf ("  guardado en %s : %s.xlsx  y  %s.ods  (columnas I | Xi | E, como tus hojas)\n", pwd, nombre, nombre);
  catch
    printf ("  guardado %s (faltan el paquete io o Java para .xlsx/.ods; abre el .csv)\n", fullfile (pwd, arch));
  end_try_catch
endfunction

function L = despejes (A, b)
  n = rows (A); L = cell (1, n);
  for i = 1:n
    t = sprintf ("x%d = %s", i, num2str (b(i) / A(i,i), 6));
    for j = [1:i-1, i+1:n]
      c = -A(i,j) / A(i,i);
      if c != 0, t = [t sprintf(" %s %s*x%d", merge (c < 0, "-", "+"), num2str (abs (c), 6), j)]; endif
    endfor
    L{i} = t;
  endfor
endfunction

function f = fila_lineal (Bj, Cj, prev)
  % Mismo orden que B*X+C: primero el producto, despues la constante.
  t = {};
  for m = 1:numel (Bj), if Bj(m) != 0, t{end+1}=sprintf("(%.17g)*%s",Bj(m),prev{m}); endif, endfor
  if isempty(t), f=sprintf("(%.17g)",Cj);
  else, f=["(" strjoin(t,"+") ")+(" sprintf("%.17g",Cj) ")"]; endif
endfunction
