% anss9 [lo que quieres]  ->  anss 9 [lo que quieres]  (analiza de nuevo el ejercicio 9 con tu nota y lo resuelve)
function anss9 (varargin)
  anss (9, varargin{:});
endfunction
