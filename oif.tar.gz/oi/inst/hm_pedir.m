% v = hm_pedir (texto, def)  -  pide un dato (matriz, vector, numero) y lo evalua.
%   Acepta lo que escribas en Octave ([2 -1; 1 3], 0:5, pi/2, A ...) o una tabla de un archivo:
%       excel datos.xlsx B4:D9      (tambien .ods o .csv;  3er dato = hoja)
%   Si dejas vacio y hay def, devuelve def.   hm_pedir ("@valor", "texto") evalua el texto sin preguntar.
function v = hm_pedir (txt, def)
  if strcmp (txt, "@valor")
    v = valor (def);
    return
  endif
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      v = valor (s);
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = valor (s)
  if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
    v = leer_tabla (s);
  else
    v = evalin ("base", s);
  endif
endfunction

function v = leer_tabla (s)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ~ isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction
