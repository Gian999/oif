% oif_setup  -  guarda UNA vez tu clave de Claude (API Console) para que octavei la use primero.
%   oif_setup            -> te la pide (Enter = omitir y usar Codex)
%   oif_setup("sk-ant-...")   oif_setup("borrar")
% La clave queda en un archivo de TU usuario (~/.oif/anthropic_key); no va dentro del paquete.
function oif_setup (k)
  d = fullfile (oif_home (), ".oif"); f = fullfile (d, "anthropic_key"); o = fullfile (d, "omitido");
  b = oif_clave ();
  if nargin < 1 && ! isempty (b)
    for t = 1:3
      pw = input ("  contrasena (Enter = omitir): ", "s");
      if isempty (pw), k = ""; break; endif
      try, k = oif_cripto ("descifrar", b, pw); break; catch, printf ("  contrasena incorrecta\n"); k = ""; if t == 3, return; endif, end_try_catch
    endfor
  elseif nargin < 1, k = strtrim (input ("  clave de Claude (Enter = omitir): ", "s")); endif
  if strcmpi (k, "borrar")
    if exist (f, "file"), delete (f); endif
    if exist (o, "file"), delete (o); endif
    setenv ("ANTHROPIC_API_KEY", ""); printf ("  clave borrada\n"); return
  endif
  if ! exist (d, "dir"), mkdir (d); endif
  if isempty (k)
    fid = fopen (o, "w"); fputs (fid, "1"); fclose (fid); printf ("  ok, usare Codex (oif_setup para poner la clave)\n"); return
  endif
  fid = fopen (f, "w"); fputs (fid, k); fclose (fid);
  if ! ispc (), system (["chmod 600 '" f "'"]); endif
  if exist (o, "file"), delete (o); endif
  setenv ("ANTHROPIC_API_KEY", k); printf ("  clave guardada\n");
endfunction
