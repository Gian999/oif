% oif_cifrar  -  cifra tu clave de Claude con una contrasena. Escribe clave_cifrada.txt (ese texto SI se puede compartir).
%   oif_cifrar                       -> te pide clave y contrasena
function oif_cifrar (clave, pass)
  if nargin < 1, clave = strtrim (oif_pedir ("  clave de Claude: ")); endif
  if nargin < 2, pass = oif_pedir ("  contrasena para cifrarla: "); endif
  b = oif_cripto ("cifrar", clave, pass);
  fid = fopen ("clave_cifrada.txt", "w"); fputs (fid, b); fclose (fid);
  printf ("  listo: clave_cifrada.txt (pasale ese texto a Claude para ponerlo en el paquete)\n");
endfunction
