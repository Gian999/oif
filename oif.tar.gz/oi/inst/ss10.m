% ss10 [nota]  ->  ss 10 [nota]
function ss10 (varargin)
  ss (10, varargin{:});
endfunction
