% ss10  ->  ss 10
function ss10 ()
  ss (10);
endfunction
