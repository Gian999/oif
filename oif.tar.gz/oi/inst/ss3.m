% ss3  ->  ss 3
function ss3 ()
  ss (3);
endfunction
