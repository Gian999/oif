% ss3 [nota]  ->  ss 3 [nota]
function ss3 (varargin)
  ss (3, varargin{:});
endfunction
