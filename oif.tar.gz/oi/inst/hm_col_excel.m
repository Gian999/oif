% Nombre de columna Excel para construir referencias (A, ..., AA, ...).
function s = hm_col_excel (c)
  s = "";
  while c > 0, m=mod(c-1,26); s=[char(65+m) s]; c=floor((c-1)/26); endwhile
endfunction
