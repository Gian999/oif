% haz N   (o  haz1 ... haz30)  -  resuelve el ejercicio de la imagen N (o carga el PDF N) de la carpeta actual.
%   haz examen.pdf  -> lee el PDF (max. 6 paginas), arma la lista de ejercicios y luego:  ss1, ss2, ...
%   Busca N.png (o N.pdf), ejN.png, ejeN.png, ejercicioN.png (tambien .jpg/.jpeg/.webp) en la carpeta actual.
%   haz 3         haz("3")        haz("mi_ejercicio.png")
% Luego escribe la solucion con teclas igual que octavei (exportar guarda el Excel).
% Si algo se ve extrano:  anss N [lo que ves o falta]  (analiza de nuevo y lo resuelve), o  repensar N [nota]  y luego  ssN.
function haz (n)
  g_ = hm_silenciar ();            % sin avisos de Octave mientras corre
  hm_ocultar ();                   % el comando escrito no queda en el historial
  if nargin < 1, error ("haz: usa  haz 1  (busca 1.png, ej1.png, eje1.png ... en la carpeta actual)"); endif
  if isnumeric (n), n = sprintf ("%d", n); endif
  n = strtrim (n);
  f = "";
  if exist (n, "file") == 2 && ~ isempty (regexpi (n, '\.(png|jpe?g|webp|gif)$'))
    f = n;
  elseif exist (n, "file") == 2 && ~ isempty (regexpi (n, '\.pdf$'))
    f = n;
  else
    pre = {"", "ej", "eje", "ejercicio", "ejer", "e"}; ext = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".pdf"};
    L = dir (pwd ()); nom = {L(~ [L.isdir]).name};
    for i = 1:numel (pre)
      for j = 1:numel (ext)
        k = find (strcmpi (nom, [pre{i} n ext{j}]), 1);
        if ~ isempty (k), f = nom{k}; break; endif
      endfor
      if ~ isempty (f), break; endif
    endfor
  endif
  if isempty (f), error ("haz: no encuentro la imagen %s en %s (prueba %s.png o eje%s.png)", n, pwd (), n, n); endif
  if ~ isempty (regexpi (f, '\.pdf$')), octavei (struct ("pdf", make_absolute_filename (f)));
  else, octavei (["@\"" make_absolute_filename(f) "\""]); endif
endfunction
