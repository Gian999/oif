% ss4  ->  ss 4
function ss4 ()
  ss (4);
endfunction
