% ss4 [nota]  ->  ss 4 [nota]
function ss4 (varargin)
  ss (4, varargin{:});
endfunction
