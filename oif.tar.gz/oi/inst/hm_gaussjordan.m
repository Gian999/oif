% Gauss-Jordan (operaciones entre filas) - sistema lineal
% TUS COMANDOS (clase S5C8):
%   f1=[3 -0.1 -0.2 7.85]; f2=[0.1 7 -0.3 -19.3]; f3=[0.3 -0.2 10 71.4]
%   f1=f1/f1(1)              % pivote 1 en la fila 1
%   f2=-f2(1)*f1+f2          % cero debajo del pivote
%   f3=-f3(1)*f1+f3
%   f2=f2/f2(2)              % siguiente pivote
%   f1=-f1(2)*f2+f1 ; f3=-f3(2)*f2+f3
%   f3=f3/f3(3) ; f1=-f1(3)*f3+f1 ; f2=-f2(3)*f3+f2   % queda [I | x]
function hm_gaussjordan ()
  M = pedir ("matriz aumentada [A b], ej [3 -0.1 -0.2 7.85; 0.1 7 -0.3 -19.3; 0.3 -0.2 10 71.4]: ");
  M0 = M; n = rows (M);
  for k = 1:n
    if abs (M(k,k)) < 1e-12
      j = find (abs (M(k+1:n,k)) > 1e-12, 1);
      if isempty (j), disp ("  sin solucion unica"); return; endif
      M([k k+j],:) = M([k+j k],:); printf ("\n  (intercambio f%d con f%d)\n", k, k+j);
    endif
    printf ("\nPaso %d:  f%d=f%d/f%d(%d)\n", k, k, k, k, k);
    M(k,:) = M(k,:) / M(k,k); disp (M);
    for i = [1:k-1, k+1:n]
      printf ("  f%d=-f%d(%d)*f%d+f%d\n", i, i, k, k, i);
      M(i,:) = -M(i,k) * M(k,:) + M(i,:);
    endfor
    disp (M);
  endfor
  x = M(:,end); printf ("\nsolucion x =\n"); disp (x);
  A = M0(:,1:end-1); b = M0(:,end);
  printf ("(comprobacion A*x-b = %g)\n", norm (A*x - b));
  assignin ("base", "x", x);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
