% destino = hm_xlsx_agregar(origen, C, nombre [, destino])
% Agrega UNA hoja nueva (con formulas vivas, formato de tus hojas) a una COPIA de tu libro .xlsx.
% Lo tuyo no se toca: tus hojas, imagenes pegadas, graficos y formulas se copian tal cual (byte a byte);
% el original nunca se modifica. Por defecto la copia se llama  <origen>_oi.xlsx
% Ej: hm_xlsx_agregar("clase.xlsx", C, "Ejercicio 4.2")
function destino = hm_xlsx_agregar (origen, C, nombre, destino)
  if nargin < 3, error ("uso: hm_xlsx_agregar(origen, C, nombre [, destino])"); endif
  origen = make_absolute_filename (origen);
  if ! exist (origen, "file"), error ("hm_xlsx_agregar: no existe %s", origen); endif
  if nargin < 4 || isempty (destino)
    [d, n] = fileparts (origen); destino = fullfile (d, [n "_oi.xlsx"]); k = 1;
    while exist (destino, "file"), k++; destino = fullfile (d, sprintf ("%s_oi_%d.xlsx", n, k)); endwhile
  else
    destino = make_absolute_filename (destino);
  endif
  if strcmp (destino, origen), error ("hm_xlsx_agregar: el destino no puede ser el original (siempre se trabaja sobre una copia)"); endif
  if exist (destino, "file"), error ("hm_xlsx_agregar: %s ya existe; usa otro nombre", destino); endif

  % 1) hoja nueva en un libro temporal (reusa el escritor de hm_xlsx) y la leo
  w = tempname (); mkdir (w); lim = onCleanup (@() limpiar (w));
  tmp = fullfile (w, "nueva.xlsx"); hm_xlsx (tmp, C);
  d1 = fullfile (w, "n"); d2 = fullfile (w, "o");
  try, unzip (tmp, d1); unzip (origen, d2); catch e, error ("hm_xlsx_agregar: no pude descomprimir (%s). En Linux hace falta el programa unzip", strtok (e.message, "\n")); end_try_catch
  hoja = fileread (fullfile (d1, "xl", "worksheets", "sheet1.xml"));
  wb = fileread (fullfile (d2, "xl", "workbook.xml"));
  rl = fileread (fullfile (d2, "xl", "_rels", "workbook.xml.rels"));
  ct = fileread (fullfile (d2, "[Content_Types].xml"));
  st = fileread (fullfile (d2, "xl", "styles.xml"));

  % 2) estilos: agrego 2 fuentes, 1 relleno, 1 borde y 5 formatos al final de los tuyos (los tuyos no cambian)
  [st, nF] = agregar (st, "fonts", '<font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><name val="Arial"/></font>', 2);
  [st, nY] = agregar (st, "fills", '<fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill>', 1);
  [st, nB] = agregar (st, "borders", '<border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border>', 1);
  cen = '<alignment horizontal="center"/>';
  xf = sprintf (['<xf numFmtId="0" fontId="%d" fillId="0" borderId="%d" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">' cen '</xf>' ...
                 '<xf numFmtId="0" fontId="%d" fillId="0" borderId="0" xfId="0" applyFont="1"/>' ...
                 '<xf numFmtId="0" fontId="%d" fillId="%d" borderId="0" xfId="0" applyFont="1" applyFill="1"/>' ...
                 '<xf numFmtId="0" fontId="%d" fillId="%d" borderId="%d" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' cen '</xf>' ...
                 '<xf numFmtId="0" fontId="%d" fillId="0" borderId="0" xfId="0" applyFont="1"/>'], ...
                nF, nB, nF+1, nF, nY, nF, nY, nB, nF);
  [st, nX] = agregar (st, "cellXfs", xf, 5);
  hoja = remapear (hoja, nX);

  % 3) registrar la hoja en el libro
  nombres = regexp (wb, '<sheet [^>]*name="([^"]*)"', "tokens"); nombres = cellfun (@(t) t{1}, nombres, "UniformOutput", false);
  nm = regexprep (nombre, '[\[\]:*?/\\]', " "); nm = strtrim (nm); nm = nm(1:min (end, 31)); if isempty (nm), nm = "Octave"; endif
  base = nm; k = 1;
  while any (strcmpi (esc_xml (nm), nombres)), k++; nm = sprintf ("%s_%d", base(1:min (end, 27)), k); endwhile
  ids = cellfun (@(t) str2double (t{1}), regexp (wb, '<sheet [^>]*sheetId="(\d+)"', "tokens"));
  sid = max ([0 ids]) + 1;
  num = 1; while exist (fullfile (d2, "xl", "worksheets", sprintf ("sheet%d.xml", num)), "file") || ! isempty (strfind (rl, sprintf ("sheet%d.xml", num))), num++; endwhile
  rid = "rIdOctguias1"; ruta = sprintf ("xl/worksheets/sheet%d.xml", num);
  if isempty (strfind (wb, "</sheets>")), error ("hm_xlsx_agregar: workbook.xml no esperado"); endif
  wb = strrep (wb, "</sheets>", sprintf ('<sheet name="%s" sheetId="%d" r:id="%s"/></sheets>', esc_xml (nm), sid, rid));
  if isempty (regexp (wb, 'xmlns:r="', "once")), wb = regexprep (wb, '<workbook ', '<workbook xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ', "once"); endif
  % recalcular al abrir (las formulas nuevas no traen valores guardados)
  if ! isempty (regexp (wb, '<calcPr[^>]*/>', "once"))
    cp = regexp (wb, '<calcPr[^>]*/>', "match", "once"); cp2 = regexprep (cp, '\s+fullCalcOnLoad="[^"]*"', ""); cp2 = strrep (cp2, "/>", ' fullCalcOnLoad="1"/>');
    wb = strrep (wb, cp, cp2);
  elseif ! isempty (strfind (wb, "</definedNames>"))
    wb = strrep (wb, "</definedNames>", '</definedNames><calcPr fullCalcOnLoad="1"/>');
  else
    wb = strrep (wb, "</sheets>", '</sheets><calcPr fullCalcOnLoad="1"/>');
  endif
  rl = strrep (rl, "</Relationships>", sprintf ('<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/></Relationships>', rid, num));
  ct = strrep (ct, "</Types>", sprintf ('<Override PartName="/%s" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>', ruta));

  % 4) reescribir el zip: lo tuyo se copia crudo; solo cambian estos 4 archivos y se agrega la hoja
  nuevos = {"xl/workbook.xml", wb; "xl/_rels/workbook.xml.rels", rl; "[Content_Types].xml", ct; "xl/styles.xml", st; ruta, hoja};
  zip_copiar (origen, destino, nuevos);
  printf ("Hoja \"%s\" agregada en la COPIA: %s\n(tu archivo original no se modifico)\n", nm, destino);
  try, hm_ods (destino); catch, end_try_catch
endfunction

function [s, n0] = agregar (s, tag, xml, cuanto)
  t = regexp (s, ['<' tag '\s+count="(\d+)"'], "tokens", "once");
  if isempty (t) || isempty (strfind (s, ["</" tag ">"])), error ("hm_xlsx_agregar: styles.xml no esperado (%s)", tag); endif
  n0 = str2double (t{1});
  s = regexprep (s, ['(<' tag '\s+count=")\d+(")'], sprintf ('$1%d$2', n0 + cuanto), "once");
  i = strfind (s, ["</" tag ">"]); i = i(1);
  s = [s(1:i-1) xml s(i:end)];
endfunction

function h = remapear (h, nX)
  % formatos propios 1..4 -> nX+0..3 ; celdas sin formato -> nX+4 (Arial plano)
  for k = 4:-1:1, h = strrep (h, sprintf (' s="%d"', k), sprintf (' s="%d"', nX + k - 1)); endfor
  h = regexprep (h, '<c r="([A-Z]+[0-9]+)"(?= t=|>)', sprintf ('<c r="$1" s="%d"', nX + 4));
endfunction

function s = esc_xml (s)
  s = strrep (strrep (strrep (strrep (s, "&", "&amp;"), "<", "&lt;"), ">", "&gt;"), '"', "&quot;");
endfunction

function limpiar (w)
  confirm_recursive_rmdir (false, "local");
  try, rmdir (w, "s"); catch, end_try_catch
endfunction

function zip_copiar (origen, destino, nuevos)
  % copia las entradas del zip original sin tocarlas (comprimidas, con su CRC) y agrega las nuevas "stored"
  fid = fopen (origen, "rb"); b = fread (fid, Inf, "uint8=>uint8")'; fclose (fid);
  u16 = @(p) double (b(p)) + 256 * double (b(p+1));
  u32 = @(p) u16 (p) + 65536 * u16 (p+2);
  p = numel (b) - 21; while p > 0 && ! isequal (b(p:p+3), uint8 ([80 75 5 6])), p--; endwhile
  if p < 1, error ("hm_xlsx_agregar: no es un .xlsx valido (zip)"); endif
  n = u16 (p + 10); cdo = u32 (p + 16) + 1;
  q = cdo; E = struct ("nom", {}, "ini", {}, "reg", {});
  for i = 1:n
    if ! isequal (b(q:q+3), uint8 ([80 75 1 2])), error ("hm_xlsx_agregar: directorio central danado"); endif
    nl = u16 (q + 28); ne = u16 (q + 30); nc = u16 (q + 32);
    E(i).nom = char (b(q+46:q+45+nl)); E(i).ini = u32 (q + 42) + 1; E(i).reg = b(q:q+45+nl+ne+nc);
    q += 46 + nl + ne + nc;
  endfor
  [~, ord] = sort ([E.ini]); fin = zeros (1, n);
  for j = 1:n, i = ord(j); if j < n, fin(i) = E(ord(j+1)).ini - 1; else, fin(i) = cdo - 1; endif, endfor
  out = fopen (destino, "wb"); if out < 0, error ("hm_xlsx_agregar: no pude escribir %s", destino); endif
  cierre = onCleanup (@() fclose (out));
  le = @(v, n) uint8 (arrayfun (@(i) bitand (bitshift (uint64 (v), -8*(i-1)), 255), 1:n));
  off = 0; cen = uint8 ([]); cnt = 0;
  for i = 1:n
    if any (strcmp (E(i).nom, nuevos(:,1))), continue; endif
    dat = b(E(i).ini:fin(i)); fwrite (out, dat, "uint8");
    r = E(i).reg; r(43:46) = le (off, 4); cen = [cen r]; off += numel (dat); cnt++;
  endfor
  persistent T
  if isempty (T)
    T = zeros (1, 256, "uint32");
    for m = 0:255
      c = uint32 (m);
      for k = 1:8, if bitand (c, uint32 (1)), c = bitxor (bitshift (c, -1), uint32 (3988292384)); else, c = bitshift (c, -1); endif, endfor
      T(m+1) = c;
    endfor
  endif
  for i = 1:rows (nuevos)
    nom = uint8 (nuevos{i,1}); dat = uint8 (nuevos{i,2}); crc = uint32 (4294967295);
    for x = dat, crc = bitxor (T(double (bitxor (bitand (crc, uint32 (255)), uint32 (x))) + 1), bitshift (crc, -8)); endfor
    crc = bitxor (crc, uint32 (4294967295)); m = numel (dat);
    h = [uint8([80 75 3 4]) le(20,2) le(0,2) le(0,2) le(0,2) le(33,2) le(crc,4) le(m,4) le(m,4) le(numel(nom),2) le(0,2) nom];
    fwrite (out, h, "uint8"); fwrite (out, dat, "uint8");
    cen = [cen uint8([80 75 1 2]) le(20,2) le(20,2) le(0,2) le(0,2) le(0,2) le(33,2) le(crc,4) le(m,4) le(m,4) le(numel(nom),2) le(0,2) le(0,2) le(0,2) le(0,2) le(0,4) le(off,4) nom];
    off += numel (h) + m; cnt++;
  endfor
  fwrite (out, cen, "uint8");
  fwrite (out, [uint8([80 75 5 6]) le(0,2) le(0,2) le(cnt,2) le(cnt,2) le(numel(cen),4) le(off,4) le(0,2)], "uint8");
  clear cierre;
endfunction
