% haz17  ->  haz 17
function haz17 ()
  haz ("17");
endfunction
