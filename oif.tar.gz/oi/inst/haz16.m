% haz16  ->  haz 16
function haz16 ()
  haz ("16");
endfunction
