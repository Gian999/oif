% hm_xlsx(archivo, C)  escribe un .xlsx con FORMULAS VIVAS (no necesita Java, io ni zip).
% Formula matricial escalar: struct("formula","=...","ref","A1").
% C = celdas: cada elemento puede ser numero, texto, o formula si el texto empieza con "=".
% Ej: C=cell(5,3); C{1,1}="i"; C{2,1}=0; C{2,2}="=A2+1"; hm_xlsx("prueba.xlsx",C)
function hm_xlsx (archivo, C, nombres)
  % Varias hojas:  hm_xlsx(archivo, {C1,C2,...}, {"nombre1","nombre2",...})
  if nargin >= 3
    if ! iscell (C) || ! iscell (nombres) || numel (C) != numel (nombres) || isempty (C), error ("hm_xlsx: hojas y nombres no coinciden"); endif
    if numel (C) > 50, error ("hm_xlsx: maximo 50 hojas"); endif
    escribir_libro (archivo, C, nombres); return;
  endif
  escribir_libro (archivo, {C}, {"Hoja1"});
endfunction

function escribir_libro (archivo, Cs, nombres)
  X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  n = numel (Cs); nm = cell (1, n);
  for k = 1:n
    nm{k} = regexprep (nombres{k}, '[\[\]:*?/\\]', " "); nm{k} = strtrim (nm{k}); nm{k} = nm{k}(1:min (end, 31));
    if isempty (nm{k}), nm{k} = sprintf ("Hoja%d", k); endif
    if any (strcmpi (nm{k}, nm(1:k-1))), nm{k} = sprintf ("%s_%d", nm{k}(1:min (end, 27)), k); endif
  endfor
  ct = ""; sh = ""; rl = ""; f = cell (0, 2);
  for k = 1:n
    f(end+1,:) = {sprintf("xl/worksheets/sheet%d.xml", k), [X '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetFormatPr defaultRowHeight="12.8"/>' anchos_xml(Cs{k}) '<sheetData>' filas_xml(Cs{k}) '</sheetData>' fusiones_xml(Cs{k}) '</worksheet>']};
    ct = [ct sprintf('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>', k)];
    sh = [sh sprintf('<sheet name="%s" sheetId="%d" r:id="rId%d"/>', esc (nm{k}), k, k)];
    rl = [rl sprintf('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>', k, k)];
  endfor
  base = {"[Content_Types].xml", [X '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' ct '</Types>'];
          "_rels/.rels", [X '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'];
          "xl/workbook.xml", [X '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' sh '</sheets><calcPr calcId="124519" calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>'];
          "xl/_rels/workbook.xml.rels", [X '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' rl sprintf('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>', n+1) '</Relationships>'];
          "xl/styles.xml", [X '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="0" fontId="0" fillId="2" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>']};
  zip_guardar (archivo, [base; f]);
endfunction

function filas = filas_xml (C)
  if ! iscell (C) || ndims (C) != 2, error ("hm_xlsx: C debe ser una tabla de celdas"); endif
  [nr, nc] = size (C);
  if nr > 1048576 || nc > 16384, error ("hm_xlsx: excede los limites de Excel"); endif
  filas = ""; [C, S, M] = estilos (C);
  for r = 1:nr
    cel = "";
    for c = 1:nc
      v = C{r,c};
      if isempty (v) && M(r,c), cel = [cel sprintf('<c r="%s" s="%d"/>', [col(c) sprintf("%d", r)], S(r,c))]; continue; endif
      if isempty (v), continue; endif
      est = ""; if S(r,c) > 0, est = sprintf (' s="%d"', S(r,c)); endif
      ref = [col(c) sprintf("%d", r)];
      % Formula matricial OOXML de una celda (compatible con Excel clasico).
      if isstruct (v) && isscalar (v) && isfield (v, "formula") && isfield (v, "ref")
        if ! ischar (v.formula) || isempty (v.formula) || v.formula(1) != "=" || numel(v.formula) < 2 || ! strcmp (v.ref, ref)
          error ("hm_xlsx: formula matricial de una celda invalida en %s", ref);
        endif
        cel = [cel sprintf('<c r="%s"%s><f t="array" ref="%s">%s</f></c>', ref, est, ref, esc(v.formula(2:end)))];
        continue;
      endif
      if ! ischar (v) && (! (isnumeric (v) || islogical (v)) || ! isscalar (v) || ! isreal (v))
        error ("hm_xlsx: dato no escalar real en %s", ref);
      endif
      if ischar (v)
        if rows (v) != 1, error ("hm_xlsx: texto debe ser una fila en %s", ref); endif
        if v(1) == "="
          if numel (v) == 1, error ("hm_xlsx: formula vacia en %s", ref); endif
          cel = [cel sprintf('<c r="%s"%s><f>%s</f></c>', ref, est, esc (v(2:end)))];
        else
          cel = [cel sprintf('<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>', ref, est, esc (v))];
        endif
      elseif islogical (v)
        cel = [cel sprintf('<c r="%s"%s t="b"><v>%d</v></c>', ref, est, v)];
      elseif isnumeric (v) && isinf (v)
        cel = [cel sprintf('<c r="%s"%s t="inlineStr"><is><t>%s</t></is></c>', ref, est, merge (v > 0, "Inf", "-Inf"))];
      elseif isnumeric (v) && isfinite (v)
        cel = [cel sprintf('<c r="%s"%s><v>%.17g</v></c>', ref, est, v)];
      endif
    endfor
    if ! isempty (cel), filas = [filas sprintf('<row r="%d">%s</row>', r, cel)]; endif
  endfor
endfunction

function x = anchos_xml (C)
  % ancho de columna como en tus hojas (11.5 por defecto) pero sin cortar encabezados: solo cuentan filas de tabla (>=2 celdas)
  [nr, nc] = size (C); w = 11.5 * ones (1, nc); C0 = C; [C, S] = estilos (C);
  % ancho: el predeterminado de tus hojas (11.5) en todas las columnas, sin ensanchar por el texto
  % columnas auxiliares ocultas: cualquier celda de la columna que empiece con la marca {h}
  oc = false (1, nc);
  for r = 1:size (C0, 1), for c = 1:size (C0, 2)
    v = C0{r,c}; if ischar (v) && numel (v) >= 3 && strcmp (v(1:3), "{h}"), oc(c) = true; endif
  endfor, endfor
  x = "<cols>";
  for c = 1:nc, x = [x sprintf('<col min="%d" max="%d" width="%.2f" customWidth="1"%s/>', c, c, w(c), merge (oc(c), ' hidden="1"', ""))]; endfor
  x = [x "</cols>"];
endfunction

function s = col (c)
  s = ""; while c > 0, m = mod (c - 1, 26); s = [char(65 + m) s]; c = floor ((c - 1) / 26); endwhile
endfunction

function s = esc (s)
  bytes=uint8(s);
  if ! isequal(bytes,uint8(unicode2native(native2unicode(bytes,"UTF-8"),"UTF-8"))) || ! isempty(strfind(s,char([239 191 190]))) || ! isempty(strfind(s,char([239 191 191])))
    error("hm_xlsx: texto no valido en UTF-8/XML 1.0");
  endif
  % XML 1.0 no admite controles salvo tabulador, LF y CR.
  if any (uint8 (s) < 32 & ! ismember (uint8 (s), [9 10 13]))
    error ("hm_xlsx: texto con caracteres de control no validos en XML");
  endif
  % Secuencias literales _xHHHH_ deben escaparse segun SpreadsheetML.
  s = regexprep (s, '(_x[0-9A-Fa-f]{4}_)', '_x005F$1');
  s = strrep (strrep (strrep (s, "&", "&amp;"), "<", "&lt;"), ">", "&gt;");
endfunction

function zip_guardar (archivo, f)
  % zip "stored" (sin compresion) escrito a mano: funciona igual en Linux y Windows
  persistent T
  if isempty (T)
    T = zeros (1, 256, "uint32");
    for n = 0:255
      c = uint32 (n);
      for k = 1:8
        if bitand (c, uint32 (1)), c = bitxor (bitshift (c, -1), uint32 (3988292384)); else, c = bitshift (c, -1); endif
      endfor
      T(n+1) = c;
    endfor
  endif
  fid = fopen (archivo, "wb");
  if fid < 0, error ("hm_xlsx: no pude abrir %s para escritura", archivo); endif
  cierre = onCleanup (@() fclose (fid));
  off = 0; cen = uint8 ([]);
  le = @(v, n) uint8 (arrayfun (@(i) bitand (bitshift (uint64 (v), -8*(i-1)), 255), 1:n));
  for i = 1:rows (f)
    nom = uint8 (f{i,1}); dat = uint8 (f{i,2}); crc = uint32 (4294967295);
    for b = dat, crc = bitxor (T(double (bitxor (bitand (crc, uint32 (255)), uint32 (b))) + 1), bitshift (crc, -8)); endfor
    crc = bitxor (crc, uint32 (4294967295)); n = numel (dat);
    h = [uint8([80 75 3 4]) le(20,2) le(0,2) le(0,2) le(0,2) le(33,2) le(crc,4) le(n,4) le(n,4) le(numel(nom),2) le(0,2) nom];
    fwrite (fid, h, "uint8"); fwrite (fid, dat, "uint8");
    cen = [cen uint8([80 75 1 2]) le(20,2) le(20,2) le(0,2) le(0,2) le(0,2) le(33,2) le(crc,4) le(n,4) le(n,4) le(numel(nom),2) le(0,2) le(0,2) le(0,2) le(0,2) le(0,4) le(off,4) nom];
    off += numel (h) + n;
  endfor
  fwrite (fid, cen, "uint8");
  fwrite (fid, [uint8([80 75 5 6]) le(0,2) le(0,2) le(rows(f),2) le(rows(f),2) le(numel(cen),4) le(off,4) le(0,2)], "uint8");
  if ferror (fid), error ("hm_xlsx: fallo al escribir %s", archivo); endif
  clear cierre;
endfunction

function [C, S, M] = estilos (C)
  % S: 0 normal, 1 celda de tabla (borde fino + centrado), 2 negrita (titulo), 3 amarillo (resultado), 4 tabla+amarillo.
  % Marcas al inicio de un texto: {b} negrita, {y} amarillo (con borde si es de tabla), {n} sin borde, {k} con borde, {Y} amarillo sin borde, {K} amarillo con borde. Una celda es de tabla si tiene vecino lleno en horizontal Y en vertical.
  [nr, nc] = size (C); S = zeros (nr, nc); marca = zeros (nr, nc); ov = zeros (nr, nc);
  % celda con estilo forzado: struct("v", valor, "s", 0..4)  (0 normal, 1 tabla, 2 negrita, 3 amarillo, 4 tabla+amarillo)
  for r = 1:nr, for c = 1:nc
    v = C{r,c};
    if isstruct (v) && isscalar (v) && isfield (v, "v") && isfield (v, "s"), ov(r,c) = v.s + 1; C{r,c} = v.v; endif
  endfor, endfor
  M = false (nr, nc); fus = false (nr, nc);
  for r = 1:nr, for c = 1:nc
    v = C{r,c};
    if ischar (v) && numel (v) >= 3 && strcmp (v(1:3), "{M}") && c < nc, fus(r,c) = true; C{r,c} = v(4:end); endif
  endfor, endfor
  lleno = ! cellfun (@isempty, C);
  for r = 1:nr, for c = 1:nc
    v = C{r,c};
    while ischar (v) && numel (v) >= 6 && v(1) == "{" && v(3) == "}" && v(4) == "{" && v(6) == "}"
      % marcas dobles ({k}{b}texto): se usa la ultima, salvo que haya negrita
      if v(2) == "b" || v(5) != "b", v = v(4:end); else, v = [v(1:3) v(7:end)]; endif
    endwhile
    if ischar (v) && numel (v) >= 3 && v(1) == "{" && v(3) == "}"
      if v(2) == "b", marca(r,c) = 2; elseif v(2) == "y", marca(r,c) = 3;
      elseif v(2) == "n", marca(r,c) = 5; elseif v(2) == "h", marca(r,c) = 9; elseif v(2) == "k", marca(r,c) = 6; elseif v(2) == "Y", marca(r,c) = 7; elseif v(2) == "K", marca(r,c) = 8; endif
      if marca(r,c), C{r,c} = v(4:end); endif
    endif
  endfor, endfor
  p = false (nr+2, nc+2); p(2:end-1, 2:end-1) = lleno;
  h = p(2:end-1, 1:end-2) | p(2:end-1, 3:end); vv = p(1:end-2, 2:end-1) | p(3:end, 2:end-1);
  tabla = lleno & h & vv;
  S(tabla) = 1;
  S(marca == 2) = 2;
  S(marca == 3 & tabla) = 4; S(marca == 3 & ! tabla) = 3;
  S(marca == 5) = 0; S(marca == 6) = 1; S(marca == 7) = 3; S(marca == 8) = 4;
  S(ov > 0) = ov(ov > 0) - 1;
  [fr, fc] = find (fus);
  for q = 1:numel (fr), M(fr(q), fc(q)+1) = true; S(fr(q), fc(q)+1) = S(fr(q), fc(q)); endfor
endfunction

function x = fusiones_xml (C)
  [nr, nc] = size (C); fus = false (nr, nc);
  for r = 1:nr, for c = 1:nc
    v = C{r,c}; if isstruct (v) && isscalar (v) && isfield (v, "v"), v = v.v; endif
    if ischar (v) && numel (v) >= 3 && strcmp (v(1:3), "{M}") && c < nc, fus(r,c) = true; endif
  endfor, endfor
  [fr, fc] = find (fus); x = "";
  if isempty (fr), return; endif
  for q = 1:numel (fr), x = [x sprintf('<mergeCell ref="%s%d:%s%d"/>', col (fc(q)), fr(q), col (fc(q)+1), fr(q))]; endfor
  x = sprintf ('<mergeCells count="%d">%s</mergeCells>', numel (fr), x);
endfunction
