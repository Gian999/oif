% ss11 [nota]  ->  ss 11 [nota]
function ss11 (varargin)
  ss (11, varargin{:});
endfunction
