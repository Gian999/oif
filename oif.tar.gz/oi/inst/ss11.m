% ss11  ->  ss 11
function ss11 ()
  ss (11);
endfunction
