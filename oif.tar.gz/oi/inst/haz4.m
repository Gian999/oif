% haz4  ->  haz 4
function haz4 ()
  haz ("4");
endfunction
