% Punto fijo, una variable: pasar f(x)=0 a x=g(x) y repetir x=g(x)
% Convergencia: |g'(x0)| < 1.  Si ya tienes x0 en el workspace, lo usa.
%   g=@(x) cos(x); x=0.5; for k=1:100, xn=g(x); if abs(xn-x)<1e-6, break, end, x=xn; end
function hm_puntofijo ()
  eq = "";
  while isempty (eq)
    eq = strrep (input ("1) ecuacion (ej: cos(x)=x  o  x^3+x-1): ", "s"), " ", "");
  endwhile
  [f_str, directo] = parse_eq (eq);
  if evalin ("base", "exist('x0','var')") && isscalar (evalin ("base", "x0"))
    x0 = evalin ("base", "x0"); origen = "tu x0 del workspace";
  else
    x0 = NaN; origen = "";
  endif
  tol = 1e-6; maxit = 100;
  [gs, xi] = elegir (f_str, directo, x0, tol, maxit);
  if isempty (gs)
    [gs, xi] = elegir (f_str, directo, NaN, tol, maxit); origen = "x0 sugerido (el tuyo no converge)";
  elseif isnan (x0), origen = "x0 sugerido"; endif
  if isempty (gs), disp ("  no encontre g(x) que converja; prueba otra forma"); return; endif
  printf ("\n2) despeje:  g(x) = %s\n", gs);
  r = input ("   Enter = aceptar, o escribe tu g(x): ", "s");
  if ! isempty (r), gs = strrep (r, " ", ""); endif
  g = str2func (["@(x) " regexprep(gs, '(?<![.])([*/^])', '.$1')]);
  printf ("\n3) x0 = %g  (%s)\n", xi, origen);
  r = input ("   Enter = aceptar, o escribe otro x0: ", "s");
  if ! isempty (r), xi = str2double (r); endif
  d = abs ((g (xi+1e-6) - g (xi-1e-6)) / 2e-6);
  printf ("\n4) condicion: |g'(x0)| = %.4f  -> %s\n", d, merge (d < 1, "< 1, converge", ">= 1, puede NO converger"));
  printf ("\n5) iteraciones (x = g(x))\n    k        x            error\n");
  x = xi; T = [0 xi NaN];
  for k = 1:maxit
    xn = g (x); e = abs (xn - x);
    printf ("   %2d  %12.8f  %10.2e\n", k, xn, e);
    T(end+1,:) = [k xn e]; x = xn; if e < tol, break; endif
  endfor
  printf ("\nraiz ~ %.8f\n", x);
  assignin ("base", "g", g); assignin ("base", "x0", xi); assignin ("base", "raiz", x);
  printf ("\nA mano seria:\n  g=@(x) %s;\n  x=%g;\n  for k=1:%d, xn=g(x); if abs(xn-x)<%g, break, end, x=xn; end\n", gs, xi, maxit, tol);
  disp ("(quedaron en el workspace: g, x0, raiz)");
  texto = {sprintf("g(x) = %s", gs), sprintf("x0 = %g ; |g'(x0)| = %.4f", xi, d), sprintf("Conclusion: raiz aproximada x=%.8f en %d iteraciones.", x, k)};
  nom = strtrim (input ("exportar en el formato de tus hojas (formulas vivas)? Enter = no, o nombre (ej. pf1): ", "s"));
  if ! isempty (nom)
    hm_bloques_vivo (nom, "Resolucion metodo del punto fijo", xi, @(j, prev, cur) hm_fexcel (gs, "x", prev{1}), texto, rows (T) - 1, "rel");
  endif
endfunction


function [f, directo] = parse_eq (eq)
  directo = false;
  if any (eq == "=")
    p = strsplit (eq, "=");
    if strcmp (p{2}, "x"), f = p{1}; directo = true;
    elseif strcmp (p{1}, "x"), f = p{2}; directo = true;
    else, f = [p{1} "-(" p{2} ")"]; endif
  else
    f = eq;
  endif
endfunction

function [gs, xi, n] = elegir (f, directo, x0, tol, maxit)
  gs = ""; xi = NaN; n = Inf;
  if directo, cand = 1; else cand = [1 -1 0.5 -0.5 0.1 -0.1 0.01 -0.01]; endif
  if isnan (x0), starts = linspace (-10, 10, 201); [~, o] = sort (abs (starts)); starts = starts(o); else starts = x0; endif
  for c = cand
    if directo, s = f; else s = sprintf ("x-(%s)*%g", f, c); endif
    gf = str2func (["@(x) " regexprep(s, '(?<![.])([*/^])', '.$1')]);
    for x1 = starts
      xc = x1; ok = false;
      try
        for k = 1:maxit
          xn = gf (xc);
          if ! isfinite (xn) || abs (xn) > 1e6, break; endif
          if abs (xn - xc) < tol, ok = true; break; endif
          xc = xn;
        endfor
      catch, end
      if ok && k < n, gs = s; xi = x1; n = k; endif
    endfor
  endfor
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (input ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction

function exportar_bloques (nombre, titulo, hdrE, T, texto)
  % Formato de tus hojas: A3 titulo | notas en B | G7:I7 = I, Xi, E | un bloque de filas por iteracion
  if isempty (nombre)
    nombre = strtrim (input ("exportar en el formato de tus hojas de Excel/ODS? Enter = no, o escribe un nombre (ej. gs1): ", "s"));
    if isempty (nombre), return; endif
  endif
  n = columns (T) - 2; K = rows (T);
  Cl = cell (max (8 + K*n + 1, 6 + numel (texto)), 9);
  Cl{3,1} = titulo;
  for i = 1:numel (texto), Cl{4+i,2} = texto{i}; endfor
  Cl{7,7} = "I"; Cl{7,8} = "Xi"; Cl{7,9} = hdrE;
  for i = 1:K
    r = 8 + (i-1)*n; Cl{r,7} = T(i,1);
    for j = 1:n, Cl{r+j-1,8} = round (T(i,1+j) * 1e6) / 1e6; endfor
    if i > 1 && ! isnan (T(i,end)), Cl{r,9} = T(i,end); endif
  endfor
  arch = [nombre ".csv"]; fid = fopen (arch, "w");
  fprintf (fid, "I,%s,E\n", strjoin (arrayfun (@(i) sprintf ("x%d", i), 1:n, "UniformOutput", false), ","));
  fclose (fid); dlmwrite (arch, T, "-append", "precision", "%.10g");
  try
    pkg load io; xlswrite ([nombre ".xlsx"], Cl); odswrite ([nombre ".ods"], Cl);
    printf ("  guardado en %s : %s.xlsx  y  %s.ods  (columnas I | Xi | E, como tus hojas)\n", pwd, nombre, nombre);
  catch
    printf ("  guardado %s (faltan el paquete io o Java para .xlsx/.ods; abre el .csv)\n", fullfile (pwd, arch));
  end_try_catch
endfunction

function L = despejes (A, b)
  n = rows (A); L = cell (1, n);
  for i = 1:n
    t = sprintf ("x%d = %s", i, num2str (b(i) / A(i,i), 6));
    for j = [1:i-1, i+1:n]
      c = -A(i,j) / A(i,i);
      if c != 0, t = [t sprintf(" %s %s*x%d", merge (c < 0, "-", "+"), num2str (abs (c), 6), j)]; endif
    endfor
    L{i} = t;
  endfor
endfunction
