% n = hm_prompt_n ()  -  numero del PROXIMO prompt (octave:n>) en la sesion actual.
% Cuenta los comandos de ESTA sesion: con el historial en memoria (despues del ultimo encabezado "# Octave ...")
% o, si no hay encabezado, con el archivo de historial (la GUI lo va escribiendo comando a comando; la terminal al salir).
% Si no se puede saber, devuelve OCT_IA_N (si existe) o 1.
function n = hm_prompt_n ()
  n = str2double (getenv ("OCT_IA_N"));
  if ~ isnan (n) && n >= 1, return; endif
  n = crudo ();
  ex = 0; try, ex = getappdata (0, "oi_extra"); catch, end
  if isempty (ex), ex = 0; endif
  n = max (1, n - ex);
endfunction

function n = crudo ()
  n = 1;
  try
    h = history ();
    idx = find (strncmp (h, "# Octave ", 9));
    if ~ isempty (idx)
      n = numel (h) - idx(end) + 1;
      return
    endif
    total = 0; sesion = 0;
    f = history_file ();
    if exist (f, "file") == 2
      L = strsplit (fileread (f), "\n");
      L = L(~ cellfun (@isempty, L));
      cab = find (strncmp (L, "# Octave ", 9));
      cmd = ~ strncmp (L, "#", 1);
      total = sum (cmd);
      if isempty (cab), sesion = total; else, sesion = sum (cmd(cab(end)+1:end)); endif
    endif
    if total >= numel (h)
      n = sesion + 1;          % el archivo ya incluye esta sesion (GUI)
    else
      n = numel (h) - total + 1;   % el archivo solo trae sesiones anteriores (terminal)
    endif
  catch
  end_try_catch
endfunction
