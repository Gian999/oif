% Ajuste de curvas (minimos cuadrados) y grafica
% TUS COMANDOS (clase S4C12):
%   x=[0 1 2 3 4 5]'; y=[2.1 7.7 13.6 27.2 40.9 61.1]'     % columnas con '
%   plot(x,y,'*'); xlabel('horas'); ylabel('grados')
%   f=inline('2.4786+2.3593*x+1.861*x^2','x')    % coeficientes del ajuste (a+bx+cx^2)
%   hold on; ezplot(f)
%   (con polyfit sale directo:  p=polyfit(x,y,2))
function hm_ajuste ()
  x = pedir ("x, ej [0 1 2 3 4 5]: "); y = pedir ("y, ej [2.1 7.7 13.6 27.2 40.9 61.1]: ");
  x = x(:); y = y(:);
  n = pedir ("grado del polinomio [Enter = 2]: ", 2);
  p = polyfit (x, y, n);
  yh = polyval (p, x); r2 = 1 - sum ((y - yh).^2) / sum ((y - mean (y)).^2);
  t = ""; for i = 1:numel (p), t = [t sprintf("%+.4f*x^%d ", p(i), n - i + 1)]; endfor
  printf ("\ny = %s\nR^2 = %.4f\n", strrep (t, "*x^0", ""), r2);
  disp ("coeficientes p (de mayor a menor potencia):"); disp (p);
  plot (x, y, "*"); hold on
  xx = linspace (min (x), max (x), 200); plot (xx, polyval (p, xx)); hold off
  xl = hm_entrada ("etiqueta x (Enter = ninguna): ", "s"); if ! isempty (xl), xlabel (xl); endif
  yl = hm_entrada ("etiqueta y (Enter = ninguna): ", "s"); if ! isempty (yl), ylabel (yl); endif
  assignin ("base", "p", p); assignin ("base", "f", @(x) polyval (p, x));
  disp ("(en el workspace: p y f; evalua con f(3))");
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
