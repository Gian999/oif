% anss6 [lo que quieres]  ->  anss 6 [lo que quieres]  (analiza de nuevo el ejercicio 6 con tu nota y lo resuelve)
function anss6 (varargin)
  anss (6, varargin{:});
endfunction
