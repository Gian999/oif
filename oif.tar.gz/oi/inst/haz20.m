% haz20  ->  haz 20
function haz20 ()
  haz ("20");
endfunction
