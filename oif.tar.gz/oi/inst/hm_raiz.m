% Raices de f(x)=0 (1 variable): biseccion, regla falsa, Newton-Raphson, secante, Muller
% TUS COMANDOS (clase 2 y 3):
%   f=inline('exp(-x)+sin(x)-x^2','x'); ezplot(f)          % grafica para hallar el intervalo
%   c0=(a0+b0)/2 ; feval(f,c0)                               % biseccion: signo de f(a)*f(c)
%   m0=b0-(fb0*(b0-a0))/(fb0-fa0)                            % regla falsa
%   x1=x0-feval(f,x0)/feval(df,x0)                           % Newton   (df a mano o con syms/diff)
%   x2=x1-(feval(f,x1)*(x1-x0))/(feval(f,x1)-feval(f,x0))    % secante
%   Ea=abs((x1-x0)/x1)*100                                   % error relativo %
% REGLAS que acepta (para ejercicios con condiciones): decimales (redondea cada paso),
%   tolerancia en %, numero fijo de iteraciones, o formula/metodo impuesto.
% Uso:  hm_raiz   o   hm_raiz("biseccion")  o  hm_raiz("ejemplo")
function hm_raiz (met)
  if nargin == 0
    disp ("  1) biseccion  2) regla falsa  3) Newton-Raphson  4) secante  5) Muller");
    k = str2double (strtrim (input ("  metodo: ", "s")));
  else
    k = find (strncmpi (met, {"bis","reg","new","sec","mul"}, 3));
    if strcmpi (met, "ejemplo"), k = 1; endif
    if isempty (k), k = 1; endif
  endif
  if ! any (k == 1:5), disp ("  (no existe)"); return; endif
  nom = {"Biseccion","Regla falsa","Newton-Raphson","Secante","Muller"}{k};
  ej = nargin && strcmpi (met, "ejemplo");
  if ej
    fs = "exp(-x)+sin(x)-x^2"; a = 1; b = 2; dec = Inf; tol = 1; nfix = 0;
    printf ("  ejemplo de tu clase 2: f=%s en [1,2]\n", fs);
  else
    fs = strtrim (input ("1) f(x) (ej: exp(-x)+sin(x)-x^2): ", "s"));
    fs = strrep (fs, " ", "");
  endif
  f = str2func (["@(x) " regexprep(fs, '(?<![.])([*/^])', '.$1')]);
  if ! ej
    printf ("2) REGLAS del ejercicio (Enter = sin regla)\n");
    dec = pedir_num ("   decimales a usar por paso (ej 4): ", Inf);
    tol = pedir_num ("   detenerse cuando Ea < __ %  (ej 1): ", 0.05);
    nfix = pedir_num ("   o hacer exactamente N iteraciones (Enter = no): ", 0);
  endif
  rd = @(v) merge (isinf (dec), v, round (v * 10^dec) / 10^dec);
  df = []; ds = "";
  switch k
    case {1,2}
      if ! ej, I = pedir_num ("3) intervalo [a b], ej [1 2]: ", [1 2]); a = I(1); b = I(2); endif
      if f(a) * f(b) > 0, disp ("  f(a)*f(b)>0: no hay cambio de signo. Grafica con ezplot y cambia el intervalo."); return; endif
      T = bisfalsa (f, a, b, k, rd, tol, nfix); hdr = {"i","ai","bi", merge(k==1,"ci","mi"), "f(ai)", merge(k==1,"f(ci)","f(mi)"), "f(bi)", "Ea"};
    case 3
      if ! ej
        ds = strtrim (input ("3) f'(x) (Enter = derivada numerica): ", "s"));
        if ! isempty (ds), df = str2func (["@(x) " regexprep(strrep(ds," ",""), '(?<![.])([*/^])', '.$1')]); endif
        x0 = pedir_num ("4) x0: ", 0);
      endif
      if isempty (df), df = @(x) (f (x + 1e-6) - f (x - 1e-6)) / 2e-6; endif
      T = [0 x0 NaN]; x = x0;
      for i = 1:200
        xn = rd (x - f (x) / df (x)); e = abs ((xn - x) / xn) * 100; T(end+1,:) = [i xn e]; x = xn;
        if (nfix && i >= nfix) || (! nfix && e < tol), break; endif
      endfor
      hdr = {"i","Xi","Ea"};
    case 4
      if ! ej, I = pedir_num ("3) x0 y x1, ej [0 0.3]: ", [0 1]); endif
      x0 = I(1); x1 = I(2); T = [0 x0 NaN; 1 x1 NaN];
      for i = 2:200
        fa = f (x0); fb = f (x1);
        xn = rd (x1 - (fb * (x1 - x0)) / (fb - fa)); e = abs ((xn - x1) / xn) * 100; T(end+1,:) = [i xn e]; x0 = x1; x1 = xn;
        if (nfix && i - 1 >= nfix) || (! nfix && e < tol), break; endif
      endfor
      hdr = {"i","Xi","Ea"};
    case 5
      I = pedir_num ("3) x0 x1 x2, ej [4.5 5.5 5]: ", [4.5 5.5 5]); x0 = I(1); x1 = I(2); x2 = I(3);
      T = [0 x2 NaN];
      for i = 1:100
        a_ = ((x1-x2)*(f(x0)-f(x2)) - (x0-x2)*(f(x1)-f(x2))) / ((x0-x2)*(x1-x2)*(x0-x1));
        b_ = ((x0-x2)^2*(f(x1)-f(x2)) - (x1-x2)^2*(f(x0)-f(x2))) / ((x0-x2)*(x1-x2)*(x0-x1));
        c_ = f (x2); d_ = sqrt (b_^2 - 4*a_*c_);
        den = merge (abs (b_ + d_) >= abs (b_ - d_), b_ + d_, b_ - d_);
        x3 = rd (x2 - 2*c_/den); e = abs ((x3 - x2) / x3) * 100; T(end+1,:) = [i real(x3) e];
        x0 = x1; x1 = x2; x2 = x3;
        if (nfix && i >= nfix) || (! nfix && e < tol), break; endif
      endfor
      hdr = {"i","Xi","Ea"};
  endswitch
  printf ("\n%s   f(x)=%s\n", nom, fs);
  printf ("%s\n", strjoin (hdr, "    "));
  for i = 1:rows (T), printf ("  %s\n", strtrim (sprintf ("%12.6g", T(i,:)))); endfor
  r = T(end, merge (k <= 2, 4, 2));
  printf ("\nraiz ~ %.*f   (Ea final = %.4g %%)\n", merge (isinf (dec), 6, dec), r, T(end,end));
  assignin ("base", "f", f); assignin ("base", "raiz", r);
  printf ("(workspace: f, raiz)   Si f(raiz)=%.3g\n", f (r));
  nombre = strtrim (input ("exportar en el formato de tus hojas? Enter = no, o un nombre (ej. bis1): ", "s"));
  if ! isempty (nombre), exportar_raiz (nombre, nom, fs, hdr, T, k, dec, ds); endif
endfunction

function T = bisfalsa (f, a, b, k, rd, tol, nfix)
  T = []; cprev = NaN; fa = f (a); fb = f (b);
  for i = 0:200
    if k == 1, c = rd ((a + b) / 2); else, c = rd (b - (fb * (b - a)) / (fb - fa)); endif
    fc = f (c); e = abs ((c - cprev) / c) * 100;
    T(end+1,:) = [i a b c fa fc fb e];
    if (nfix && i + 1 >= nfix) || (! nfix && ! isnan (e) && e < tol) || fc == 0, break; endif
    if fa * fc > 0, a = c; fa = fc; else, b = c; fb = fc; endif
    cprev = c;
  endfor
endfunction

function v = pedir_num (txt, def)
  s = strtrim (input (txt, "s"));
  if isempty (s), v = def; return; endif
  v = eval (s);
endfunction

function exportar_raiz (nombre, nom, fs, hdr, T, k, dec, ds)
  % Hoja como la tuya (HomeW2nd): titulo en C2, encabezados en fila 3 desde B, FORMULAS VIVAS (no valores)
  n = rows (T); Cl = cell (4 + n + 2, 10); R = @(e) merge (isinf (dec), e, sprintf ("ROUND(%s,%d)", e, dec));
  F = @(ref) ["(" hm_fexcel(fs, "x", ref) ")"];
  Cl{2,3} = sprintf ("%s   f(x) = %s", nom, fs);
  if k <= 2
    for j = 1:8, Cl{3,1+j} = hdr{j}; endfor
    for i = 1:n
      r = 3 + i; p = r - 1; Cl{r,2} = i - 1;
      if i == 1, Cl{r,3} = T(1,2); Cl{r,4} = T(1,3);
      else
        Cl{r,3} = sprintf ("=IF(F%d*G%d>0,E%d,C%d)", p, p, p, p); Cl{r,4} = sprintf ("=IF(F%d*G%d>0,D%d,E%d)", p, p, p, p);
      endif
      if k == 1, Cl{r,5} = ["=" R(sprintf("(C%d+D%d)/2", r, r))];
      else, Cl{r,5} = ["=" R(sprintf("D%d-(H%d*(D%d-C%d))/(H%d-F%d)", r, r, r, r, r, r))]; endif
      Cl{r,6} = ["=" F(sprintf("C%d", r))]; Cl{r,7} = ["=" F(sprintf("E%d", r))]; Cl{r,8} = ["=" F(sprintf("D%d", r))];
      if i > 1, Cl{r,9} = sprintf ("=ABS((E%d-E%d)/E%d)*100", r, p, r); endif
    endfor
    cr = 3 + n; celda = sprintf ("E%d", cr);
  else
    for j = 1:3, Cl{3,1+j} = hdr{j}; endfor
    for i = 1:n
      r = 3 + i; p = r - 1; Cl{r,2} = T(i,1);
      if k == 3 && i > 1
        if isempty (ds), d = sprintf ("((%s)-(%s))/0.000002", F(sprintf("C%d+0.000001", p)), F(sprintf("C%d-0.000001", p)));
        else, d = hm_fexcel (ds, "x", sprintf ("C%d", p)); endif
        Cl{r,3} = ["=" R(sprintf("C%d-(%s)/(%s)", p, F(sprintf("C%d", p)), d))];
      elseif k == 4 && i > 2
        q = p - 1; fp = F(sprintf ("C%d", p)); fq = F(sprintf ("C%d", q));
        Cl{r,3} = ["=" R(sprintf("C%d-(%s*(C%d-C%d))/(%s-%s)", p, fp, p, q, fp, fq))];
      else
        Cl{r,3} = T(i,2);   % valores iniciales (y Muller: valores)
      endif
      if (k == 4 && i > 2) || (k != 4 && i > 1), Cl{r,4} = sprintf ("=ABS((C%d-C%d)/C%d)*100", r, p, r); endif
    endfor
    celda = sprintf ("C%d", 3 + n);
  endif
  Cl{3+n+2,2} = ["Conclusion: la raiz aproximada esta en la celda " celda];
  Cl{3+n+3,2} = ["f(raiz) = "]; Cl{3+n+3,3} = ["=" F(celda)];
  hm_xlsx ([nombre ".xlsx"], Cl);
  arch = [nombre ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, T, "-append", "precision", "%.10g");
  printf ("  guardado en %s : %s.xlsx (con formulas vivas, se recalcula al abrir) y %s.csv\n", pwd, nombre, nombre);
endfunction
