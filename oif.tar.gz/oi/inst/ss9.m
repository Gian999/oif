% ss9  ->  ss 9
function ss9 ()
  ss (9);
endfunction
