% ss9 [nota]  ->  ss 9 [nota]
function ss9 (varargin)
  ss (9, varargin{:});
endfunction
