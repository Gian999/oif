% anss5 [lo que quieres]  ->  anss 5 [lo que quieres]  (analiza de nuevo el ejercicio 5 con tu nota y lo resuelve)
function anss5 (varargin)
  anss (5, varargin{:});
endfunction
