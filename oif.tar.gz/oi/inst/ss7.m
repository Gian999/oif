% ss7  ->  ss 7
function ss7 ()
  ss (7);
endfunction
