% ss7 [nota]  ->  ss 7 [nota]
function ss7 (varargin)
  ss (7, varargin{:});
endfunction
