% Evidencia de ecuaciones normales: datos, Xd, C, b, a, Q, SST y R2 vivos.
function hm_regresion_vivo (nombre, modo, X1, y, grado, nuevo)
  N=rows(X1); nx=columns(X1);
  if modo==2, p=nx+1; else p=grado+1; endif
  cy=nx+2; ce=cy+1; cerr=cy+2;
  d=max(cerr+2,10); cc=d+p+2; cb=cc+p+1; ca=cb+2;
  C=cell(max(N+10,p+7),ca);
  C{3,1}="Regresion: ecuaciones normales C*a=b; a=inv(C)*b";
  C{5,1}="obs";
  for j=1:nx, C{5,1+j}=sprintf("x%d",j); endfor
  C{5,cy}="y"; C{5,ce}="y_estimado"; C{5,cerr}="error^2";
  C{3,d}="Xd"; C{3,cc}="C=Xd'*Xd"; C{3,cb}="b=Xd'*y"; C{3,ca}="a=inv(C)*b";
  yr=sprintf("$%s$6:$%s$%d",hm_col_excel(cy),hm_col_excel(cy),5+N);
  for i=1:N
    r=5+i; C{r,1}=i;
    for j=1:nx, C{r,1+j}=X1(i,j); endfor
    C{r,cy}=y(i); C{r,d}="=1";
    for j=2:p
      if modo==2, C{r,d+j-1}=sprintf("=%s%d",hm_col_excel(j),r);
      else C{r,d+j-1}=sprintf("=B%d^%d",r,j-1); endif
    endfor
    terms=cell(1,p);
    for j=1:p, terms{j}=sprintf("%s%d*$%s$%d",hm_col_excel(d+j-1),r,hm_col_excel(ca),5+j); endfor
    C{r,ce}=["=" strjoin(terms,"+")];
    C{r,cerr}=sprintf("=(%s%d-%s%d)^2",hm_col_excel(ce),r,hm_col_excel(cy),r);
  endfor
  for i=1:p
    ri=sprintf("$%s$6:$%s$%d",hm_col_excel(d+i-1),hm_col_excel(d+i-1),5+N);
    for j=1:p
      rj=sprintf("$%s$6:$%s$%d",hm_col_excel(d+j-1),hm_col_excel(d+j-1),5+N);
      C{5+i,cc+j-1}=sprintf("=SUMPRODUCT(%s,%s)",ri,rj);
    endfor
    C{5+i,cb}=sprintf("=SUMPRODUCT(%s,%s)",ri,yr);
    f=sprintf("=INDEX(MMULT(MINVERSE($%s$6:$%s$%d),$%s$6:$%s$%d),%d,1)",hm_col_excel(cc),hm_col_excel(cc+p-1),5+p,hm_col_excel(cb),hm_col_excel(cb),5+p,i);
    ref=sprintf("%s%d",hm_col_excel(ca),5+i); C{5+i,ca}=struct("formula",f,"ref",ref);
  endfor
  r=7+N;
  C{r,1}="Q"; C{r,2}=sprintf("=SUM(%s6:%s%d)",hm_col_excel(cerr),hm_col_excel(cerr),5+N);
  C{r+1,1}="media y"; C{r+1,2}=["=AVERAGE(" yr ")"];
  C{r+2,1}="SST"; C{r+2,2}=sprintf("=SUMPRODUCT((%s-$B$%d)^2)",yr,r+1);
  C{r+3,1}="R2"; C{r+3,2}=sprintf("=(B%d-B%d)/B%d",r+2,r,r+2);
  if ! isempty(nuevo)
    rp=r+5; C{rp,1}="prediccion";
    for j=1:numel(nuevo), C{rp,1+j}=nuevo(j); endfor
    terms=cell(1,p); terms{1}=sprintf("$%s$6",hm_col_excel(ca));
    for j=2:p
      if modo==2, xx=sprintf("%s%d",hm_col_excel(j),rp);
      else xx=sprintf("B%d^%d",rp,j-1); endif
      terms{j}=sprintf("$%s$%d*(%s)",hm_col_excel(ca),5+j,xx);
    endfor
    C{rp,ce}=["=" strjoin(terms,"+")];
  endif
  hm_xlsx([nombre ".xlsx"],C);
  printf("  guardado: %s.xlsx (ecuaciones normales y estadisticas con formulas vivas)\n",nombre);
endfunction
