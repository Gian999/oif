% haz28  ->  haz 28
function haz28 ()
  haz ("28");
endfunction
