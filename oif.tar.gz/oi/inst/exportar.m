% exportar  -  guarda en Excel el ejercicio que acabas de resolver con octavei.  Sin parametros:  exportar
%   exportar        -> Excel del ultimo ejercicio (formulas vivas, en la carpeta actual)
%   exportar(3)     -> Excel del ejercicio 3 del catalogo (aunque no lo hayas resuelto)
%   exportar("mi_nombre")  -> igual que exportar, pero con ese nombre de archivo
function exportar (que)
  g_ = hm_silenciar ();
  hm_ocultar ();                   % el comando escrito no queda en el historial
  nombre = ""; id = [];
  if nargin >= 1
    if isnumeric (que) && isscalar (que), id = que;
    elseif ischar (que), nombre = strtrim (que);
    else, error ("exportar: usa exportar, exportar(3) o exportar(\"nombre\")"); endif
  endif
  ult = [];
  if isempty (id)
    try, ult = getappdata (0, "oi_ultimo"); catch, end
    if isempty (ult)
      d = desde_sesion ();
      if isempty (d), error ("exportar: no hay nada que exportar todavia. Resuelve un ejercicio con octavei (ej: octavei 3) o define x e y (o x1, x2 e y) y escribe exportar"); endif
      ult = struct ("tipo", "sesion", "datos", d);
    endif
  else
    ult = struct ("tipo", "catalogo", "id", id);
  endif
  if strcmp (ult.tipo, "catalogo")
    e = hm_catalogo (sprintf ("%d", ult.id));
    if isempty (e), error ("exportar: no existe el ejercicio %d", ult.id); endif
    if isempty (e.datos), disp ("  (ese ejercicio no tiene Excel; usa tu hoja de clase)"); return; endif
    if isempty (nombre), nombre = strrep (e.excel, " ", "_"); endif
    destino = libre ([nombre ".xlsx"]);
    hm_ej_xlsx (destino, e.datos);
    printf ("  [%s]\n", destino);
  elseif strcmp (ult.tipo, "sesion")
    if isempty (nombre), nombre = "ejercicio_sesion"; endif
    destino = libre ([nombre ".xlsx"]);
    hm_ej_xlsx (destino, ult.datos);
    printf ("  [%s]\n", destino);
  else
    if isempty (ult.texto), error ("exportar: la IA no devolvio datos para Excel; pidelo escribiendo la palabra excel en la pregunta"); endif
    acum = []; if isfield (ult, "acum"), acum = ult.acum; endif
    r = hm_excel_ia (ult.texto, ult.libro, acum);
    m = regexp (r, '\[[^\]]*\]', "match");
    if isempty (m), disp ("  (la IA no mando un bloque de Excel; pidelo con la palabra excel)"); else, printf ("  %s\n", m{end}); endif
  endif
endfunction

function d = libre (arch)
  d = arch; [~, b, e] = fileparts (arch); k = 1;
  while exist (d, "file"), k = k + 1; d = sprintf ("%s_%d%s", b, k, e); endwhile
endfunction

function d = desde_sesion ()
  % datos del ejercicio que tienes en la sesion: x,y (recta; con ap tambien parabola) o x1,x2,y (multiple)
  d = [];
  ex = @(v) evalin ("base", sprintf ("exist ('%s', 'var')", v)) == 1;
  g = @(v) double (evalin ("base", v)(:)');
  if ex ("x1") && ex ("x2") && ex ("y")
    d = struct ("titulo", "Regresión múltiple (datos de tu sesión de Octave)", "x1", g ("x1"), "x2", g ("x2"), "y", g ("y"));
  elseif ex ("x") && ex ("y")
    d = struct ("titulo", "Ejercicio (datos de tu sesión de Octave)", "x", g ("x"), "y", g ("y"), "par", ex ("ap") || ex ("a2"));
  endif
endfunction
