% anss11 [lo que quieres]  ->  anss 11 [lo que quieres]  (analiza de nuevo el ejercicio 11 con tu nota y lo resuelve)
function anss11 (varargin)
  anss (11, varargin{:});
endfunction
