% Cholesky - A simetrica definida positiva: A = U'*U
% TUS COMANDOS (clase S5C8):
%   A=[8 20 15; 20 80 50; 15 50 60]; b=[50;250;100]
%   U=chol(A)
%   U'*U               % debe dar A
%   y=inv(U')*b        % U' y = b
%   x=inv(U)*y         % U x = y
%   x=inv(A)*b         % comprobacion
function hm_cholesky ()
  A = pedir ("A simetrica, ej [8 20 15; 20 80 50; 15 50 60]: ");
  b = pedir ("b (columna), ej [50;250;100]: ");
  [U, p] = chol (A);
  if p > 0, disp ("  A no es definida positiva: Cholesky no aplica"); return; endif
  printf ("\nU=chol(A)\n"); disp (U);
  printf ("U'*U (debe ser A), error = %g\n", norm (U'*U - A));
  y = U' \ b; printf ("\ny=inv(U')*b\n"); disp (y);
  x = U \ y;  printf ("x=inv(U)*y\n"); disp (x);
  printf ("comprobacion inv(A)*b - x = %g\n", norm (inv (A)*b - x));
  assignin ("base", "U", U); assignin ("base", "x", x);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
