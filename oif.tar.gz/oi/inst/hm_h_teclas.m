% hm_h_teclas (metodo)  -  modo "teclas" del menu h, SIN IA: te pide los datos del ejercicio (matriz, ecuaciones, x0, tolerancia...)
% y escribe el codigo de la clase con tus teclas (octave:N>), igual que octavei; al terminar guarda el Excel si el metodo tiene hoja.
%   metodos: gaussjordan inversa lu cholesky normas reordenar jacobi gaussseidel directos puntofijo newton regresion ajuste interpola
% El codigo de Jacobi, Gauss-Seidel, punto fijo y Newton y todas las hojas de Excel salen de las MISMAS plantillas que usa el modo IA
% (el programa reordena el sistema, deriva el jacobiano y arma las hojas); aqui los datos los pones tu en vez de leerlos la IA.
function hm_h_teclas (metodo)
  switch metodo
    case "gaussjordan", m_gaussjordan ();
    case "inversa", m_inversa ();
    case "lu", m_lu ();
    case "cholesky", m_cholesky ();
    case "normas", m_normas ();
    case "reordenar", m_reordenar ();
    case {"jacobi", "gaussseidel"}, m_iterativo (metodo);
    case "directos", m_directos ();
    case "puntofijo", m_puntofijo ();
    case "newton", m_newton ();
    case "regresion", m_regresion ();
    case "ajuste", m_ajuste ();
    case "interpola", m_interpola ();
    otherwise, error ("hm_h_teclas: no existe el metodo '%s'", metodo);
  endswitch
endfunction

% ------------------------------------------------------------------ salida: texto con bloques que entiende octavei
function emitir (L, J)
  t = "";
  if ~ isempty (L), t = ["```octave\n" strjoin(L, "\n") "\n```\n"]; endif
  if isstruct (J), t = [t "```excel\n" jsonencode(J) "\n```\n"]; endif
  octavei (struct ("texto", t));
endfunction

% ------------------------------------------------------------------ texto de numeros y matrices (ASCII, sin perder cifras)
function t = nn (v)
  t = sprintf ("%.10g", v + 0);
endfunction

function t = fila_txt (v)
  t = ["[" strjoin(arrayfun (@nn, v(:)', "UniformOutput", false), " ") "]"];
endfunction

function t = col_txt (v)
  t = ["[" strjoin(arrayfun (@nn, v(:)', "UniformOutput", false), ";") "]"];
endfunction

function t = mat_txt (M)
  f = cell (1, rows (M));
  for i = 1:rows (M), f{i} = strjoin (arrayfun (@nn, M(i,:), "UniformOutput", false), " "); endfor
  t = ["[" strjoin(f, "; ") "]"];
endfunction

% ------------------------------------------------------------------ datos
function [A, b, vars] = pedir_sistema ()
  vars = {};
  disp ("  Escribe A y b (matrices) o las ecuaciones.");
  while true
    s = strtrim (hm_entrada ("  A (ej [2 -1 1; 1 1 3; 3 3 5]) o las ecuaciones separadas por ; (ej 2x-y+z=-1; x+y+3z=0; 3x+3y+5z=4): ", "s"));
    if isempty (s), continue; endif
    try
      if ~ isempty (strfind (s, "=")) && isempty (regexp (s, '^\w+\s*=\s*\[', "once"))
        [A, b, vars] = ecuaciones_lineales (s);
        printf ("  A = %s\n  b = %s\n", mat_txt (A), col_txt (b));
      else
        A = hm_pedir ("@valor", s);
        b = hm_pedir ("  b (columna), ej [-1;0;4]: ");
      endif
      b = b(:);
      if ~ isnumeric (A) || rows (A) ~= columns (A) || numel (b) ~= rows (A) || ~ all (isfinite ([A(:); b]))
        error ("A debe ser cuadrada y b del mismo tamano, con numeros");
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function [A, b, vars] = ecuaciones_lineales (s)
  eqs = strtrim (strsplit (s, {";", "\n"}));
  eqs = eqs(~ cellfun (@isempty, eqs));
  n = numel (eqs);
  imp = @(t) regexprep (regexprep (t, '(\d)\s*([A-DF-Za-df-z_(])', '$1*$2'), '(\))\s*([A-Za-z_(])', '$1*$2');
  Li = cell (1, n); Ri = cell (1, n);
  for i = 1:n
    p = strfind (eqs{i}, "=");
    if numel (p) ~= 1, error ("cada ecuacion lleva un solo '='"); endif
    Li{i} = imp (eqs{i}(1:p-1)); Ri{i} = imp (eqs{i}(p+1:end));
  endfor
  vars = unique (regexp (strjoin ([Li Ri], " "), '[A-Za-z_]\w*', "match"));
  if numel (vars) ~= n, error ("%d ecuaciones necesitan %d incognitas y encontre %d (%s)", n, n, numel (vars), strjoin (vars, ",")); endif
  if all (cellfun (@(v) ~ isempty (regexp (v, '^[A-Za-z]+\d+$', "once")), vars))
    num = cellfun (@(v) str2double (regexp (v, '\d+$', "match", "once")), vars);
    [~, o] = sort (num); vars = vars(o);
  endif
  A = zeros (n); b = zeros (n, 1);
  r = [0.37 -1.3 2.1 0.9 -0.6 1.7 -2.2 0.45](1:n);
  for i = 1:n
    f = str2func (["@(" strjoin(vars, ",") ") " Li{i} " - (" Ri{i} ")"]);
    a0 = num2cell (zeros (1, n)); f0 = f (a0{:});
    for j = 1:n
      e = zeros (1, n); e(j) = 1; ae = num2cell (e);
      A(i,j) = f (ae{:}) - f0;
    endfor
    b(i) = -f0;
    ar = num2cell (r); if abs (f (ar{:}) - (f0 + A(i,:) * r')) > 1e-8 * (1 + abs (f0)), error ("la ecuacion %d no es lineal", i); endif
  endfor
endfunction

function [maxit, tol] = pedir_parada ()
  r = strtrim (hm_entrada ("  parar: iteraciones (ej 2) o tolerancia (ej 1e-3) [Enter = tol 1e-3]: ", "s"));
  maxit = []; tol = 1e-3;
  if isempty (r), return; endif
  v = str2double (r);
  if isnan (v) || v <= 0, disp ("  no entendi, uso tolerancia 1e-3");
  elseif v >= 1 && v == round (v), maxit = v;
  else, tol = v; endif
endfunction

function g = pedir_lista (rot, minimo, maximo)
  % lineas de texto (una por ecuacion) hasta Enter vacio
  g = {};
  printf ("  Una por linea (variables x, y, z); Enter vacio para terminar (minimo %d).\n", minimo);
  while numel (g) < maximo
    s = strtrim (hm_entrada (sprintf ("  %s%d = ", rot, numel (g) + 1), "s"));
    if isempty (s)
      if numel (g) >= minimo, break; endif
      continue
    endif
    g{end+1} = s;
  endwhile
endfunction

function x0 = pedir_x0 (n, def)
  x0 = hm_pedir (sprintf ("  X0 (ej %s) [Enter = %s]: ", fila_txt (def), fila_txt (def)), def);
  x0 = x0(:)';
  if numel (x0) ~= n, error ("X0 debe tener %d valores", n); endif
endfunction

% ------------------------------------------------------------------ metodos directos y de la parte de matrices
function m_gaussjordan ()
  [A, b] = pedir_sistema ();
  L = lineas_gj (A, b);
  if isempty (L), disp ("  sin solucion unica"); return; endif
  emitir (L, []);
endfunction

function L = lineas_gj (A, b)
  n = rows (A); M = [A b(:)]; L = {"% Gauss-Jordan: matriz aumentada por filas, queda [I | x]"};
  L{end+1} = strjoin (arrayfun (@(i) sprintf ("f%d=%s", i, fila_txt (M(i,:))), 1:n, "UniformOutput", false), "; ");
  for k = 1:n
    if abs (M(k,k)) < 1e-12
      j = find (abs (M(k+1:n,k)) > 1e-12, 1);
      if isempty (j), L = {}; return; endif
      j = j + k;
      L{end+1} = sprintf ("%% el pivote es 0: intercambio las filas %d y %d", k, j);
      L{end+1} = sprintf ("faux=f%d; f%d=f%d; f%d=faux", k, k, j, j);
      M([k j],:) = M([j k],:);
    endif
    L{end+1} = sprintf ("f%d=f%d/f%d(%d)", k, k, k, k);
    M(k,:) = M(k,:) / M(k,k);
    for i = [1:k-1, k+1:n]
      L{end+1} = sprintf ("f%d=-f%d(%d)*f%d+f%d", i, i, k, k, i);
      M(i,:) = M(i,:) - M(i,k) * M(k,:);
    endfor
  endfor
  L{end+1} = ["x=[" strjoin(arrayfun (@(i) sprintf ("f%d(%d)", i, n+1), 1:n, "UniformOutput", false), ";") "]"];
endfunction

function m_inversa ()
  [A, b] = pedir_sistema ();
  if abs (det (A)) < 1e-12, disp ("  A es singular (det=0): no tiene inversa"); return; endif
  emitir ({"% Metodo directo con la matriz inversa", ["A=" mat_txt(A)], ["b=" col_txt(b)], "inv(A)", "X=inv(A)*b", "% comprobacion: debe dar ~0", "A*X-b"}, []);
endfunction

function m_lu ()
  [A, b] = pedir_sistema ();
  if abs (det (A)) < 1e-12, disp ("  A es singular (det=0): no tiene factorizacion LU util"); return; endif
  emitir ({"% Factorizacion LU: A=L*U, L*y=b, U*x=y", ["A=" mat_txt(A) "; b=" col_txt(b)], "[L,U]=lu(A)", "L*U", "y=inv(L)*b", "x=inv(U)*y", "% comprobacion", "x=inv(A)*b"}, []);
endfunction

function m_cholesky ()
  [A, b] = pedir_sistema ();
  [~, p] = chol (A);
  if p > 0, disp ("  A no es simetrica definida positiva: Cholesky no aplica"); return; endif
  emitir ({"% Cholesky: A=U'*U, U'*y=b, U*x=y", ["A=" mat_txt(A) "; b=" col_txt(b)], "U=chol(A)", "U'*U", "y=inv(U')*b", "x=inv(U)*y", "% comprobacion", "x=inv(A)*b"}, []);
endfunction

function m_normas ()
  A = hm_pedir ("  A, ej [-1 2 0; 5 -3 2; -1 -2 -4]: ");
  emitir ({"% Normas, radio espectral y condicionamiento", ["A=" mat_txt(A)], "norm(A)", "norm(A,1)", "norm(A,inf)", ...
           "eig(A)", "% radio espectral = mayor |autovalor|", "max(abs(eig(A)))", "cond(A)"}, []);
endfunction

function m_reordenar ()
  [A, b] = pedir_sistema ();
  evalc ("[A2, b2, orden] = hm_reordenar (A, b);");
  emitir ({"% Reordenar: cada incognita se despeja de la ecuacion donde su coeficiente es mayor", ["A=" mat_txt(A) "; b=" col_txt(b)], ...
           ["orden=" fila_txt(orden)], "A2=A(orden,:); b2=b(orden)", "D=diag(diag(A2)); BJ=-inv(D)*(A2-D)", "C=inv(D)*b2", ...
           "norm(BJ,inf)", "% radio espectral < 1 -> converge", "max(abs(eig(BJ)))"}, []);
endfunction

function m_directos ()
  disp ("  1) Cramer   2) Eliminacion gaussiana (filas f1,f2,f3)   3) Sustitucion progresiva/regresiva (A triangular)");
  op = hm_pedir ("  metodo [1]: ", 1);
  [A, b] = pedir_sistema ();
  n = rows (A);
  switch op
    case 2
      L = lineas_eliminacion (A, b);
      if isempty (L), disp ("  sin solucion unica"); return; endif
    case 3
      if istriu (A), L = {"% Sustitucion regresiva (A triangular superior)"}; paso = n:-1:1;
      elseif istril (A), L = {"% Sustitucion progresiva (A triangular inferior)"}; paso = 1:n;
      else, disp ("  A no es triangular: usa la opcion 2 (eliminacion gaussiana)"); return; endif
      L{end+1} = ["A=" mat_txt(A) "; b=" col_txt(b)];
      for i = paso
        if istriu (A), o = i+1:n; else, o = 1:i-1; endif
        t = sprintf ("(b(%d)", i);
        for j = o, t = [t sprintf("-A(%d,%d)*x%d", i, j, j)]; endfor
        L{end+1} = sprintf ("x%d=%s)/A(%d,%d)", i, t, i, i);
      endfor
      L{end+1} = ["X=[" strjoin(arrayfun (@(i) sprintf ("x%d", i), 1:n, "UniformOutput", false), ";") "]"];
      L{end+1} = "% comprobacion: debe dar ~0";
      L{end+1} = "A*X-b";
    otherwise
      if abs (det (A)) < 1e-12, disp ("  det(A)=0: Cramer no aplica"); return; endif
      L = {"% Cramer: xj = det(Aj)/det(A), con Aj = A cambiando la columna j por b", ["A=" mat_txt(A) "; b=" col_txt(b)], "X=inv(A)*b", "DA=det(A)"};
      for j = 1:n
        L{end+1} = sprintf ("X%d=A; X%d(:,%d)=b; Dx%d=det(X%d); x%df=Dx%d/DA", j, j, j, j, j, j, j);
      endfor
      L{end+1} = ["Xc=[" strjoin(arrayfun (@(i) sprintf ("x%df", i), 1:n, "UniformOutput", false), ";") "]"];
  endswitch
  emitir (L, []);
endfunction

function L = lineas_eliminacion (A, b)
  n = rows (A); M = [A b(:)]; L = {"% Eliminacion gaussiana: filas aumentadas y sustitucion regresiva"};
  L{end+1} = strjoin (arrayfun (@(i) sprintf ("f%d=%s", i, fila_txt (M(i,:))), 1:n, "UniformOutput", false), "; ");
  for k = 1:n
    if abs (M(k,k)) < 1e-12
      j = find (abs (M(k+1:n,k)) > 1e-12, 1);
      if isempty (j), L = {}; return; endif
      j = j + k;
      L{end+1} = sprintf ("%% el pivote es 0: intercambio las filas %d y %d", k, j);
      L{end+1} = sprintf ("faux=f%d; f%d=f%d; f%d=faux", k, k, j, j);
      M([k j],:) = M([j k],:);
    endif
    L{end+1} = sprintf ("f%d=1/f%d(%d)*f%d", k, k, k, k);
    M(k,:) = M(k,:) / M(k,k);
    for i = k+1:n
      L{end+1} = sprintf ("f%d=-f%d(%d)*f%d+f%d", i, i, k, k, i);
      M(i,:) = M(i,:) - M(i,k) * M(k,:);
    endfor
  endfor
  L{end+1} = sprintf ("x%d=f%d(%d)/f%d(%d)", n, n, n+1, n, n);
  for i = n-1:-1:1
    t = sprintf ("x%d=f%d(%d)", i, i, n+1);
    for j = i+1:n, t = [t sprintf("-f%d(%d)*x%d", i, j, j)]; endfor
    L{end+1} = t;
  endfor
  L{end+1} = ["X=[" strjoin(arrayfun (@(i) sprintf ("x%d", i), 1:n, "UniformOutput", false), ";") "]"];
endfunction

% ------------------------------------------------------------------ Jacobi y Gauss-Seidel (plantilla: el programa reordena y despeja)
function m_iterativo (clave)
  [A, b, vars] = pedir_sistema ();
  n = rows (A);
  x0 = pedir_x0 (n, zeros (1, n));
  [maxit, tol] = pedir_parada ();
  c = lower (strtrim (hm_entrada ("  estudiar la convergencia (E.D.D., BJ, normas)? s = si, Enter = no: ", "s")));
  J = struct ("plantilla", clave, "titulo", merge (strcmp (clave, "jacobi"), "Metodo de Jacobi", "Metodo de Gauss-Seidel"), ...
              "archivo", merge (strcmp (clave, "jacobi"), "jacobi", "gauss_seidel"), "A", A, "b", b(:)', "x0", x0);
  if isempty (maxit), J.tol = tol; else, J.maxit = maxit; endif
  if strcmp (c, "s"), J.conv = true; endif
  if ~ isempty (vars), J.vars = vars; endif
  emitir ({}, J);
endfunction

% ------------------------------------------------------------------ no lineales (plantillas)
function m_puntofijo ()
  disp ("  Escribe las g del despeje (x = g1(x,y,z), y = g2(x,y,z), ...), ej  (2-y^2-z^2)/x");
  g = pedir_lista ("g", 2, 3);
  x0 = pedir_x0 (numel (g), zeros (1, numel (g)));
  [maxit, tol] = pedir_parada ();
  c = lower (strtrim (hm_entrada ("  estudiar la convergencia (derivadas de g en X0)? s = si, Enter = no: ", "s")));
  J = struct ("plantilla", "puntofijo", "titulo", "Metodo del punto fijo", "archivo", "punto_fijo", "g", {g}, "x0", x0);
  if isempty (maxit), J.tol = tol; else, J.maxit = maxit; endif
  if strcmp (c, "s"), J.conv = true; endif
  emitir ({}, J);
endfunction

function m_newton ()
  disp ("  Escribe las ecuaciones igualadas a 0 (f1, f2, f3 en x, y, z), ej  x^2+y^2-z");
  F = pedir_lista ("f", 2, 3);
  x0 = pedir_x0 (numel (F), zeros (1, numel (F)));
  [maxit, tol] = pedir_parada ();
  J = struct ("plantilla", "newtonsistemas", "titulo", "Metodo de Newton", "archivo", "newton", "F", {F}, "x0", x0);
  if isempty (maxit), J.tol = tol; else, J.maxit = maxit; endif
  emitir ({}, J);
endfunction

% ------------------------------------------------------------------ regresion y ajuste
function m_regresion ()
  disp ("  1) recta   2) parabola   3) recta y parabola (y compararlas)   4) lineal multiple (x1, x2)");
  op = hm_pedir ("  opcion [1]: ", 1);
  if op == 4
    x1 = hm_pedir ("  x1, ej [0 1 1 2 2 3 3 4 4] (o: excel datos.xlsx B4:B12): "); x2 = hm_pedir ("  x2: "); y = hm_pedir ("  y: ");
    x1 = x1(:); x2 = x2(:); y = y(:);
    if numel (x1) ~= numel (y) || numel (x2) ~= numel (y) || numel (y) < 4, error ("x1, x2 e y deben tener la misma cantidad de datos (minimo 4)"); endif
    L = [{"% Regresion lineal multiple y = a0 + a1*x1 + a2*x2", ["x1=" col_txt(x1)], ["x2=" col_txt(x2)], ["y=" col_txt(y)]}, hm_lineas("multiple")];
    J = struct ("plantilla", "multiple", "titulo", "Regresion lineal multiple", "archivo", "regresion_multiple", "x1", x1(:)', "x2", x2(:)', "y", y(:)');
    emitir (L, J);
    return
  endif
  x = hm_pedir ("  x, ej [1 2 3 4 5]  (o: excel datos.xlsx A2:A6): "); y = hm_pedir ("  y, ej [9 7.5 4.2 3 2.1]: ");
  x = x(:); y = y(:);
  if numel (x) ~= numel (y) || numel (x) < 3, error ("x e y deben tener la misma cantidad de datos (minimo 3)"); endif
  xe = hm_pedir ("  x a estimar (ej 2.5) [Enter = ninguno]: ", []);
  xn = ""; if ~ isempty (xe), xn = nn (xe(1)); endif
  sw = lower (strtrim (hm_entrada ("  tambien la recta de x sobre y (se intercambian)? s = si, Enter = no: ", "s")));
  swap = strcmp (sw, "s") && op ~= 2;
  L = {"% Regresion por minimos cuadrados (ecuaciones normales C*a=b)", ["x=" col_txt(x)], ["y=" col_txt(y)], "plot(x,y,'*')"};
  J = struct ("plantilla", "regresion", "titulo", "Regresion por minimos cuadrados", "archivo", "regresion", "labs", {{"x", "y"}}, "x", x(:)', "y", y(:)', "xl", "x");
  switch op
    case 2
      L = [L, hm_lineas("poly2", "", "parabola", xn)];
      J.par = true; J.solo = "parabola";
    case 3
      L = [L, hm_lineas("poly1", "", "recta", xn), hm_lineas("poly2", "p", "parabola", xn), {"% el mas preciso es el de mayor R2 (y menor error estandar)", "R2, R2p", "EE, EEp"}];
      J.par = true;
    otherwise
      L = [L, hm_lineas("poly1", "", "recta", xn)];
  endswitch
  if swap
    L = [L, {"% recta de x sobre y: se intercambian los papeles", "t=x; x=y; y=t;"}, hm_lineas("poly1", "2", "recta x sobre y", "")];
    J.swap = true;
  endif
  if ~ isempty (xn), J.pred = xe(1); endif
  emitir (L, J);
endfunction

function m_ajuste ()
  x = hm_pedir ("  x, ej [0 1 2 3 4 5]: "); y = hm_pedir ("  y, ej [2.1 7.7 13.6 27.2 40.9 61.1]: ");
  x = x(:); y = y(:);
  if numel (x) ~= numel (y), error ("x e y deben tener la misma cantidad de datos"); endif
  n = hm_pedir ("  grado del polinomio [Enter = 2]: ", 2);
  emitir ({"% Ajuste de curvas con polyfit", ["x=" col_txt(x)], ["y=" col_txt(y)], "plot(x,y,'*')", sprintf("p=polyfit(x,y,%d)", n), ...
           "yh=polyval(p,x);", "R2=1-sum((y-yh).^2)/sum((y-mean(y)).^2)", "hold on; xx=linspace(min(x),max(x),100); plot(xx,polyval(p,xx))"}, []);
endfunction

% ------------------------------------------------------------------ interpolacion
function m_interpola ()
  disp ("  1) Lagrange (nodos mas cercanos)   2) Newton (diferencias divididas)   3) polinomio por todos los puntos (polyfit)");
  op = hm_pedir ("  opcion [1]: ", 1);
  x = hm_pedir ("  nodos x, ej [2 2.2 2.4 2.6 2.8]: "); y = hm_pedir ("  valores y: ");
  x = x(:)'; y = y(:)';
  if numel (x) ~= numel (y) || numel (x) < 2, error ("x e y deben tener la misma cantidad de datos (minimo 2)"); endif
  [x, o] = sort (x); y = y(o);
  datos = {["x=" col_txt(x)], ["y=" col_txt(y)], "plot(x,y,'*')"};
  if op == 3
    xe = hm_pedir ("  x a evaluar [Enter = ninguno]: ", []);
    L = [{"% Polinomio que pasa por todos los puntos"}, datos, {"p=polyfit(x,y,length(x)-1)"}];
    if ~ isempty (xe), L{end+1} = sprintf ("polyval(p,%s)", fila_txt (xe)); endif
    emitir (L, []);
    return
  endif
  xe = hm_pedir ("  x a evaluar, ej 2.5 (puedes poner varios [2.1 2.5]): ");
  xe = xe(:)';
  gr = hm_pedir (sprintf ("  grado(s), ej 1 o [1 2] [Enter = maximo, grado %d]: ", numel (x) - 1), []);
  gr = gr(:)';
  if any (gr < 1 | gr > numel (x) - 1 | gr ~= round (gr)), error ("los grados deben ser enteros entre 1 y %d", numel (x) - 1); endif
  if op == 2
    if numel (xe) > 1, disp ("  (Newton: uso solo el primer valor de x)"); xe = xe(1); endif
    gr = reshape (unique (gr(gr ~= numel (x) - 1)), 1, []);   % el grado maximo siempre se calcula
    L = lineas_newton (x, y, xe, gr, datos);
    J = struct ("plantilla", "newton", "titulo", "Interpolacion de Newton", "archivo", "interpolacion_newton", "x", x, "y", y, "xe", xe);
  else
    L = lineas_lagrange (x, y, xe, gr, datos);
    J = struct ("plantilla", "lagrange", "titulo", "Interpolacion de Lagrange", "archivo", "interpolacion_lagrange", "x", x, "y", y, "xe", xe);
  endif
  if ~ isempty (gr), J.grados = gr; endif
  emitir (L, J);
endfunction

% ventana de g+1 nodos contiguos mas cercanos a xe (la misma regla que usa la hoja de Excel)
function s0 = ventana (x, xe, g)
  n = numel (x); best = Inf; s0 = 0;
  for s = 0:n-1-g
    c_ = sum (abs (x(s+1:s+g+1) - xe));
    if c_ < best, best = c_; s0 = s; endif
  endfor
endfunction

function L = lineas_lagrange (x, y, xe, gr, datos)
  n = numel (x); if isempty (gr), gr = n - 1; endif
  L = [{"% Interpolacion de Lagrange: P(x)=y0*L0(x)+y1*L1(x)+..."}, datos];
  for e = xe
    L{end+1} = sprintf ("xe=%s", nn (e));
    for g = gr
      s0 = ventana (x, e, g);
      L{end+1} = sprintf ("%% grado %d: nodos %d a %d", g, s0 + 1, s0 + g + 1);
      L{end+1} = sprintf ("xs=x(%d:%d); ys=y(%d:%d);", s0 + 1, s0 + g + 1, s0 + 1, s0 + g + 1);
      for i = 0:g
        o = setdiff (0:g, i) + 1;
        num = strjoin (arrayfun (@(j) sprintf ("(xe-xs(%d))", j), o, "UniformOutput", false), "*");
        den = strjoin (arrayfun (@(j) sprintf ("(xs(%d)-xs(%d))", i + 1, j), o, "UniformOutput", false), "*");
        L{end+1} = sprintf ("L%d=%s/(%s)", i, num, den);
      endfor
      L{end+1} = sprintf ("P%d=%s", g, strjoin (arrayfun (@(i) sprintf ("ys(%d)*L%d", i + 1, i), 0:g, "UniformOutput", false), "+"));
      L{end+1} = sprintf ("hold on; ezplot(@(t) polyval(polyfit(xs,ys,%d),t), [min(x) max(x)])", g);   % dibuja el polinomio junto a los puntos, como en clase
    endfor
  endfor
endfunction

function t = nom_dd (n, i, j)
  idx = i:i+j;
  if n <= 10, t = ["f" sprintf("%d", idx)]; else, t = ["f" strjoin(arrayfun (@(v) sprintf ("%d", v), idx, "UniformOutput", false), "_")]; endif
endfunction

function L = lineas_newton (x, y, xe, gr, datos)
  n = numel (x);
  L = [{"% Interpolacion de Newton: diferencias divididas"}, datos, {sprintf("xe=%s", nn (xe))}];
  for j = 1:n-1
    for i = 0:n-1-j
      if j == 1
        L{end+1} = sprintf ("%s=(y(%d)-y(%d))/(x(%d)-x(%d))", nom_dd (n, i, 1), i + 2, i + 1, i + 2, i + 1);
      else
        L{end+1} = sprintf ("%s=(%s-%s)/(x(%d)-x(%d))", nom_dd (n, i, j), nom_dd (n, i + 1, j - 1), nom_dd (n, i, j - 1), i + j + 1, i + 1);
      endif
    endfor
  endfor
  todos = [n - 1, gr];
  for g = todos
    if g == n - 1, s0 = 0; else, s0 = ventana (x, xe, g); endif
    t = sprintf ("y(%d)", s0 + 1);
    for j = 1:g
      p = strjoin (arrayfun (@(m) sprintf ("(xe-x(%d))", s0 + m + 1), 0:j-1, "UniformOutput", false), "*");
      t = [t "+" nom_dd(n, s0, j) "*" p];
    endfor
    L{end+1} = sprintf ("P%d=%s", g, t);
  endfor
endfunction
