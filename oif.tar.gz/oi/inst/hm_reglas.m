% Opciones compartidas; no cambia el metodo ni los datos del ejercicio.
% decimales=[]: precision completa; iteraciones=[]: parar por tolerancia.
function r = hm_reglas (op, tol, limite, preguntar)
  if ! isstruct (op) || ! isscalar (op), error ("oi: reglas deben ser una estructura escalar"); endif
  r = struct ("decimales", [], "iteraciones", [], "tolerancia", tol, "limite", limite);
  for f = {"decimales","iteraciones","tolerancia"}
    if isfield (op, f{1}), r.(f{1}) = op.(f{1}); endif
  endfor
  if preguntar
    s = strtrim (hm_entrada ("decimales por paso (Enter = completo): ", "s"));
    if ! isempty (s), r.decimales = str2double (s); endif
    s = strtrim (hm_entrada ("numero fijo de iteraciones (Enter = hasta tolerancia): ", "s"));
    if ! isempty (s), r.iteraciones = str2double (s); endif
  endif
  if ! isempty (r.decimales) && (! isnumeric (r.decimales) || ! isscalar (r.decimales) || ! isfinite (r.decimales) || r.decimales != fix (r.decimales) || r.decimales < 0 || r.decimales > 15)
    error ("oi: decimales debe ser un entero entre 0 y 15, o []");
  endif
  if ! isempty (r.iteraciones) && (! isnumeric (r.iteraciones) || ! isscalar (r.iteraciones) || ! isfinite (r.iteraciones) || r.iteraciones < 1 || r.iteraciones != fix (r.iteraciones))
    error ("oi: iteraciones debe ser un entero positivo, o []");
  endif
  if ! isnumeric (r.tolerancia) || ! isscalar (r.tolerancia) || ! isfinite (r.tolerancia) || r.tolerancia <= 0
    error ("oi: tolerancia debe ser positiva y finita");
  endif
  if ! isempty (r.iteraciones), r.limite = r.iteraciones; endif
endfunction
