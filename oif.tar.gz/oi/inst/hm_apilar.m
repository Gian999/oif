% hm_apilar (Cs, nombres)  -  apila partes (a, b, c...) de un ejercicio en UNA sola hoja (margen: columna A y fila 1 vacias).
%   Mueve las referencias de celda de cada parte; entiende referencias entre partes con el nombre:  =a!C6  o  ='Lagrange'!D40
function C = hm_apilar (Cs, nom)
  % Apila los partes (a, b, c...) en UNA sola hoja con margen como tus hojas (columna A y fila 1 vacias).
  % Mueve las referencias de las formulas (filas y columnas). Titulo unico por parte (el de la primera fila, o el nombre si no hay).
  nc = max (cellfun (@columns, Cs)) + 1; C = cell (1, nc); off = 1;
  % 1) desplazamiento de cada parte (para resolver referencias tipo  a!C60  que la IA escribe entre partes)
  dd = zeros (1, numel (Cs)); o2 = 1;
  for k = 1:numel (Cs)
    Ck = Cs{k}; nk = rows (Ck);
    tit = nk >= 1 && sum (! cellfun (@isempty, Ck(1,:))) == 1 && ischar (Ck{1,find (! cellfun (@isempty, Ck(1,:)), 1)});
    lead = 0; if ! tit, lead = find (any (! cellfun (@isempty, Ck), 2), 1) - 1; if isempty (lead), lead = 0; endif, endif
    dd(k) = merge (tit, o2, o2 + 1) - lead; o2 = dd(k) + nk + 1;
  endfor
  for k = 1:numel (Cs)
    Ck = Cs{k}; [nk, mk] = size (Ck);
    tit = nk >= 1 && sum (! cellfun (@isempty, Ck(1,:))) == 1 && ischar (Ck{1,find (! cellfun (@isempty, Ck(1,:)), 1)});
    lead = 0; if ! tit, lead = find (any (! cellfun (@isempty, Ck), 2), 1) - 1; if isempty (lead), lead = 0; endif, endif
    if tit, d = off; else, d = off + 1 - lead; C(off+1, 1:nc) = cell (1, nc); C{off+1, 2} = ["{b}" nom{k}]; endif
    for i = lead+1:nk, for j = 1:mk
      v = Ck{i,j}; est = [];
      if isstruct (v) && isscalar (v) && isfield (v, "v") && isfield (v, "s"), est = v.s; v = v.v; endif
      pre = "";
      if ischar (v) && numel (v) > 3 && v(1) == "{" && v(3) == "}", pre = v(1:3); v = v(4:end); endif
      if ischar (v) && ! isempty (v) && v(1) == "=", v = desplazar_cal (v, d, dd, nom, k); endif
      if i == 1 && tit && ischar (v) && ! isempty (v) && isempty (pre), pre = "{b}"; endif
      if ! isempty (pre), v = [pre v]; endif
      if ! isempty (est), v = struct ("v", v, "s", est); endif
      C{d+i, j+1} = v;
    endfor, endfor
    off = d + nk + 1;
  endfor
endfunction

function f = desplazar_cal (f, d, dd, nom, k)
  % referencias con nombre de hoja/parte (a!C60, 'Recta'!B3): se llevan a la hoja unica con el desplazamiento de esa parte;
  % el resto se desplaza con el de su propia parte
  [~, ~, ~, m, tk, ~, sp] = regexp (f, '(?:''([^'']+)''|([A-Za-z0-9_]+))!(\$?[A-Za-z]{1,3}\$?\d+)');
  if isempty (m), f = desplazar (f, d, 1); return; endif
  o = ""; nn = lower (strtrim (nom(:)'));
  for i = 1:numel (m)
    t = tk{i}; ref = upper (t{end}); nombre = lower (strtrim (strjoin (t(1:end-1), "")));
    j = find (strcmp (nn, nombre), 1);
    if isempty (j), j = find (strcmp (regexprep (nn, ' .*', ''), nombre), 1); endif
    if isempty (j), j = k; endif
    o = [o desplazar(sp{i}, d, 1) strtrim(desplazar(["=" ref], dd(j), 1)(2:end))];
  endfor
  f = [o desplazar(sp{end}, d, 1)];
endfunction

function f = desplazar (f, d, dc)
  % suma d a las filas y dc a las columnas de las referencias (A1, $B$4...), sin tocar nombres de funcion como LOG10(
  [~, ~, ~, m, ~, ~, sp] = regexp (f, '(?<![A-Za-z_\d.])(\$?)([A-Z]{1,3})(\$?)(\d+)(?![\d(A-Za-z_])');
  if isempty (m), return; endif
  o = sp{1};
  for i = 1:numel (m)
    s0 = m{i}; p1 = ""; p2 = ""; if s0(1) == "$", p1 = "$"; s0 = s0(2:end); endif
    q = find ((s0 >= "0" & s0 <= "9") | s0 == "$", 1); lt = s0(1:q-1); s0 = s0(q:end);
    if s0(1) == "$", p2 = "$"; s0 = s0(2:end); endif
    t = {p1, lt, p2, s0};
    n = 0; for ch = t{2}, n = n * 26 + (double (ch) - 64); endfor
    n += dc; L = ""; while n > 0, r = mod (n - 1, 26); L = [char(65 + r) L]; n = (n - 1 - r) / 26; endwhile
    o = [o sprintf("%s%s%s%d", t{1}, L, t{3}, str2double (t{4}) + d) sp{i+1}];
  endfor
  f = o;
endfunction
