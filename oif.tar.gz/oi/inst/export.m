% export  -  igual que exportar (atajo).   export   |   export(3)
function export (varargin)
  exportar (varargin{:});
endfunction
