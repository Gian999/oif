% ss8  ->  ss 8
function ss8 ()
  ss (8);
endfunction
