% ss8 [nota]  ->  ss 8 [nota]
function ss8 (varargin)
  ss (8, varargin{:});
endfunction
