% Normaliza una expresion escalar escrita por una IA/persona: nombres de funciones
% (ABS, Sqrt, EXP...) y variables (X, Y) sin importar mayusculas; ** -> ^; signos unicode.
% hm_normexpr("SQRT(ABS(Z-Y^2))", {"x","y","z"}) -> "sqrt(abs(z-y^2))"
function s = hm_normexpr (s, vars)
  if nargin < 2, vars = {}; endif
  if iscell (s), s = cellfun (@(t) hm_normexpr (t, vars), s, "UniformOutput", false); return; endif
  s = strrep (s, "**", "^");
  s = strrep (s, char ([226 136 146]), "-");   % menos unicode
  s = strrep (s, char ([195 151]), "*");        % multiplicacion unicode
  fun = {"exp","sin","cos","tan","sqrt","abs","log","ln","log10","asin","acos","atan","pi"};
  [tok, ini, fin] = regexp (s, '[A-Za-z_]\w*', "match", "start", "end");
  for k = numel (tok):-1:1
    t = tok{k}; l = lower (t); nuevo = t;
    if any (strcmp (l, fun)), nuevo = l;
    elseif ~ any (strcmp (t, vars)) && any (strcmp (l, lower (vars))), nuevo = vars{find (strcmp (l, lower (vars)), 1)};
    endif
    s = [s(1:ini(k)-1) nuevo s(fin(k)+1:end)];
  endfor
endfunction
