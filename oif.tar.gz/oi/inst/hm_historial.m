% hm_historial (lineas)  -  agrega las lineas al historial de comandos (flecha arriba, panel Command History).
% Usa  history -r  con un archivo temporal. Anota cuantas lineas cuenta hm_prompt_n de mas para no desfasar el numero del prompt.
function hm_historial (lineas)
  try
    if ischar (lineas), lineas = {lineas}; endif
    lineas = lineas(~ cellfun (@(s) isempty (strtrim (s)), lineas));
    if isempty (lineas), return; endif
    f = [tempname() ".txt"];
    fid = fopen (f, "w"); fprintf (fid, "%s\n", lineas{:}); fclose (fid);
    antes = hm_prompt_n ();
    history ("-r", f);
    despues = hm_prompt_n ();
    delete (f);
    ex = getappdata (0, "oi_extra"); if isempty (ex), ex = 0; endif
    setappdata (0, "oi_extra", ex + max (0, despues - antes));
  catch
  end_try_catch
endfunction
