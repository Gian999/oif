% rehacer N [nota]  ==  repensar N [nota]
function rehacer (varargin)
  repensar (varargin{:});
endfunction
