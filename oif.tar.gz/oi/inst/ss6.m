% ss6 [nota]  ->  ss 6 [nota]
function ss6 (varargin)
  ss (6, varargin{:});
endfunction
