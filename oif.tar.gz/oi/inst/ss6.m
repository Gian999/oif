% ss6  ->  ss 6
function ss6 ()
  ss (6);
endfunction
