% [L, chk] = hm_octave_plantilla (J)  -  arma el CODIGO DE OCTAVE (una linea por comando, estilo de tu clase) de Jacobi, Gauss-Seidel,
% punto fijo, Newton de sistemas y el examen con varios metodos, a partir de los MISMOS datos que arman el Excel (J = el JSON de la plantilla).
% La IA ya no escribe este codigo: solo manda los datos del enunciado. Asi el Octave y el Excel salen del mismo sistema, reordenado una sola vez.
%   L    celda de lineas  (comentarios con %)       chk   valores esperados {linea, var, valor} para comprobar al ejecutar el codigo
% Devuelve L = {} si la plantilla no es de este tipo (regresion, interpolacion...): ahi el codigo sigue siendo el de la IA, pero validado.
function [L, chk] = hm_octave_plantilla (J)
  L = {}; chk = struct ("linea", {}, "var", {}, "valor", {});
  if ~ isfield (J, "plantilla"), return; endif
  pl = lower (J.plantilla);
  M = {};
  if strcmp (pl, "examen")
    X = J.metodos; if isstruct (X), X = num2cell (X); endif
    M = X(:)';
  elseif any (strcmp (pl, {"newtonsistemas", "newton-sistemas"})), s = rmfield (J, "plantilla"); s.metodo = "newton"; M = {s};
  elseif strcmp (pl, "puntofijo"), s = rmfield (J, "plantilla"); s.metodo = "puntofijo"; M = {s};
  elseif any (strcmp (pl, {"jacobi", "gaussseidel", "gauss-seidel"})), s = rmfield (J, "plantilla"); s.metodo = pl; M = {s};
  else, return; endif
  % normalizar cada metodo con las MISMAS reglas que el Excel (A reordenada, despeje, J comprobada, nota de J singular)
  S = cell (size (M)); vf = false (size (M));
  for k = 1:numel (M)
    s = M{k};
    if ~ isfield (s, "metodo"), error ("hm_octave_plantilla: cada metodo necesita el campo metodo"); endif
    if strcmpi (s.metodo, "verificar"), vf(k) = true; S{k} = s; continue; endif
    S{k} = hm_ej_xlsx ("@norm", s);
    if ~ isfield (S{k}, "iter"), error ("hm_octave_plantilla: metodo '%s' desconocido", s.metodo); endif
  endfor
  % F de referencia (para comprobar los despejes de punto fijo): la del primer Newton o verificar, o la que traiga el propio metodo
  Fref = {};
  for k = 1:numel (S), if isfield (S{k}, "F") && isempty (Fref), Fref = cellstr (S{k}.F)(:)'; endif, endfor
  for k = 1:numel (S)
    if ~ vf(k) && strcmp (S{k}.iter, "puntofijo"), S{k} = hm_ej_xlsx ("@pf", struct ("s", S{k}, "Fref", {Fref})); endif
  endfor
  conv_glob = false;
  for k = 1:numel (S), if ~ vf(k) && strcmp (S{k}.iter, "matricial") && isfield (S{k}, "conv") && S{k}.conv, conv_glob = true; endif, endfor
  st = struct ("sym", false, "F", "", "vars", {{}});
  if isfield (J, "titulo") && ischar (J.titulo) && ~ isempty (strtrim (J.titulo))
    % si el unico metodo ya lleva ese mismo titulo en su comentario, no se repite
    repetido = numel (S) == 1 && ~ vf(1) && isfield (S{1}, "titulo") && ischar (S{1}.titulo) && strcmp (strtrim (S{1}.titulo), strtrim (J.titulo));
    if ~ repetido, [L, ~] = ad (L, ["% " J.titulo]); endif
  endif
  for k = 1:numel (S)
    s = S{k};
    if vf(k), [L, chk, st] = cod_verificar (L, chk, st, s);
    elseif strcmp (s.iter, "newton"), [L, chk, st] = cod_newton (L, chk, st, s);
    elseif strcmp (s.iter, "puntofijo"), [L, chk, st] = cod_pf (L, chk, st, s, Fref);
    else, [L, chk, st] = cod_matricial (L, chk, st, s, conv_glob); endif
  endfor
endfunction

% ------------------------------------------------------------------ utilidades
function [L, idx] = ad (L, s)
  L{end+1} = asc (s); idx = numel (L);
endfunction

function s = asc (s)
  % texto ASCII simple (el programa teclea letra por letra)
  rep = {"á","a"; "é","e"; "í","i"; "ó","o"; "ú","u"; "Á","A"; "É","E"; "Í","I"; "Ó","O"; "Ú","U"; "ñ","n"; "Ñ","N"; "ü","u"; ...
         "–","-"; "—","-"; "−","-"; "×","*"; "→","->"; "≈","~"; "≤","<="; "≥",">="; "°",""; "’","'"; "“","\""; "”","\""};
  for i = 1:rows (rep), s = strrep (s, rep{i,1}, rep{i,2}); endfor
  s(double (s) > 126 | double (s) < 32) = [];
endfunction

function t = nn (v)
  t = sprintf ("%.10g", v + 0);       % + 0 evita escribir -0
endfunction

function t = colv (x)
  t = ["[" strjoin(arrayfun (@nn, x(:)', "UniformOutput", false), ";") "]"];
endfunction

function t = pto (x)
  t = ["(" strjoin(arrayfun (@nn, x(:)', "UniformOutput", false), ",") ")"];
endfunction

function t = fr (v)
  % fraccion exacta p/q si existe (como en clase: BJ=[0 0 -1/3; 1/4 0 1/2; ...]); si no, decimal con 15 cifras
  if v == 0, t = "0"; return; endif
  if v == round (v), t = sprintf ("%d", v); return; endif
  [n, d] = rat (v, 1e-12);
  if d > 0 && d <= 100000 && abs (n / d - v) <= 1e-13 * max (1, abs (v))
    t = sprintf ("%d/%d", n, d);
  else
    t = sprintf ("%.15g", v);
  endif
endfunction

function t = matfr (M)
  f = cell (rows (M), 1);
  for i = 1:rows (M), f{i} = strjoin (arrayfun (@fr, M(i,:), "UniformOutput", false), " "); endfor
  t = ["[" strjoin(f(:)', "; ") "]"];
endfunction

function t = colfr (v)
  t = ["[" strjoin(arrayfun (@fr, v(:)', "UniformOutput", false), "; ") "]"];
endfunction

function [vars, n] = nombres (s, n)
  vars = {"x", "y", "z"}(1:min (n, 3)); if isfield (s, "vars"), vars = cellstr (s.vars)(:)'; endif
endfunction

function v = lista_vars (vars)
  v = ["[" strjoin(vars, " ") "]"];
endfunction

function t = sc (e)
  t = regexprep (e, '(?<![.])([*/^])', '.$1');
endfunction

function [L, st] = simbolos (L, st, vars)
  % pkg load symbolic y syms (una sola vez por conjunto de variables)
  if ~ st.sym, [L, ~] = ad (L, "pkg load symbolic"); st.sym = true; endif
  if ~ isequal (st.vars, vars), [L, ~] = ad (L, ["syms " strjoin(vars, " ")]); st.vars = vars; st.F = ""; endif
endfunction

function [L, st] = def_F (L, st, Fs)
  % f1=...; f2=...; F=[f1;f2;...]  (se omite si ya esta definida la misma F)
  clave = strjoin (Fs, "|");
  if strcmp (st.F, clave), return; endif
  for j = 1:numel (Fs), [L, ~] = ad (L, sprintf ("f%d=%s", j, Fs{j})); endfor
  [L, ~] = ad (L, ["F=[" strjoin(arrayfun (@(j) sprintf ("f%d", j), 1:numel (Fs), "UniformOutput", false), ";") "]"]);
  st.F = clave; st.Jdef = false;
endfunction

function L = notas (L, s)
  % lo que se hace en papel (reordenar, despejes, avisos) va como comentarios %
  for campo = {"sistema", "despeje"}
    if isfield (s, campo{1})
      for t = cellstr (s.(campo{1}))(:)'
        tt = strtrim (t{1}); if isempty (tt), continue; endif
        if tt(1) ~= "%", tt = ["% " tt]; endif
        if any (strcmp (L, asc (tt))), continue; endif      % ya escrito antes (mismo sistema en Jacobi y Gauss-Seidel)
        [L, ~] = ad (L, tt);
      endfor
    endif
  endfor
endfunction

function [K, fijo] = cuantas (s, maxdef)
  fijo = isfield (s, "maxit") && ~ isempty (s.maxit);
  if fijo, K = s.maxit; else, K = maxdef; endif
endfunction

function t = describe (s, nombre, x0, K, fijo, tol)
  if fijo, t = sprintf ("X0=%s, %d iteraciones", pto (x0), K);
  else, t = sprintf ("X0=%s, parar cuando E<%g", pto (x0), tol); endif
endfunction

function t = titulo_m (s, defecto)
  t = defecto; if isfield (s, "titulo") && ischar (s.titulo) && ~ isempty (strtrim (s.titulo)), t = strtrim (s.titulo); endif
endfunction

% ------------------------------------------------------------------ Jacobi / Gauss-Seidel
function [L, chk, st] = cod_matricial (L, chk, st, s, conv_glob)
  gs = isfield (s, "gs") && s.gs;
  x0 = s.x0(:); n = numel (x0);
  tol = 1e-3; if isfield (s, "tol") && ~ isempty (s.tol), tol = s.tol; endif
  [K, fijo] = cuantas (s, 40);
  if isfield (s, "A") && isfield (s, "b")
    A = s.A; b = s.b(:);
    if rows (A) ~= n || columns (A) ~= n || numel (b) ~= n || any (diag (A) == 0)
      if any (diag (A) == 0) && rows (A) == n && columns (A) == n
        error ("el sistema no se puede reordenar para que la diagonal no tenga ceros: revisa que A y b esten bien leidos del enunciado (una fila por ecuacion, columnas x,y,z)");
      endif
      error ("A debe ser %dx%d (una fila por ecuacion) y b de largo %d, como x0", n, n, n);
    endif
    if gs
      D = diag (diag (A)); Lw = tril (A, -1); U = triu (A, 1);
      B = -((D + Lw) \ U); Cv = (D + Lw) \ b;
    else
      B = -(A - diag (diag (A))) ./ diag (A); Cv = b ./ diag (A);
    endif
  else
    B = s.B; Cv = s.Cv(:);
  endif
  nombreB = merge (gs, "BGS", "BJ");
  nombre = merge (gs, "Gauss-Seidel", "Jacobi");
  [L, ~] = ad (L, ["% " titulo_m(s, ["Metodo de " nombre]) ": " describe(s, nombre, x0, K, fijo, tol)]);
  L = notas (L, s);
  if gs, [L, ~] = ad (L, "% Gauss-Seidel: BGS=-inv(D+L)*U y C=inv(D+L)*b, con D, L y U de A (fracciones exactas, calculadas a papel)");
  else, [L, ~] = ad (L, "% Jacobi: BJ=-inv(D)*(L+U) y C=inv(D)*b, es decir, cada fila se despeja (fracciones exactas)"); endif
  [L, i1] = ad (L, sprintf ("%s=%s", nombreB, matfr (B)));
  chk(end+1) = struct ("linea", i1, "var", nombreB, "valor", B);
  [L, i2] = ad (L, sprintf ("C=%s", colfr (Cv)));
  chk(end+1) = struct ("linea", i2, "var", "C", "valor", Cv);
  % convergencia: solo si el enunciado lo pide (conv) o si hubo que reordenar para E.D.D.
  reord = isfield (s, "sistema") && any (~ cellfun (@isempty, regexp (cellstr (s.sistema), 'eordenad', "once")));
  if (isfield (s, "conv") && s.conv) || conv_glob || reord
    [L, ~] = ad (L, "% convergencia: la norma infinito de la matriz de iteracion debe ser menor que 1 (E.D.D. por filas)");
    [L, ~] = ad (L, sprintf ("norm(%s,inf)", nombreB));
    ni = norm (B, inf);
    if (isfield (s, "conv") && s.conv) || conv_glob
      [L, ~] = ad (L, sprintf ("norm(%s,1)", nombreB));
      [L, ~] = ad (L, sprintf ("max(abs(eig(%s)))", nombreB));
      rho = max (abs (eig (B)));
      [L, ~] = ad (L, sprintf ("%% radio espectral = %.4g %s 1: %s", rho, merge (rho < 1, "<", ">="), merge (rho < 1, "converge", "no se garantiza convergencia")));
    else
      [L, ~] = ad (L, sprintf ("%% norm(%s,inf) = %.4g %s 1: %s", nombreB, ni, merge (ni < 1, "<", ">="), merge (ni < 1, "converge", "no se garantiza convergencia con esta norma")));
    endif
  endif
  [L, i3] = ad (L, sprintf ("X0=%s", colv (x0)));
  X = x0; k = 0; E = Inf;
  do
    k = k + 1; Xn = B * X + Cv; E = norm (Xn - X, inf);
    a = merge (k == 1, "X0", sprintf ("X%d", k - 1));
    [L, ix] = ad (L, sprintf ("X%d=%s*%s+C", k, nombreB, a));
    chk(end+1) = struct ("linea", ix, "var", sprintf ("X%d", k), "valor", Xn);
    [L, ie] = ad (L, sprintf ("E%d=norm(X%d-%s,inf)", k, k, a));
    chk(end+1) = struct ("linea", ie, "var", sprintf ("E%d", k), "valor", E);
    X = Xn;
  until (~ fijo && E < tol) || k >= K || ~ all (isfinite (X))
  if ~ fijo && E >= tol, [L, ~] = ad (L, sprintf ("%% (tras %d iteraciones E=%.3g todavia no baja de %g)", k, E, tol)); endif
endfunction

% ------------------------------------------------------------------ Newton de sistemas
function [L, chk, st] = cod_newton (L, chk, st, s)
  x0 = s.x0(:); Fs = cellstr (s.F)(:)'; n = numel (Fs);
  vars = nombres (s, n); Fs = hm_normexpr (Fs, vars);
  tol = 1e-3; if isfield (s, "tol") && ~ isempty (s.tol), tol = s.tol; endif
  [K, fijo] = cuantas (s, 40);
  [L, ~] = ad (L, ["% " titulo_m(s, "Metodo de Newton") ": " describe(s, "Newton-Raphson", x0, K, fijo, tol)]);
  L = notas (L, s);
  [L, st] = simbolos (L, st, vars);
  [L, st] = def_F (L, st, Fs);
  if ~ isfield (st, "Jdef") || ~ st.Jdef
    [L, ~] = ad (L, ["J=jacobian(F," lista_vars(vars) ")"]);
    [L, ~] = ad (L, "IJ=inv(J)");
    st.Jdef = true;
  endif
  [L, ~] = ad (L, sprintf ("X0=%s", colv (x0)));
  % valores esperados con el mismo jacobiano que usa el Excel (s.J ya comprobada contra la derivada exacta de F)
  va = strjoin (vars, ",");
  Fh = str2func (["@(" va ") [" strjoin(cellfun (@sc, Fs(:)', "UniformOutput", false), ";") "]"]);
  Js = s.J; Jh = cell (n, n);
  for a = 1:n, for b = 1:n, Jh{a,b} = sc (hm_normexpr (Js{a,b}, vars)); endfor, endfor
  Jf = str2func (["@(" va ") [" strjoin(arrayfun (@(a) strjoin (Jh(a,:), ","), 1:n, "UniformOutput", false), ";") "]"]);
  X = x0; k = 0; E = Inf; fin = false;
  do
    args = num2cell (X)(:)';
    Jm = Jf (args{:});
    if any (~ isfinite (Jm(:))) || rcond (Jm) < 1e-14
      [L, ~] = ad (L, sprintf ("%% J(X%d) es singular: Newton se detiene aqui", k)); fin = true; break;
    endif
    Xn = X - Jm \ Fh (args{:}); k = k + 1; E = norm (Xn - X, inf);
    a = merge (k == 1, "X0", sprintf ("X%d", k - 1));
    [L, ix] = ad (L, sprintf ("X%d=%s-double(subs(IJ,%s,%s))*double(subs(F,%s,%s))", k, a, lista_vars(vars), a, lista_vars(vars), a));
    chk(end+1) = struct ("linea", ix, "var", sprintf ("X%d", k), "valor", Xn);
    [L, ie] = ad (L, sprintf ("E%d=norm(X%d-%s,inf)", k, k, a));
    chk(end+1) = struct ("linea", ie, "var", sprintf ("E%d", k), "valor", E);
    X = Xn;
  until (~ fijo && E < tol) || k >= K || ~ all (isfinite (X))
endfunction

% ------------------------------------------------------------------ punto fijo
function [L, chk, st] = cod_pf (L, chk, st, s, Fref)
  x0 = s.x0(:); n = numel (x0); gs_ = cellstr (s.g)(:)';
  vars = nombres (s, n); gs_ = hm_normexpr (gs_, vars);
  if numel (gs_) ~= n, error ("hm_octave_plantilla: g debe tener %d expresiones", n); endif
  tol = 1e-3; if isfield (s, "tol") && ~ isempty (s.tol), tol = s.tol; endif
  [K, fijo] = cuantas (s, 40);
  [L, ~] = ad (L, ["% " titulo_m(s, "Punto fijo") ": " describe(s, "punto fijo", x0, K, fijo, tol)]);
  % despeje a papel: de que ecuacion sale cada g (y, en "sistema", el aviso si no cumple g(x*)=x* donde F=0)
  L = notas (L, s);
  [L, st] = simbolos (L, st, vars);
  for j = 1:n, [L, ~] = ad (L, sprintf ("g%d=%s", j, gs_{j})); endfor
  % convergencia (opcional, como en clase): dg=diff(g,var) y su valor en X0; la suma por columna de |dg| debe ser < 1
  conv = isfield (s, "conv") && s.conv; Jg = [];
  if conv
    try
      Jg = zeros (n);
      for j = 1:n, for m = 1:n
        dh = str2func (["@(" strjoin(vars, ",") ") " sc(hm_derivar (gs_{j}, vars{m}))]);
        a0 = num2cell (x0)(:)'; Jg(j,m) = dh (a0{:});
      endfor, endfor
      if ~ all (isfinite (Jg(:))), Jg = []; endif
    catch
      Jg = [];
    end_try_catch
    if isempty (Jg)
      [L, ~] = ad (L, "% convergencia: las derivadas de g no estan definidas en X0 (se estudia con otro punto inicial)"); conv = false;
    else
      [L, ~] = ad (L, "% convergencia: derivadas parciales de g (la suma por columna de |dg| en X0 debe ser menor que 1)");
      for j = 1:n, for m = 1:n, [L, ~] = ad (L, sprintf ("dg%d%s=diff(g%d,%s)", j, vars{m}, j, vars{m})); endfor, endfor
    endif
  endif
  p0 = arrayfun (@(j) sprintf ("%s0", vars{j}), 1:n, "UniformOutput", false);
  [L, ~] = ad (L, [strjoin(arrayfun (@(j) sprintf ("%s0=%s", vars{j}, nn (x0(j))), 1:n, "UniformOutput", false), ";") ";"]);
  [L, ~] = ad (L, sprintf ("X0=[%s]", strjoin (p0, ";")));
  if conv
    for j = 1:n, for m = 1:n, [L, ~] = ad (L, sprintf ("double(subs(dg%d%s,%s,[%s]))", j, vars{m}, lista_vars(vars), strjoin (p0, " "))); endfor, endfor
    cs = sum (abs (Jg), 1);
    [L, ~] = ad (L, sprintf ("%% suma por columna de |dg| en X0: %s -> %s", strjoin (arrayfun (@(v) sprintf ("%.4g", v), cs, "UniformOutput", false), ", "), ...
                 merge (all (cs < 1), "todas < 1: converge", "alguna >= 1: no se garantiza convergencia con este punto")));
  endif
  gh = cellfun (@(t) str2func (["@(" strjoin(vars, ",") ") " sc(t)]), gs_, "UniformOutput", false);
  X = x0; k = 0; E = Inf; prev = p0;
  do
    args = num2cell (X)(:)';
    Xn = zeros (n, 1); for j = 1:n, Xn(j) = gh{j} (args{:}); endfor
    k = k + 1; E = norm (Xn - X, inf);
    cur = arrayfun (@(j) sprintf ("%s%d", vars{j}, k), 1:n, "UniformOutput", false);
    for j = 1:n
      [L, ij] = ad (L, sprintf ("%s=double(subs(g%d,%s,[%s]))", cur{j}, j, lista_vars(vars), strjoin (prev, " ")));
      chk(end+1) = struct ("linea", ij, "var", cur{j}, "valor", Xn(j));
    endfor
    a = merge (k == 1, "X0", sprintf ("X%d", k - 1));
    [L, ix] = ad (L, sprintf ("X%d=[%s]", k, strjoin (cur, ";")));
    chk(end+1) = struct ("linea", ix, "var", sprintf ("X%d", k), "valor", Xn);
    [L, ie] = ad (L, sprintf ("E%d=norm(X%d-%s,inf)", k, k, a));
    chk(end+1) = struct ("linea", ie, "var", sprintf ("E%d", k), "valor", E);
    X = Xn; prev = cur;
  until (~ fijo && E < tol) || k >= K || ~ all (isfinite (X))
endfunction

% ------------------------------------------------------------------ verificar que unos puntos son solucion
function [L, chk, st] = cod_verificar (L, chk, st, s)
  Fs = cellstr (s.F)(:)'; P = s.puntos;
  if iscell (P), P = cell2mat (cellfun (@(v) v(:)', P(:), "UniformOutput", false)); endif
  if columns (P) == 1 && rows (P) > 1, P = P'; endif
  n = columns (P); vars = {"x", "y", "z"}(1:min (n, 3));
  Fs = hm_normexpr (Fs, vars);
  tit = "Evaluar F en los puntos"; if isfield (s, "titulo") && ischar (s.titulo) && ~ isempty (strtrim (s.titulo)), tit = strtrim (s.titulo); endif
  [L, ~] = ad (L, ["% " tit]);
  [aviso, inf_] = hm_ej_xlsx ("@verif", struct ("F", {Fs}, "puntos", P, "vars", {vars})); Pc = inf_.Pc;
  if isfield (s, "nota") && ~ isempty (strtrim (s.nota)) && isempty (aviso), [L, ~] = ad (L, ["% " strtrim(regexprep(s.nota, '^\s*%\s*', ""))]); endif
  [L, st] = simbolos (L, st, vars);
  [L, st] = def_F (L, st, Fs);
  Fh = str2func (["@(" strjoin(vars, ",") ") [" strjoin(cellfun (@sc, Fs(:)', "UniformOutput", false), ";") "]"]);
  for i = 1:rows (P)
    [L, ~] = ad (L, sprintf ("double(subs(F,%s,[%s]))", lista_vars (vars), strjoin (arrayfun (@nn, P(i,:), "UniformOutput", false), " ")));
  endfor
  % si F no se anula en algun punto se dice (comentario con el resultado REAL) y se evalua tambien el punto corregido
  if ~ isempty (aviso), [L, ~] = ad (L, ["% " aviso]); endif
  for i = 1:rows (Pc)
    [L, ~] = ad (L, sprintf ("%% punto corregido %s", pto (Pc(i,:))));
    [L, ~] = ad (L, sprintf ("double(subs(F,%s,[%s]))", lista_vars (vars), strjoin (arrayfun (@nn, Pc(i,:), "UniformOutput", false), " ")));
  endfor
endfunction
