% Entrada guiada: EOF no significa Enter; en scripts usar argumentos/opciones.
function s = hm_entrada (texto, tipo)
  try
    s = input (texto, tipo);
  catch e
    error ("oi:entrada", "Falta entrada para '%s'. En modo no interactivo suministra stdin o usa las opciones del metodo. (%s)", texto, e.message);
  end_try_catch
endfunction
