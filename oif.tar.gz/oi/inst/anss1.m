% anss1 [lo que quieres]  ->  anss 1 [lo que quieres]  (analiza de nuevo el ejercicio 1 con tu nota y lo resuelve)
function anss1 (varargin)
  anss (1, varargin{:});
endfunction
