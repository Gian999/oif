% haz2  ->  haz 2
function haz2 ()
  haz ("2");
endfunction
