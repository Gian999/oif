% haz7  ->  haz 7
function haz7 ()
  haz ("7");
endfunction
