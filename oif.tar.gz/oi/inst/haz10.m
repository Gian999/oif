% haz10  ->  haz 10
function haz10 ()
  haz ("10");
endfunction
