% haz21  ->  haz 21
function haz21 ()
  haz ("21");
endfunction
