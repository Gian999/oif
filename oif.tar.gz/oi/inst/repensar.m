% repensar N [lo que ves raro]   (tambien: otra N ...  |  rehacer N ...)
%   Si algo del ejercicio N de tu PDF se ve extrano, la IA lo vuelve a leer desde cero, busca que salio mal y lo rehace
%   (o lo resuelve por otro camino de tu clase). Despues escribe  ssN  para ejecutarlo: reemplaza la hoja N del Excel.
%     repensar 2
%     repensar 4 solo pedia la parabola
%     repensar 5 era interpolacion inversa
%   Sin numero: rehace la ultima pregunta suelta que hiciste con octavei("...").
function repensar (varargin)
  n = []; resto = varargin;
  if ! isempty (resto)
    v = resto{1};
    if isnumeric (v) && isscalar (v), n = v; resto(1) = [];
    elseif ischar (v) && ! isempty (regexp (strtrim (v), '^\d+$', "once")), n = str2double (v); resto(1) = []; endif
  endif
  nota = strtrim (strjoin (cellfun (@(x) char (x), resto, "UniformOutput", false), " "));
  octavei (struct ("repensar", n, "nota", nota));
endfunction
