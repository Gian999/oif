% haz24  ->  haz 24
function haz24 ()
  haz ("24");
endfunction
