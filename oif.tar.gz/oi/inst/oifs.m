% oifs  -  guarda UNA vez tu clave de Claude (API Console) para que octavei la use primero.
%   oifs            -> te la pide en una linea, sin mostrar lo que escribes (Enter = omitir y usar Codex)
%   oifs("tu_contrasena")   oifs("sk-ant-...")   oifs("borrar")
%   oifs limpiar    -> quita del historial de comandos todo lo que ya habia de haz, ss, octavei, oifs... (los nuevos ya no se guardan)
% La clave queda en un archivo de TU usuario (~/.oif/anthropic_key); no va dentro del paquete.
function oifs (k)
  hm_ocultar ();                   % este comando no queda en el historial
  if nargin == 1 && ischar (k) && strcmpi (strtrim (k), "limpiar")
    q = hm_ocultar ("todo"); printf ("  historial limpio (%d comandos del paquete quitados)\n", q); return
  endif
  d = fullfile (oif_home (), ".oif"); f = fullfile (d, "anthropic_key"); o = fullfile (d, "omitido");
  b = oif_clave ();
  if nargin == 1 && ~ isempty (b) && isempty (regexp (k, '^sk-', 'once')) && ~ strcmpi (k, "borrar")
    try, k = oif_cripto ("descifrar", b, k); catch, printf ("  no\n"); return; end_try_catch
  elseif nargin < 1 && ~ isempty (b)
    % una sola linea, sin mostrar lo que escribes (Enter solo = omitir y usar Codex)
    for t = 1:3
      pw = oif_pedir ("  > ");
      if isempty (pw), k = ""; break; endif
      try, k = oif_cripto ("descifrar", b, pw); break; catch, printf ("  no\n"); k = ""; if t == 3, return; endif, end_try_catch
    endfor
  elseif nargin < 1, k = strtrim (oif_pedir ("  > ")); endif
  if strcmpi (k, "borrar")
    if exist (f, "file"), delete (f); endif
    if exist (o, "file"), delete (o); endif
    setenv ("ANTHROPIC_API_KEY", ""); return
  endif
  if ~ exist (d, "dir"), mkdir (d); endif
  if isempty (k)
    fid = fopen (o, "w"); fputs (fid, "1"); fclose (fid); return        % omitido: usa Codex (oifs para poner la clave)
  endif
  fid = fopen (f, "w"); fputs (fid, k); fclose (fid);
  if ~ ispc (), system (["chmod 600 '" f "'"]); endif
  if exist (o, "file"), delete (o); endif
  setenv ("ANTHROPIC_API_KEY", k);
endfunction
