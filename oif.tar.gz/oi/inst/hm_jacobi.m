% Jacobi: X(k+1)=B*X(k)+C
% TUS COMANDOS (clase S2C8):
%   BJ=[0 1/2 -1/2; -1 0 -5/3; -1/3 -1/3 0]; C=[-1/2; 4/3; 0]
%   norm(BJ,inf)   norm(BJ,1)   eig(BJ)
%   max(abs(eig(BJ)))        % radio espectral < 1  ->  converge
%   X0=[0;0;0]
%   X1=BJ*X0+C, E1=norm(X1-X0,inf)
%   X2=BJ*X1+C, E2=norm(X2-X1,inf)   ... (repetir hasta que E sea pequeno)
function [T, estado] = hm_jacobi (ej, op)
  if nargin < 1, ej = ""; endif
  if nargin < 2, [T, estado] = hm_iterativo ("jacobi", ej);
  else, [T, estado] = hm_iterativo ("jacobi", ej, op); endif
endfunction
