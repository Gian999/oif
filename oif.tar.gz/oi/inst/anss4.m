% anss4 [lo que quieres]  ->  anss 4 [lo que quieres]  (analiza de nuevo el ejercicio 4 con tu nota y lo resuelve)
function anss4 (varargin)
  anss (4, varargin{:});
endfunction
