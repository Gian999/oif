% g = hm_silenciar ()  -  apaga los avisos (warning) mientras vive g y los restaura al salir de la funcion que lo llamo.
% Octave 11 avisa por "concatenation of single and double quoted..." y "language extension"; dentro de octavei/exportar no sirven de nada.
% Uso:  g = hm_silenciar ();   (guardar el resultado en una variable local)
function g = hm_silenciar ()
  s = warning ();
  warning ("off", "all");
  g = onCleanup (@() warning (s));
endfunction
