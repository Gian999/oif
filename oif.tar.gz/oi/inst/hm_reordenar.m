% Reordenar las ecuaciones para que Jacobi / Gauss-Seidel CONVERJAN  (lo que se hace "en papel")
% Idea (tu clase S2C8 / Clase 04): cada incognita se despeja de la ecuacion donde su coeficiente
% es el mas fuerte, aunque no sea la del mismo numero.  Ej. del sistema
%     2x1 - x2 + x3 = -1 ;  x1 + x2 + 3x3 = 0 ;  3x1 + 3x2 + 5x3 = 4
% se toma: ec.1 -> x1,  ec.3 -> x2,  ec.2 -> x3   (orden [1 3 2])  y entonces BJ y C salen como en clase.
% Criterio: se prueban todos los ordenes y se elige el de MENOR radio espectral de BJ (< 1 converge).
% Uso:  [A2,b2,orden] = hm_reordenar(A,b)      o solo  hm_reordenar  (te pide A y b)
function [A2, b2, orden] = hm_reordenar (A, b, forzar_edd)
  if nargin < 3, forzar_edd = false; endif
  if nargin < 2
    A = pedir ("A, ej [2 -1 1; 1 1 3; 3 3 5]: ");
    b = pedir ("b (columna), ej [-1;0;4]: ");
  endif
  n = rows (A); b = b(:);
  if n > 8, error ("hm_reordenar: maximo 8 ecuaciones"); endif
  cand = [1:n; perms(1:n)];
  mejor = Inf; orden = 1:n; rho0 = NaN;
  for i = 1:rows (cand)
    p = cand(i,:); r = rho_jacobi (A(p,:));
    if i == 1, rho0 = r; endif
    if r < mejor - 1e-12, mejor = r; orden = p; endif
  endfor
  printf ("\norden original [%s]:  ", num2str (1:n));
  if isinf (rho0), disp ("hay un cero en la diagonal (no se puede despejar asi)");
  else printf ("radio espectral de BJ = %.4f  (%s)\n", rho0, merge (rho0 < 1, "converge", "NO converge")); endif
  A2 = A(orden,:); b2 = b(orden);
  d = abs (diag (A2)); fuera = sum (abs (A2), 2) - d;
  printf ("condicionamiento inicial: cond(A,inf) = %.4g   cond(A,1) = %.4g\n", cond (A, inf), cond (A, 1));
  if ! all (d > fuera) && n <= 5 && (mejor >= 1 - 1e-9 || forzar_edd)
    [A3, b3, ops] = acondicionar (A, b);
    if ! isempty (ops)
      printf ("\nNo es E.D.D.: se acondiciona con operaciones entre filas (como en papel):\n");
      for i = 1:numel (ops), printf ("  %s\n", ops{i}); endfor
      printf ("matriz acondicionada A =\n"); disp (A3); printf ("b ="); disp (b3');
      printf ("cond(A,inf) despues = %.4g\n", cond (A3, inf));
      A = A3; b = b3; mejor = Inf;
      cand = [1:n; perms(1:n)];
      for i = 1:rows (cand), pp = cand(i,:); r = rho_jacobi (A(pp,:)); if r < mejor - 1e-12, mejor = r; orden = pp; endif, endfor
      A2 = A(orden,:); b2 = b(orden); d = abs (diag (A2)); fuera = sum (abs (A2), 2) - d;
      printf ("orden despues de acondicionar [%s]: radio espectral = %.4f\n", num2str (orden), mejor);
    endif
  endif
  printf ("mejor orden [%s]:    radio espectral de BJ = %.4f  (%s)\n", num2str (orden), mejor, merge (mejor < 1 - 1e-9, "converge", "NO converge"));
  printf ("dominancia diagonal estricta (EDD): %s\n", merge (all (d > fuera), "SI", "no  (eso NO impide converger; manda el radio espectral)"));
  printf ("\nDespejes (ecuacion %d -> x1, ecuacion %d -> x2, ...):\n", orden(1), orden(min (2, n)));
  for i = 1:n
    t = sprintf ("  x%d = %s", i, fmt (b2(i) / A2(i,i)));
    for j = [1:i-1, i+1:n]
      c = -A2(i,j) / A2(i,i);
      if c != 0, t = [t sprintf(" %s %s*x%d", merge (c < 0, "-", "+"), num2str (abs (c), 6), j)]; endif
    endfor
    disp (t);
  endfor
  D = diag (diag (A2)); BJ = -(D \ (A2 - D)); C = D \ b2;
  printf ("\nBJ =\n"); disp (BJ); printf ("C =\n"); disp (C);
  Lo = tril (A2, -1); Up = triu (A2, 1); BG = -((D + Lo) \ Up);
  printf ("radio espectral Gauss-Seidel = %.4f\n", max (abs (eig (BG))));
  assignin ("base", "A2", A2); assignin ("base", "b2", b2); assignin ("base", "BJ", BJ); assignin ("base", "C", C);
  disp ("(en el workspace: A2, b2, BJ, C)");
  if nargout == 0, clear A2 b2 orden; endif
endfunction

function [A, b, ops] = acondicionar (A, b)
  % busca Fi <- Fi + c*Fj (c = +-1, +-2, +-1/2) que vuelvan la matriz E.D.D. (con algun orden de filas)
  n = rows (A); ops = {}; cs = [1 -1 2 -2 0.5 -0.5]; P = perms (1:n);
  A0 = A; b0 = b;
  for paso = 1:4
    if puntaje (A, P) > 1, return; endif
    mej = puntaje (A, P); op = [];
    for i = 1:n, for j = 1:n, if i != j, for c = cs
      B = A; B(i,:) += c * A(j,:); sc = puntaje (B, P);
      if sc > mej + 1e-12, mej = sc; op = [i j c]; endif
    endfor, endif, endfor, endfor
    if isempty (op), ops = {}; return; endif
    i = op(1); j = op(2); c = op(3);
    A(i,:) += c * A(j,:); b(i) += c * b(j);
    ops{end+1} = sprintf ("F%d <- F%d %s %g*F%d", i, i, merge (c < 0, "-", "+"), abs (c), j);
  endfor
  if puntaje (A, P) <= 1, A = A0; b = b0; ops = {}; endif   % no se logro E.D.D.: no cambio nada
endfunction

function sc = puntaje (A, P)
  sc = 0;
  for k = 1:rows (P)
    M = A(P(k,:),:); d = abs (diag (M)); f = sum (abs (M), 2) - d;
    sc = max (sc, min (d ./ max (f, 1e-12)));
  endfor
endfunction

function r = rho_jacobi (A)
  d = diag (A);
  if any (abs (d) < 1e-12), r = Inf; return; endif
  D = diag (d); r = max (abs (eig (-(D \ (A - D)))));
endfunction

function t = fmt (x)
  t = num2str (x, 6);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
