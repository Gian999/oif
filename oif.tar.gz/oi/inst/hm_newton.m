% Newton-Raphson para SISTEMAS no lineales:  X(k+1) = X(k) - inv(J)*F(X(k))
% TUS COMANDOS (clase 02):
%   pkg load symbolic ; syms x y
%   f1=x^2-10*x+y^2+8 ; f2=x*y^2+x-10*y+8 ; F=[f1;f2]
%   J=jacobian(F,[x y])                 % matriz de derivadas parciales
%   IJ=inv(J)
%   X0=[0;0]
%   X1=X0-double(subs(IJ,[x y],X0))*double(subs(F,[x y],X0))
%   E1=norm(X1-X0,inf)
%   X2=X1-double(subs(IJ,[x y],X1))*double(subs(F,[x y],X1)) ...
% Usa jacobian e inv como en clase (paquete symbolic); si no esta disponible, cae a diferencias finitas y avisa.
function [T, estado] = hm_newton (ej, op)
  con_op = nargin >= 2; if ~ con_op, op = struct (); endif
  T = []; estado = "sin iterar";
  ej = nargin > 0 && strcmp (ej, "ejemplo");
  printf ("\nEscribe f1 y f2 (ecuaciones igualadas a 0, con x e y).\n");
  if ej, s1 = "x^2-10*x+y^2+8"; s2 = "x*y^2+x-10*y+8"; printf ("ejemplo de tu Clase 02:\n  f1=%s\n  f2=%s\n", s1, s2);
  else
    s1 = ""; while isempty (s1), s1 = strtrim (hm_entrada ("f1(x,y) = ", "s")); endwhile
    s2 = ""; while isempty (s2), s2 = strtrim (hm_entrada ("f2(x,y) = ", "s")); endwhile
  endif
  f1 = str2func (["@(x,y) " regexprep(s1, '(?<![.])([*/^])', '.$1')]); f2 = str2func (["@(x,y) " regexprep(s2, '(?<![.])([*/^])', '.$1')]);
  F = @(v) [f1(v(1), v(2)); f2(v(1), v(2))];
  usa_sym = true;
  try
    pkg load symbolic;
    syms x y;
    Fs = [sym(regexprep(s1, '\.([*/^])', '$1')); sym(regexprep(s2, '\.([*/^])', '$1'))];
    Js = jacobian (Fs, [x y]);
    Jf = function_handle (Js, "vars", [x y]);
    jtexto = cell (2,2);
    for i=1:2, for j=1:2, jtexto{i,j} = strrep(char(Js(i,j)), "**", "^"); endfor, endfor
  catch err
    usa_sym = false;
    printf ("AVISO: no pude usar el paquete symbolic (%s).\n  Uso la jacobiana por diferencias finitas (mismos valores salvo ~1e-8). En clase: syms x y; J=jacobian(F,[x y]).\n", strtok (err.message, "\n"));
    hh = 1e-6; ss = {regexprep(s1, '\.([*/^])', '$1'), regexprep(s2, '\.([*/^])', '$1')};
    Jf = @(a, b) [(f1(a+hh,b)-f1(a-hh,b))/(2*hh), (f1(a,b+hh)-f1(a,b-hh))/(2*hh); (f2(a+hh,b)-f2(a-hh,b))/(2*hh), (f2(a,b+hh)-f2(a,b-hh))/(2*hh)];
    jtexto = cell (2,2);
    for i=1:2
      jtexto{i,1} = sprintf ("((%s)-(%s))/0.000002", regexprep (ss{i}, '(?<![A-Za-z_0-9.])x(?![A-Za-z_0-9(])', '(x+0.000001)'), regexprep (ss{i}, '(?<![A-Za-z_0-9.])x(?![A-Za-z_0-9(])', '(x-0.000001)'));
      jtexto{i,2} = sprintf ("((%s)-(%s))/0.000002", regexprep (ss{i}, '(?<![A-Za-z_0-9.])y(?![A-Za-z_0-9(])', '(y+0.000001)'), regexprep (ss{i}, '(?<![A-Za-z_0-9.])y(?![A-Za-z_0-9(])', '(y-0.000001)'));
    endfor
  end_try_catch

  def = zeros (2, 1);
  if evalin ("base", "exist('X0','var')") && numel (evalin ("base", "X0")) == 2, def = evalin ("base", "X0")(:); endif
  if ej, X = [0; 0]; tol = 1e-4;
  else
    X = pedir (sprintf ("X0 (columna)  [Enter = [%g;%g]]: ", def), def); X = X(:);
    tol = pedir ("tolerancia [Enter = 1e-6]: ", 1e-6);
  endif
  if numel (X) ~= 2 || ~ all (isfinite (X)) || ~ isscalar (tol) || ~ isfinite (tol) || tol <= 0
    error ("hm_newton: X0 necesita dos valores finitos y tolerancia positiva finita");
  endif
  reglas = hm_reglas (op, tol, 50, ~ ej && ~ con_op);
  tol = reglas.tolerancia;
  printf ("Reglas: decimales=%s; iteraciones=%s; tolerancia=%g\n", mat2str(reglas.decimales), mat2str(reglas.iteraciones), tol);
  printf ("\nPASOS DE CLASE:\n  pkg load symbolic ; syms x y\n  f1=%s\n  f2=%s\n  F=[f1;f2]\n  J=jacobian(F,[x y])\n  IJ=inv(J)\n  X0=%s\n  X1=X0-double(subs(IJ,[x y],X0))*double(subs(F,[x y],X0))\n  E1=norm(X1-X0,inf)\n  ...\n", s1, s2, mat2str (X, 4));
  if ~ isempty(reglas.decimales)
    printf("  %% En cada paso, ANTES de E1:\n  X1=round(X1*10^%d)/10^%d\n",reglas.decimales,reglas.decimales);
  endif
  printf ("\n   k        x            y         error (norma inf)\n");
  T = [0 X' NaN]; sing = false; E = Inf;
  for k = 1:reglas.limite
    J = Jf (X(1), X(2));
    if ~ all (isfinite (J(:))) || abs (det (J)) < 1e-12, disp ("  la jacobiana es singular aqui: prueba otro X0"); sing = true; break; endif
    Xn = hm_redondear (X - inv (J) * F (X), reglas.decimales); E = norm (Xn - X, inf);
    printf ("  %3d  %11.6f  %11.6f   %.3e\n", k, Xn(1), Xn(2), E);
    T(end+1,:) = [k Xn' E]; X = Xn;
    if (isempty (reglas.iteraciones) && E < tol) || ~ all (isfinite (X)), break; endif
  endfor
  ok = ~ sing && E < tol && all (isfinite (X));
  estado = "limite sin tolerancia";
  if sing, estado="jacobiana singular o no finita";
  elseif ~ all (isfinite (X)), estado = "valores no finitos";
  elseif ok, estado = "tolerancia alcanzada";
  elseif ~ isempty (reglas.iteraciones), estado = "iteraciones solicitadas completadas";
  endif
  printf ("Estado: %s; iteraciones realizadas=%d\n", estado, rows(T)-1);

  printf ("\n%s x=%.8f  y=%.8f   (F(X)=%g)\n", merge (ok, "solucion ~", merge (sing, "SE DETUVO (jacobiana singular); ultimo valor", "NO se alcanzo la tolerancia; ultimo valor")), X(1), X(2), norm (F (X), inf));
  disp ("(J=jacobian(F,[x y]); IJ=inv(J), como en clase)");
  printf ("\nJ en la solucion (por si la pide la tarea):\n"); disp (Jf (X(1), X(2)));
  assignin ("base", "X", X);
  texto = {sprintf("f1 = %s", s1), sprintf("f2 = %s", s2), "F=[f1;f2] ;  J=jacobian(F,[x y]) ;  X(k+1)=X(k)-inv(J)*F(X(k))", sprintf("X0 = %s ; criterio E < %g", mat2str (T(1,2:3)', 3), tol), merge(ok, sprintf("Conclusion: solucion aproximada x=%.6f, y=%.6f en %d iteraciones.", X(1), X(2), rows(T)-1), sprintf("Conclusion: tolerancia NO alcanzada (con iteraciones fijas es lo esperado) (ultimo x=%.6g, y=%.6g tras %d iteraciones).", X(1), X(2), rows(T)-1))};
  texto{end+1} = sprintf ("Estado: %s; decimales=%s; iteraciones=%s; tolerancia=%g", estado, mat2str(reglas.decimales), mat2str(reglas.iteraciones), tol);
  nombre_exportar = merge (ej, "newton_ejemplo", "");
  if isfield (op, "exportar"), nombre_exportar = op.exportar; endif
  if isequal (nombre_exportar, false), return; endif
  if isempty (nombre_exportar)
    nombre_exportar = strtrim(hm_entrada("exportar formulas vivas? Enter = no, o nombre: ", "s"));
  endif
  if ~ isempty (nombre_exportar)
    exportar_newton (nombre_exportar, T(1,2:3)', {s1,s2}, jtexto, texto, rows(T)-1, reglas.decimales);
  endif
endfunction

function exportar_newton (nombre, X0, fs, js, texto, K, dec)
  C = cell(max(10+2*K,6+numel(texto)),14);
  C{3,1} = "Resolucion metodo de Newton Raphson";
  for i=1:numel(texto), C{4+i,2}=texto{i}; endfor
  C(7,7:9) = {"I","Xi","E"}; C{7,11}="F"; C{7,13}="J";
  C{8,7}=0; C{8,8}=X0(1); C{9,8}=X0(2);
  for k=1:K
    r=8+2*k; prev={sprintf("H%d",r-2),sprintf("H%d",r-1)}; C{r,7}=k;
    for i=1:2
      C{r+i-1,11}=["=" hm_fexcel(fs{i},{"x","y"},prev)];
      for j=1:2, C{r+i-1,12+j}=["=" hm_fexcel(js{i,j},{"x","y"},prev)]; endfor
      % INDEX(MMULT(MINVERSE(J),F),i,1) = componente de inv(J)*F.
      f=sprintf("%s-INDEX(MMULT(MINVERSE($M$%d:$N$%d),$K$%d:$K$%d),%d,1)",prev{i},r,r+1,r,r+1,i);
      if ~ isempty(dec), f=sprintf("ROUND(%s,%d)",f,dec); endif
      ref=sprintf("H%d",r+i-1); C{r+i-1,8}=struct("formula",["=" f],"ref",ref);
    endfor
    C{r,9}=sprintf("=MAX(ABS(H%d-H%d),ABS(H%d-H%d))",r,r-2,r+1,r-1);
  endfor
  hm_xlsx([nombre ".xlsx"],C);
  printf("  guardado: %s.xlsx (J simbolica o por diferencias finitas, MINVERSE/MMULT, formulas vivas)\n",nombre);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ~ isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

