function h = oif_home ()
  h = getenv ("HOME"); if isempty (h), h = getenv ("USERPROFILE"); endif
  if isempty (h), h = tempdir (); endif
endfunction
