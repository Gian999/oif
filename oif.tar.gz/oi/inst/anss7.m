% anss7 [lo que quieres]  ->  anss 7 [lo que quieres]  (analiza de nuevo el ejercicio 7 con tu nota y lo resuelve)
function anss7 (varargin)
  anss (7, varargin{:});
endfunction
