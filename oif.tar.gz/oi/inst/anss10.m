% anss10 [lo que quieres]  ->  anss 10 [lo que quieres]  (analiza de nuevo el ejercicio 10 con tu nota y lo resuelve)
function anss10 (varargin)
  anss (10, varargin{:});
endfunction
