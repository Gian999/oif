% anss N [lo que quieres]   (o  anss1 ... anss12 [lo que quieres])  -  analiza OTRA VEZ el ejercicio N de tu PDF y lo resuelve de una vez
%   Despues de  haz examen.pdf  ya tienes la lista; con  anss2  la IA vuelve a leer el ejercicio 2 con lo que tu le digas
%   (que falta, que piden, que metodo) y escribe los comandos igual que ss2 (y guarda su hoja en el Excel). Es repensar N + ssN en un paso.
%     anss2 creo que me pide grafico
%     anss4 solo pedia la parabola y el error
%     anss5 era interpolacion inversa
%     anss3            (sin nota: la IA revisa sola que pudo salir mal)
%   Tambien vale  ss2 creo que me pide grafico  (ssN con texto hace lo mismo).
function anss (varargin)
  g_ = hm_silenciar ();            % sin avisos de Octave mientras corre
  hm_ocultar ();                   % el comando escrito no queda en el historial
  n = []; resto = varargin;
  if ~ isempty (resto)
    v = resto{1};
    if isnumeric (v) && isscalar (v), n = v; resto(1) = [];
    elseif ischar (v) && ~ isempty (regexp (strtrim (v), '^\d+$', "once")), n = str2double (v); resto(1) = []; endif
  endif
  if isempty (n), error ("anss: usa  anss 2 creo que me pide grafico  (o anss2 ...), despues de cargar el PDF con  haz archivo.pdf"); endif
  plan = []; try, plan = getappdata (0, "oi_plan"); catch, end
  if isempty (plan), error ("anss: primero carga el PDF con  haz archivo.pdf"); endif
  if ~ isscalar (n) || isnan (n) || n < 1 || n > numel (plan), error ("anss: elige un ejercicio de 1 a %d", numel (plan)); endif
  antes = plan{n}.texto;
  setappdata (0, "oi_anss", true);
  try
    repensar (n, resto{:});
  catch err
    setappdata (0, "oi_anss", false); rethrow (err);
  end_try_catch
  setappdata (0, "oi_anss", false);
  plan = getappdata (0, "oi_plan");
  if strcmp (plan{n}.texto, antes)
    printf ("  (el ejercicio %d no cambio; no lo ejecuto. Si quieres el de antes escribe  ss%d)\n\n", n, n);
    return
  endif
  ss (n);
endfunction
