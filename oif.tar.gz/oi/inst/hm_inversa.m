% Metodo directo con la matriz inversa:  X = inv(A)*b
% TUS COMANDOS (Clase 05):
%   A=[0.3 0.52 1; 0.5 1 1.9; 0.1 0.3 0.5]
%   b=[-0.01; 0.67; -0.44]
%   inv(A)
%   X=inv(A)*b
%   (comprobacion:  A*X-b  debe dar ~0 ;  tambien  A\b  da lo mismo)
function hm_inversa ()
  A = pedir ("A, ej [0.3 0.52 1; 0.5 1 1.9; 0.1 0.3 0.5]  (o: excel datos.xlsx B2:D4): ");
  b = pedir ("b (columna), ej [-0.01;0.67;-0.44]: "); b = b(:);
  if abs (det (A)) < 1e-12, disp ("  A es singular (det=0): no tiene inversa"); return; endif
  printf ("\ninv(A) =\n"); disp (inv (A));
  X = inv (A) * b; printf ("X=inv(A)*b =\n"); disp (X);
  printf ("comprobacion  norm(A*X-b) = %g     cond(A) = %g\n", norm (A*X - b), cond (A));
  assignin ("base", "X", X);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ~ isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
