% Protege un argumento para system(), segun el shell de la plataforma.
function q = hm_shellquote (s)
  if ! ischar(s) || rows(s)>1 || any(s==char(0)), error("oi: argumento de shell invalido"); endif
  if ispc()
    % cmd.exe expande %VAR% y, si esta activado, !VAR! aun entre comillas.
    if any(ismember(s,[char(34),char(37),char(33),char(10),char(13)]))
      error("oi: argumento con comillas, %% o ! no soportado de forma segura en cmd.exe");
    endif
    q=[char(34) s char(34)];
  else
    separador=[char(39) char(34) char(39) char(34) char(39)];
    q=[char(39) strrep(s,char(39),separador) char(39)];
  endif
endfunction
