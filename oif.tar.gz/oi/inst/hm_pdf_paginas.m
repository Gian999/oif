% imgs = hm_pdf_paginas (pdf)  -  convierte las primeras paginas (OCT_IA_PAGS, por defecto 6) de un PDF a imagenes png
%   en una carpeta temporal y devuelve sus rutas.  Usa Ghostscript (viene con Octave en Windows) o pdftoppm.
function imgs = hm_pdf_paginas (pdf)
  if exist (pdf, "file") != 2, error ("haz: no encuentro el PDF %s", pdf); endif
  pdf = make_absolute_filename (pdf);
  maxp = str2double (getenv ("OCT_IA_PAGS")); if isnan (maxp) || maxp < 1, maxp = 6; endif
  carpeta = tempname (); [ok, msg] = mkdir (carpeta);
  if ! ok, error ("haz: no pude crear carpeta temporal: %s", msg); endif
  % NO se usa cd de Octave: el cd va dentro del comando
  cd_ = @(c) [merge(ispc (), "cd /d ", "cd ") hm_shellquote(carpeta) " && " c];
  gs = buscar_gs ();
  if ! isempty (gs)
    c = sprintf ("%s -q -dNOPAUSE -dBATCH -dSAFER -sDEVICE=png16m -r110 -dTextAlphaBits=4 -dGraphicsAlphaBits=4 -dFirstPage=1 -dLastPage=%d -sOutputFile=p%%d.png %s", ...
                hm_shellquote (gs), maxp, hm_shellquote (pdf));
    [st, out] = system (cd_ (c));
  else
    [st0, ~] = system ("pdftoppm -v");
    if st0 != 0 && st0 != 99, error ("haz: para leer PDF necesito Ghostscript (viene con Octave en Windows; en Linux: sudo apt install ghostscript) o pdftoppm. Otra opcion: convierte el PDF a imagenes png y usa  haz imagen.png"); endif
    c = sprintf ("pdftoppm -png -r 110 -l %d %s p", maxp, hm_shellquote (pdf));
    [st, out] = system (cd_ (c));
  endif
  L = dir (fullfile (carpeta, "*.png"));
  if isempty (L), error ("haz: no pude convertir el PDF a imagenes (%s)", strtrim (out(max(1,end-300):end))); endif
  nom = sort ({L.name});
  imgs = cellfun (@(n) fullfile (carpeta, n), nom, "UniformOutput", false);
endfunction

function gs = buscar_gs ()
  gs = "";
  cand = {getenv("GSC"), "gs", "gswin64c", "gswin32c"};
  h = getenv ("OCTAVE_HOME");
  if ! isempty (h)
    for d = {fullfile(h,"mingw64","bin"), fullfile(h,"bin")}
      for n = {"gs.exe", "gswin64c.exe", "gswin32c.exe"}, cand{end+1} = fullfile (d{1}, n{1}); endfor
    endfor
  endif
  for i = 1:numel (cand)
    c = cand{i}; if isempty (c), continue; endif
    if any (c == filesep ()) && exist (c, "file") != 2, continue; endif
    try
      [st, ~] = system ([hm_shellquote(c) " --version"]);
    catch
      st = 1;
    end_try_catch
    if st == 0, gs = c; return; endif
  endfor
endfunction
