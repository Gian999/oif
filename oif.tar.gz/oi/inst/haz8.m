% haz8  ->  haz 8
function haz8 ()
  haz ("8");
endfunction
