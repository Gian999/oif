% Traduce expresiones escalares de clase a Excel, conservando precedencia.
% hm_fexcel("exp(-x)+sin(x)-x^2", "x", "C5")
% hm_fexcel(fs, {"x","y"}, {"C5","D5"})
% No evalua codigo. Rechaza funciones/sintaxis que no sabe traducir.
function s = hm_fexcel (fs, v, ref)
  if ischar (v), v = {v}; ref = {ref}; endif
  if numel (v) != numel (ref), error ("hm_fexcel: variables y referencias incompatibles"); endif
  fs = hm_normexpr (fs, v);
  fs = regexprep (fs, '\.([*/^])', '$1');
  fs = regexprep (fs, '\s+', '');
  t = regexp (fs, '(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|[A-Za-z_]\w*|[+*/^(),-]', "match");
  if isempty (t) || ! strcmp (strjoin (t, ""), fs), error ("hm_fexcel: sintaxis escalar no soportada: %s", fs); endif
  [s, i] = suma (t, 1, v, ref);
  if i <= numel (t), error ("hm_fexcel: expresion incompleta cerca de %s", t{i}); endif
endfunction

function [s, i] = suma (t, i, v, ref)
  [s, i] = producto (t, i, v, ref);
  while i <= numel (t) && any (strcmp (t{i}, {"+","-"}))
    op = t{i}; [b, i] = producto (t, i+1, v, ref); s = ["(" s op b ")"];
  endwhile
endfunction

function [s, i] = producto (t, i, v, ref)
  [s, i] = signo (t, i, v, ref);
  while i <= numel (t) && any (strcmp (t{i}, {"*","/"}))
    op = t{i}; [b, i] = signo (t, i+1, v, ref); s = ["(" s op b ")"];
  endwhile
endfunction

function [s, i] = signo (t, i, v, ref)
  if i <= numel (t) && any (strcmp (t{i}, {"+","-"}))
    op = t{i}; [s, i] = signo (t, i+1, v, ref); s = ["(" op s ")"];
  else
    [s, i] = potencia (t, i, v, ref);
  endif
endfunction

function [s, i] = potencia (t, i, v, ref)
  [s, i] = atomo (t, i, v, ref);
  % Octave encadena potencias de izquierda a derecha. El signo del
  % exponente se aplica a su atomo, sin consumir la siguiente potencia.
  while i <= numel (t) && strcmp (t{i}, "^")
    i++; pref = "";
    while i <= numel (t) && any (strcmp (t{i}, {"+","-"})), pref = [pref t{i}]; i++; endwhile
    [b, i] = atomo (t, i, v, ref);
    for k = numel (pref):-1:1, b = ["(" pref(k) b ")"]; endfor
    s = ["(" s "^" b ")"];
  endwhile
endfunction

function [s, i] = atomo (t, i, v, ref)
  if i > numel (t), error ("hm_fexcel: falta operando"); endif
  a = t{i}; i++;
  if strcmp (a, "(")
    [s, i] = suma (t, i, v, ref);
    if i > numel (t) || ! strcmp (t{i}, ")"), error ("hm_fexcel: falta parentesis"); endif
    i++; return;
  endif
  if ! isempty (regexp (a, '^(\d|\.\d)', "once")), s = a; return; endif
  j = find (strcmp (a, v), 1);
  if ! isempty (j), s = ["(" ref{j} ")"]; return; endif
  if strcmp (a, "pi"), s = "PI()"; return; endif
  nombres = {"exp","sin","cos","tan","sqrt","abs","log","ln","log10","asin","acos","atan"};
  excel = {"EXP","SIN","COS","TAN","SQRT","ABS","LN","LN","LOG10","ASIN","ACOS","ATAN"};
  j = find (strcmp (a, nombres), 1);
  if isempty (j), error ("hm_fexcel: nombre no soportado: %s", a); endif
  if i > numel (t) || ! strcmp (t{i}, "("), error ("hm_fexcel: falta argumento de %s", a); endif
  [b, i] = suma (t, i+1, v, ref);
  if i > numel (t) || ! strcmp (t{i}, ")"), error ("hm_fexcel: %s necesita un argumento y parentesis", a); endif
  i++; s = [excel{j} "(" b ")"];
endfunction
