% anss12 [lo que quieres]  ->  anss 12 [lo que quieres]  (analiza de nuevo el ejercicio 12 con tu nota y lo resuelve)
function anss12 (varargin)
  anss (12, varargin{:});
endfunction
