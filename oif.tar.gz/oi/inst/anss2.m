% anss2 [lo que quieres]  ->  anss 2 [lo que quieres]  (analiza de nuevo el ejercicio 2 con tu nota y lo resuelve)
function anss2 (varargin)
  anss (2, varargin{:});
endfunction
