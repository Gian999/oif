% ss5  ->  ss 5
function ss5 ()
  ss (5);
endfunction
