% ss5 [nota]  ->  ss 5 [nota]
function ss5 (varargin)
  ss (5, varargin{:});
endfunction
