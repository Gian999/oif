% ia  -  atajo de octavei (mismo comando con el nombre viejo).   ia   |   ia 3
function varargout = ia (varargin)
  [varargout{1:nargout}] = octavei (varargin{:});
endfunction
