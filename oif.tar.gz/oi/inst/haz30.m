% haz30  ->  haz 30
function haz30 ()
  haz ("30");
endfunction
