% haz12  ->  haz 12
function haz12 ()
  haz ("12");
endfunction
