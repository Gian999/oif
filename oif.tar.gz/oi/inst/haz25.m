% haz25  ->  haz 25
function haz25 ()
  haz ("25");
endfunction
