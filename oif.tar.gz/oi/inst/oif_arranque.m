% oif_arranque  -  al hacer  pkg load oi  pide UNA vez la contrasena de la clave de Claude (Enter = omitir y usar Codex).
function oif_arranque ()
  try
    if ! isempty (getenv ("ANTHROPIC_API_KEY")) || ! isempty (getenv ("OPENAI_API_KEY")) || ! isempty (getenv ("OCT_IA_PROVIDER")), return; endif
    d = fullfile (oif_home (), ".oif");
    if exist (fullfile (d, "omitido"), "file") || isempty (oif_clave ()), return; endif
    fk = fullfile (d, "anthropic_key");
    if exist (fk, "file")
      fid = fopen (fk, "r"); k = strtrim (fread (fid, Inf, "char=>char")'); fclose (fid); setenv ("ANTHROPIC_API_KEY", k); return;
    endif
    oif_setup ();
  catch
  end_try_catch
endfunction
