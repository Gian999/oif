% oif_arranque  -  al cargar el paquete avisa (sin preguntar) si falta activar la clave de Claude; el aviso dice que escribir.
function oif_arranque ()
  try
    if ! isempty (getenv ("ANTHROPIC_API_KEY")) || ! isempty (getenv ("OPENAI_API_KEY")) || ! isempty (getenv ("OCT_IA_PROVIDER")), return; endif
    d = fullfile (oif_home (), ".oif");
    if exist (fullfile (d, "omitido"), "file") || isempty (oif_clave ()), return; endif
    fk = fullfile (d, "anthropic_key");
    if exist (fk, "file")
      fid = fopen (fk, "r"); k = strtrim (fread (fid, Inf, "char=>char")'); fclose (fid); setenv ("ANTHROPIC_API_KEY", k); return;
    endif
    printf ("\n  oi: para activar Claude escribe  oif_setup  y luego tu contrasena (Enter = omitir y usar Codex)\n\n");
  catch
  end_try_catch
endfunction
