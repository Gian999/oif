% [p, pdf] = hm_arrobas (pregunta)  -  deja escribir  @nombre  SIN extension dentro de la pregunta de octavei, como en haz:
%   busca en la carpeta actual  nombre.png/.jpg/.jpeg/.webp/.gif, luego .pdf y al final .xlsx (tambien ejNOMBRE, ejeNOMBRE, ejercicioNOMBRE, ejerNOMBRE, eNOMBRE),
%   sin importar mayusculas. Si lo encuentra, lo reescribe como  @"archivo.ext";  si no, lo deja igual.
%   pdf = ruta del PDF si la pregunta trae uno (octavei lo trata como  haz archivo.pdf).
function [p, pdf] = hm_arrobas (p)
  pdf = "";
  if ~ ischar (p) || isempty (strfind (p, "@")), return; endif
  [ini, fin, ~, ~, tk] = regexp (p, '@(?:"([^"]+)"|([^\s"]+))');
  for i = numel (ini):-1:1
    t = tk{i}{find (~ cellfun (@isempty, tk{i}), 1)};
    cola = "";
    if isempty (regexpi (t, '\.(png|jpe?g|webp|gif|xlsx|pdf)$', "once"))
      cola = regexp (t, '[.,;:!?)]+$', "match", "once"); if isempty (cola), cola = ""; endif
      t = t(1:end-numel (cola));
      f = buscar (t);
      if isempty (f)
        if ~ isempty (regexp (t, '^[A-Za-z0-9_-]+$', "once")), error ("octavei: no encuentro @%s en la carpeta actual (%s): busco %s.png, .jpg, .pdf o .xlsx (tambien ej%s, eje%s...)", t, pwd (), t, t, t); endif
        continue
      endif
      p = [p(1:ini(i)-1) '@"' f '"' cola p(fin(i)+1:end)];
    endif
  endfor
  m = regexp (p, '@(?:"([^"]+\.pdf)"|(\S+\.pdf))', "tokens", "once", "ignorecase");
  if ~ isempty (m)
    pdf = make_absolute_filename (m{find (~ cellfun (@isempty, m), 1)});
    if exist (pdf, "file") ~= 2, error ("octavei: no encuentro el PDF %s", pdf); endif
  endif
endfunction

function f = buscar (n)
  f = ""; n = strtrim (n);
  if isempty (n), return; endif
  [d, b, e] = fileparts (n);
  if ~ isempty (e) && ~ isempty (regexpi (e, '^\.(png|jpe?g|webp|gif|pdf|xlsx)$', "once")), return; endif
  b = [b e];
  if isempty (d), d = pwd (); endif
  L = dir (d); nom = {L(~ [L.isdir]).name};
  pre = {"", "ej", "eje", "ejercicio", "ejer", "e"}; ext = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".pdf", ".xlsx"};
  for j = 1:numel (ext)
    for i = 1:numel (pre)
      k = find (strcmpi (nom, [pre{i} b ext{j}]), 1);
      if ~ isempty (k)
        f = nom{k}; if ~ strcmp (d, pwd ()), f = fullfile (d, f); endif
        return
      endif
    endfor
  endfor
endfunction
