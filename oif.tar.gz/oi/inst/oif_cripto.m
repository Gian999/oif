% oif_cripto  -  cifrado con contrasena (sha256 iterado + flujo + marca de integridad). Uso interno de oif_cifrar / oifs.
function r = oif_cripto (op, txt, pass, salt)
  switch op
    case "cifrar"
      salt = sprintf ("%02x", floor (rand (1, 16) * 256));
      k = kdf (pass, salt); b = double (txt(:)'); ct = bitxor (uint8 (b), flujo (k, numel (b)));
      hx = sprintf ("%02x", ct); r = ["v1:" salt ":" hx ":" hash("sha256", [k "mac" hx])];
    case "descifrar"
      p = strsplit (txt, ":");
      if numel (p) ~= 4 || ~ strcmp (p{1}, "v1"), error ("oif: formato de clave cifrada no valido"); endif
      k = kdf (pass, p{2});
      if ~ strcmp (hash ("sha256", [k "mac" p{3}]), p{4}), error ("oif: contrasena incorrecta"); endif
      ct = uint8 (sscanf (p{3}, "%2x")'); r = char (bitxor (ct, flujo (k, numel (ct))));
  endswitch
endfunction

function k = kdf (pass, salt)
  k = hash ("sha256", [pass salt]);
  for i = 1:300000, k = hash ("sha256", [k pass]); endfor
endfunction

function f = flujo (k, n)
  f = zeros (1, 0, "uint8"); c = 0;
  while numel (f) < n, f = [f uint8(sscanf (hash ("sha256", [k sprintf("%d", c)]), "%2x")')]; c = c + 1; endwhile
  f = f(1:n);
endfunction
