% haz22  ->  haz 22
function haz22 ()
  haz ("22");
endfunction
