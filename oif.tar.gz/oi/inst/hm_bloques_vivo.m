% hm_bloques_vivo(nombre, titulo, X0, fform, texto, K, tipoE, dec, op)
% Hoja con tu formato (A3 titulo, notas en B desde fila 5, G7:I7 = I | Xi | E, un bloque de n filas por iteracion)
% pero con FORMULAS VIVAS. fform(j, prev, cur [, k]) -> texto de formula para la variable j (prev/cur = celdas)
% tipoE: "inf" (max |Xk+1-Xk|) o "rel" (|(x1-x0)/x1|*100 para 1 variable)
% op (opcional): hdrE = encabezado de la columna de error ("E" o "Ei"), c0 = columna de I (7), r0 = fila del encabezado (7), tpos = [fila col] del titulo ([3 1]), notas = [fila col] de las notas ([5 2]; [] = sin notas)
function Cl = hm_bloques_vivo (nombre, titulo, X0, fform, texto, K, tipoE, dec, op)
  if nargin < 8, dec = []; endif
  if nargin < 9, op = struct (); endif
  c0 = 7; r0 = 7; tpos = [3 1]; npos = [5 2];
  if isfield (op, "c0"), c0 = op.c0; endif
  if isfield (op, "r0"), r0 = op.r0; endif
  if isfield (op, "tpos"), tpos = op.tpos; endif
  if isfield (op, "notas"), npos = op.notas; endif
  n = numel (X0); cx = hm_col_excel (c0 + 1);
  Cl = cell (max ([r0 + 1 + (K+1)*n, 6 + numel(texto), tpos(1)]), max (9, c0 + 2));
  if ~ isempty (titulo), Cl{tpos(1), tpos(2)} = titulo; endif
  if ~ isempty (npos), for i = 1:numel (texto), Cl{npos(1)+i-1, npos(2)} = texto{i}; endfor, endif
  hdrE = merge (strcmp (tipoE, "rel"), "Ei", "E"); if isfield (op, "hdrE"), hdrE = op.hdrE; endif
  Cl{r0,c0} = "I"; Cl{r0,c0+1} = "Xi"; Cl{r0,c0+2} = hdrE;
  con4 = nargin (fform) >= 4 || nargin (fform) < 0;
  for k = 0:K
    r = r0 + 1 + k*n; Cl{r,c0} = k;
    for j = 1:n
      if k == 0, Cl{r+j-1,c0+1} = X0(j);
      else
        prev = arrayfun (@(m) sprintf ("%s%d", cx, r - n + m - 1), 1:n, "UniformOutput", false);
        cur  = arrayfun (@(m) sprintf ("%s%d", cx, r + m - 1), 1:n, "UniformOutput", false);
        if con4, formula = fform (j, prev, cur, k); else, formula = fform (j, prev, cur); endif
        if ~ isempty (dec), formula = sprintf ("ROUND(%s,%d)", formula, dec); endif
        Cl{r+j-1,c0+1} = ["=" formula];
      endif
    endfor
    if k > 0
      if strcmp (tipoE, "rel"), Cl{r,c0+2} = sprintf ("=ABS((%s%d-%s%d)/%s%d)*100", cx, r, cx, r-n, cx, r);
      else
        t = arrayfun (@(m) sprintf ("ABS(%s%d-%s%d)", cx, r+m-1, cx, r-n+m-1), 1:n, "UniformOutput", false);
        Cl{r,c0+2} = ["=MAX(" strjoin(t, ",") ")"];
      endif
    endif
  endfor
  if isempty (nombre), return; endif
  hm_xlsx ([nombre ".xlsx"], Cl);
  printf ("  guardado en %s : %s.xlsx (formato de tus hojas, formulas vivas)\n", pwd, nombre);
endfunction
