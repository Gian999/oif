% haz1  ->  haz 1
function haz1 ()
  haz ("1");
endfunction
