% haz13  ->  haz 13
function haz13 ()
  haz ("13");
endfunction
