% Punto fijo para SISTEMAS no lineales (2 ecuaciones, x e y)  [Unidad 2]
% TUS COMANDOS (clase 03, partes 1-3):
%   f1=inline('x^2-10*x+y^2+8','x','y'); f2=inline('x*y^2+x-10*y+8','x','y')
%   ezplot(f1); hold on; ezplot(f2)          % ver donde se cruzan (punto inicial)
%   g1=(x^2+y^2+8)/10 ; g2=(x*y^2+x+8)/10    % despeje x=g1(x,y), y=g2(x,y)
%   dg1x=diff(g1,x); dg1y=diff(g1,y); dg2x=diff(g2,x); dg2y=diff(g2,y)
%   double(subs(dg1x,[x y],[2 3]))  ...     % derivadas en el punto
%   dg1x+dg2x   y   dg1y+dg2y               % columnas |.| < 1  -> converge
%   segunda opcion de despeje: g1=(-8-y^2)/(x-10) ; g2=(-8-x)/(x*y-10)
%   si no hay punto inicial se puede usar [0 0]
%   X0=[0;0]; x1=g1(x0,y0); y1=g2(x0,y0); X1=[x1;y1]; E1=norm(X1-X0,inf)
function [T, estado] = hm_puntofijo2 (ej, op)
  con_op = nargin >= 2; if ! con_op, op = struct (); endif
  T = []; estado = "sin iterar";
  ej = nargin > 0 && strcmp (ej, "ejemplo");
  printf ("\n1) ya tengo g1,g2 (x=g1(x,y), y=g2(x,y))\n2) tengo f1=0 y f2=0 (despejar automaticamente)\n");
  if ej, modo = 1; else modo = pedir ("opcion [1]: ", 1); endif
  def = [0 0];
  if evalin ("base", "exist('x0','var') && exist('y0','var')"), def = [evalin("base","x0") evalin("base","y0")]; endif
  if modo == 2
    s1 = ""; while isempty (s1), s1 = strtrim (hm_entrada ("f1(x,y) = ", "s")); endwhile
    s2 = ""; while isempty (s2), s2 = strtrim (hm_entrada ("f2(x,y) = ", "s")); endwhile
    f1 = fh (s1); f2 = fh (s2);
    g = strtrim (hm_entrada ("graficar las curvas f1=0 y f2=0 para ver el punto inicial? (s = si, Enter = no): ", "s"));
    if strcmpi (g, "s")
      try, ezplot (f1); hold on; ezplot (f2); hold off; catch e, disp (["  (no pude graficar: " e.message "]"]); end_try_catch
    endif
    p = pedir (sprintf ("punto inicial [x0 y0]  (Enter = [%g %g]): ", def), def);
    h = 1e-6; c1 = (f1 (p(1)+h, p(2)) - f1 (p(1)-h, p(2))) / (2*h); c2 = (f2 (p(1), p(2)+h) - f2 (p(1), p(2)-h)) / (2*h);
    if abs (c1) < 1e-8 || abs (c2) < 1e-8, disp ("  df1/dx o df2/dy es cero en ese punto: elige otro"); return; endif
    s1g = sprintf ("x-(%s)/(%.10g)", s1, c1); s2g = sprintf ("y-(%s)/(%.10g)", s2, c2);
    printf ("\ndespeje automatico (deja el termino lineal en cada ecuacion):\n  g1 = %s\n  g2 = %s\n", s1g, s2g);
    disp ("  (para x^2-10x+y^2+8 y x*y^2+x-10y+8 equivale a g1=(x^2+y^2+8)/10, g2=(x*y^2+x+8)/10 de tu clase)");
    r = strtrim (hm_entrada ("Enter = aceptar, o escribe tus propias g1,g2 con la opcion 1: ", "s"));
    g1 = fh (s1g); g2 = fh (s2g); gt1 = s1g; gt2 = s2g;
  else
    if ej, s1 = "(-8-y^2)/(x-10)"; s2 = "(-8-x)/(x*y-10)"; p = [0 0]; printf ("ejemplo de tu Clase 03 (segunda opcion de despeje):\n  g1=%s\n  g2=%s\n  punto inicial [0 0]\n", s1, s2);
    else
      s1 = ""; while isempty (s1), s1 = strtrim (hm_entrada ("g1(x,y) = ", "s")); endwhile
      s2 = ""; while isempty (s2), s2 = strtrim (hm_entrada ("g2(x,y) = ", "s")); endwhile
      p = pedir (sprintf ("punto inicial [x0 y0]  (Enter = [%g %g]): ", def), def);
    endif
    g1 = fh (s1); g2 = fh (s2); gt1 = s1; gt2 = s2;
  endif
  x = p(1); y = p(2); h = 1e-6;
  dg1x = (g1 (x+h, y) - g1 (x-h, y)) / (2*h); dg1y = (g1 (x, y+h) - g1 (x, y-h)) / (2*h);
  dg2x = (g2 (x+h, y) - g2 (x-h, y)) / (2*h); dg2y = (g2 (x, y+h) - g2 (x, y-h)) / (2*h);
  printf ("\nderivadas en (%g,%g):\n  dg1x=%.4f  dg1y=%.4f\n  dg2x=%.4f  dg2y=%.4f\n", x, y, dg1x, dg1y, dg2x, dg2y);
  c1 = abs (dg1x) + abs (dg2x); c2 = abs (dg1y) + abs (dg2y);
  printf ("\ncolumnas: |dg1x|+|dg2x| = %.4f   |dg1y|+|dg2y| = %.4f\n", c1, c2);
  printf ("radio espectral del jacobiano de G = %.4f\n", max (abs (eig ([dg1x dg1y; dg2x dg2y]))));
  if max (c1, c2) < 1, disp ("  columnas < 1 en este punto: indicio local, no garantia para todo el recorrido");
  else, disp ("  alguna columna >= 1: puede NO converger (prueba otro despeje u otro punto inicial)"); endif
  if ej, tol = 1e-4; else tol = pedir ("tolerancia [Enter = 1e-6]: ", 1e-6); endif
  if numel (p) != 2 || ! all (isfinite (p)) || ! isscalar (tol) || ! isfinite (tol) || tol <= 0
    error ("hm_puntofijo2: punto inicial de dos valores finitos y tolerancia positiva finita");
  endif
  reglas = hm_reglas (op, tol, 200, ! ej && ! con_op);
  tol = reglas.tolerancia;
  printf ("Reglas: decimales=%s; iteraciones=%s; tolerancia=%g\n", mat2str(reglas.decimales), mat2str(reglas.iteraciones), tol);
  X = [x; y];
  if ! isempty(reglas.decimales)
    printf("  %% En cada paso redondea x1 e y1 ANTES de formar X1 y calcular E1:\n  x1=round(x1*10^%d)/10^%d\n  y1=round(y1*10^%d)/10^%d\n",reglas.decimales,reglas.decimales,reglas.decimales,reglas.decimales);
  endif
  printf ("\n   k        x            y         error (norma inf)\n");
  T = [0 x y NaN];
  for k = 1:reglas.limite
    Xn = hm_redondear ([g1(X(1), X(2)); g2(X(1), X(2))], reglas.decimales); E = norm (Xn - X, inf);
    printf ("  %3d  %11.6f  %11.6f   %.3e\n", k, Xn(1), Xn(2), E);
    T(end+1,:) = [k Xn(1) Xn(2) E]; X = Xn;
    if (isempty (reglas.iteraciones) && E < tol) || ! all (isfinite (X)), break; endif
  endfor
  ok = E < tol && all (isfinite (X));
  estado = "limite sin tolerancia";
  if ! all (isfinite (X)), estado = "valores no finitos";
  elseif ok, estado = "tolerancia alcanzada";
  elseif ! isempty (reglas.iteraciones), estado = "iteraciones solicitadas completadas";
  endif
  printf ("Estado: %s; iteraciones realizadas=%d\n", estado, rows(T)-1);

  printf ("\n%s x=%.6f  y=%.6f\n", merge (ok, "solucion ~", merge (all (isfinite (X)), "NO se alcanzo la tolerancia; ultimo valor", "DIVERGIO; ultimo valor")), X(1), X(2));
  printf ("(la revision de derivadas se hizo en el punto inicial; revisa el recorrido, la tolerancia y las ecuaciones originales)\n");
  assignin ("base", "X", X);
  texto = {sprintf("g1 = %s", gt1), sprintf("g2 = %s", gt2), sprintf("dg1x=%.4f dg1y=%.4f dg2x=%.4f dg2y=%.4f en (%g,%g)", dg1x, dg1y, dg2x, dg2y, p(1), p(2)), sprintf("Columnas: %.4f y %.4f -> %s", c1, c2, merge (max (c1, c2) < 1, "converge", "revisar convergencia")), merge(ok, sprintf("Conclusion: x=%.6f, y=%.6f en %d iteraciones.", X(1), X(2), k), sprintf("Conclusion: tolerancia NO alcanzada (con iteraciones fijas es lo esperado) (ultimo x=%.6g, y=%.6g tras %d iteraciones).", X(1), X(2), k))};
  texto{end+1} = sprintf ("Estado: %s; decimales=%s; iteraciones=%s; tolerancia=%g", estado, mat2str(reglas.decimales), mat2str(reglas.iteraciones), tol);
  nom = merge (ej, "puntofijo_ejemplo", "");
  if isfield (op, "exportar"), nom = op.exportar; endif
  if isequal (nom, false), return; endif
  if isempty (nom), nom = strtrim (hm_entrada ("exportar en el formato de tus hojas (formulas vivas)? Enter = no, o nombre (ej. pf2): ", "s")); endif
  if ! isempty (nom)
    gts = {gt1, gt2};
    hm_bloques_vivo (nom, "Resolucion metodo del punto fijo U2", p(:), @(j, prev, cur) hm_fexcel (gts{j}, {"x","y"}, {prev{1}, prev{2}}), texto, rows (T) - 1, "inf", reglas.decimales);
  endif
endfunction

function f = fh (s)
  f = str2func (["@(x,y) " regexprep(s, '(?<![.])([*/^])', '.$1')]);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction

function exportar_bloques (nombre, titulo, hdrE, T, texto)
  % Formato de tus hojas: A3 titulo | notas en B | G7:I7 = I, Xi, E | un bloque de filas por iteracion
  if isempty (nombre)
    nombre = strtrim (hm_entrada ("exportar en el formato de tus hojas de Excel/ODS? Enter = no, o escribe un nombre (ej. gs1): ", "s"));
    if isempty (nombre), return; endif
  endif
  n = columns (T) - 2; K = rows (T);
  Cl = cell (max (8 + K*n + 1, 6 + numel (texto)), 9);
  Cl{3,1} = titulo;
  for i = 1:numel (texto), Cl{4+i,2} = texto{i}; endfor
  Cl{7,7} = "I"; Cl{7,8} = "Xi"; Cl{7,9} = hdrE;
  for i = 1:K
    r = 8 + (i-1)*n; Cl{r,7} = T(i,1);
    for j = 1:n, Cl{r+j-1,8} = round (T(i,1+j) * 1e6) / 1e6; endfor
    if i > 1 && ! isnan (T(i,end)), Cl{r,9} = T(i,end); endif
  endfor
  arch = [nombre ".csv"]; fid = fopen (arch, "w");
  fprintf (fid, "I,%s,E\n", strjoin (arrayfun (@(i) sprintf ("x%d", i), 1:n, "UniformOutput", false), ","));
  fclose (fid); dlmwrite (arch, T, "-append", "precision", "%.10g");
  try
    pkg load io; xlswrite ([nombre ".xlsx"], Cl); odswrite ([nombre ".ods"], Cl);
    printf ("  guardado en %s : %s.xlsx  y  %s.ods  (columnas I | Xi | E, como tus hojas)\n", pwd, nombre, nombre);
  catch
    printf ("  guardado %s (faltan el paquete io o Java para .xlsx/.ods; abre el .csv)\n", fullfile (pwd, arch));
  end_try_catch
endfunction

function L = despejes (A, b)
  n = rows (A); L = cell (1, n);
  for i = 1:n
    t = sprintf ("x%d = %s", i, num2str (b(i) / A(i,i), 6));
    for j = [1:i-1, i+1:n]
      c = -A(i,j) / A(i,i);
      if c != 0, t = [t sprintf(" %s %s*x%d", merge (c < 0, "-", "+"), num2str (abs (c), 6), j)]; endif
    endfor
    L{i} = t;
  endfor
endfunction
