% Interpolacion: curva que pasa por los puntos dados
% TUS COMANDOS (clase S5C13):
%   x=[-pi/2 0 pi/2]'; y=[0 1 0]'; plot(x,y,'*'); hold on
%   f1=inline('2/pi*x+1','x'); ezplot(f1)              % recta entre 2 puntos
%   f2=inline('(-4/pi^2)*x^2+1','x'); ezplot(f2)       % parabola por los 3 puntos
%   (con polyfit sale directo:  p=polyfit(x,y,length(x)-1))
function hm_interpola (modo)
  if nargin && strncmpi (modo, "lag", 3), lagrange_pasos (); return; endif
  disp ("  (para el polinomio de Lagrange paso a paso:  hm_interpola(\"lagrange\"))");
  x = pedir ("x, ej [-pi/2 0 pi/2]: "); y = pedir ("y, ej [0 1 0]: "); x = x(:); y = y(:);
  n = numel (x);
  p = polyfit (x, y, n - 1);
  t = ""; for i = 1:n, t = [t sprintf("%+.4f*x^%d ", p(i), n - i)]; endfor
  printf ("\npolinomio de grado %d por los %d puntos:\n  y = %s\n", n - 1, n, strrep (t, "*x^0", ""));
  plot (x, y, "*"); hold on
  xx = linspace (min (x), max (x), 300);
  plot (xx, polyval (p, xx)); plot (xx, interp1 (x, y, xx, "linear"), "--"); hold off
  legend ("puntos", "polinomio", "lineal por tramos");
  xe = pedir ("evaluar en x = (Enter = no evaluar): ", []);
  if ! isempty (xe), printf ("  polinomio: %.6f   lineal por tramos: %.6f\n", polyval (p, xe), interp1 (x, y, xe, "linear")); endif
  assignin ("base", "p", p);
endfunction

function lagrange_pasos ()
  % Como tu clase S5C13 / hoja "Ejemplo2": nodos x,y ; grado g ; los g+1 nodos mas cercanos a x ; P(x)=y0*L0(x)+y1*L1(x)+...
  x = pedir ("nodos x, ej [2 2.2 2.4 2.6 2.8]: "); y = pedir ("nodos y: "); x = x(:); y = y(:);
  xe = pedir ("x a evaluar, ej 2.5: "); g = pedir ("grado, ej 1 o 2 [Enter = 2]: ", 2);
  [~, ix] = sort (abs (x - xe)); ix = sort (ix(1:g+1)); xs = x(ix); ys = y(ix); m = g + 1;
  printf ("\nGRADO %d, x = %g, nodos usados:\n", g, xe);
  for i = 1:m, printf ("  x%d = %g   y%d = %.7g\n", i-1, xs(i), i-1, ys(i)); endfor
  L = zeros (m, 1);
  for i = 1:m
    o = [1:i-1, i+1:m]; L(i) = prod ((xe - xs(o)) ./ (xs(i) - xs(o)));
    printf ("  L%d(x) = %s = %.7g\n", i-1, strjoin (arrayfun (@(j) sprintf ("(x-%g)/(%g-%g)", xs(j), xs(i), xs(j)), o, "UniformOutput", false), "*"), L(i));
  endfor
  Px = sum (ys .* L);
  printf ("  P%d(x) = %s\n  P%d(%g) = %.7f\n", g, strjoin (arrayfun (@(i) sprintf ("y%d*L%d(x)", i-1, i-1), 1:m, "UniformOutput", false), " + "), g, xe, Px);
  assignin ("base", "Px", Px);
  nom = strtrim (hm_entrada ("exportar hoja con formulas vivas? Enter = no, o nombre (ej. lag1): ", "s"));
  if isempty (nom), return; endif
  Cl = cell (8 + m, 8); Cl{2,1} = sprintf ("Polinomio interpolante de Lagrange, grado %d", g);
  Cl{4,1} = "x"; Cl{4,2} = "y"; Cl{4,4} = "x="; Cl{4,5} = xe;
  for i = 1:m
    r = 5 + i; Cl{r,1} = xs(i); Cl{r,2} = ys(i);
    o = [1:i-1, i+1:m];
    t = arrayfun (@(j) sprintf ("($E$4-A%d)/(A%d-A%d)", 5+j, r, 5+j), o, "UniformOutput", false);
    Cl{r,3} = ["=" strjoin(t, "*")]; Cl{r,4} = sprintf ("L%d", i-1);
  endfor
  Cl{5,3} = "Li(x)"; Cl{6+m+1,1} = sprintf ("P%d(x)=", g); Cl{6+m+1,2} = sprintf ("=SUMPRODUCT(B6:B%d,C6:C%d)", 5+m, 5+m);
  hm_xlsx ([nom ".xlsx"], Cl); printf ("  guardado en %s : %s.xlsx (formulas vivas)\n", pwd, nom);
endfunction

function v = pedir (txt, def)
  while true
    s = strtrim (hm_entrada (txt, "s"));
    if isempty (s)
      if nargin > 1, v = def; return; endif
      continue
    endif
    try
      if strncmpi (s, "excel ", 6) || strncmpi (s, "leer ", 5)
        v = leer_tabla (s);
      else
        v = evalin ("base", s);
      endif
      return
    catch e
      disp (["  no entendi: " e.message]);
    end_try_catch
  endwhile
endfunction

function v = leer_tabla (s)
  % uso:  excel archivo.xlsx B4:D9   (tambien .ods o .csv; 3er dato = hoja)
  p = strtrim (s); p = strtrim (p(find (isspace (p), 1):end));
  tok = regexp (p, "\"[^\"]*\"|'[^']*'|\\S+", "match"); tok = cellfun (@(t) regexprep (t, "^[\"']|[\"']$", ""), tok, "UniformOutput", false); arch = tok{1};
  rango = ""; hoja = 1;
  if numel (tok) >= 2, rango = tok{2}; endif
  if numel (tok) >= 3, hoja = tok{3}; if ! isnan (str2double (hoja)), hoja = str2double (hoja); endif, endif
  [~, ~, ext] = fileparts (lower (arch));
  if strcmp (ext, ".csv")
    if isempty (rango), v = dlmread (arch, ","); else v = dlmread (arch, ",", rango); endif
  else
    pkg load io;
    if strcmp (ext, ".ods"), f = @odsread; else f = @xlsread; endif
    if isempty (rango), v = f (arch, hoja); else v = f (arch, hoja, rango); endif
  endif
  printf ("  leido %dx%d de %s\n", rows (v), columns (v), arch);
endfunction

function exportar_tabla (hdr, M)
  r = strtrim (hm_entrada ("exportar la tabla para tu evidencia? Enter = no, o escribe un nombre (ej. jacobi1): ", "s"));
  if isempty (r), return; endif
  arch = [r ".csv"]; fid = fopen (arch, "w"); fprintf (fid, "%s\n", strjoin (hdr, ",")); fclose (fid);
  dlmwrite (arch, M, "-append", "precision", "%.10g");
  printf ("  guardado: %s\n", fullfile (pwd, arch));
  try
    pkg load io; datos = [hdr; num2cell(M)];
    xlswrite ([r ".xlsx"], datos); odswrite ([r ".ods"], datos);
    printf ("  guardado: %s.xlsx  y  %s.ods\n", r, r);
  catch
    disp ("  (.xlsx/.ods no disponibles: falta el paquete io o Java; abre el .csv con Excel/LibreOffice)");
  end_try_catch
endfunction
