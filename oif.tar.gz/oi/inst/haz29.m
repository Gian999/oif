% haz29  ->  haz 29
function haz29 ()
  haz ("29");
endfunction
