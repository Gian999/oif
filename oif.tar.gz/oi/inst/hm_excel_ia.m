% hm_excel_ia (texto, libro)  -  convierte el bloque ```excel (JSON) de la respuesta de la IA en un .xlsx (formulas vivas, una sola hoja).
% Lo usa exportar. Si trae libro (@mi_libro.xlsx) agrega la hoja a una COPIA del libro. Devuelve el texto sin el bloque, mas el aviso.
function o = hm_excel_ia (t, libro, acum)
  if nargin < 3, acum = []; endif
  % si la IA mando un bloque ```excel con JSON, lo convierte en .xlsx (formulas vivas) y lo quita del texto
  o = t;
  [tok, rest] = regexp (t, '```excel\s*\n([\s\S]*?)```', "tokens", "split");
  if isempty (tok), return; endif
  o = strtrim (strjoin (rest, ""));
  try
    J = jsondecode (tok{1}{1});
    directo = false;
    if isfield (J, "plantilla")
      % plantilla: la IA solo manda los DATOS del enunciado y el programa arma la hoja (misma forma de tus hojas, sin errores de rotulado)
      d = rmfield (J, "plantilla"); cp = fieldnames (d);
      for k = 1:numel (cp), v = d.(cp{k}); if isnumeric (v) && ! isscalar (v) && ! any (strcmp (cp{k}, {"A", "B", "J"})), d.(cp{k}) = v(:)'; endif, endfor
      pl = lower (J.plantilla);
      if strcmp (pl, "newton"), d.newton = true; if ! isfield (d, "grados"), d.grados = []; endif
      elseif strcmp (pl, "lagrange"), d.lagrange = true; if ! isfield (d, "grados"), d.grados = []; endif
      elseif any (strcmp (pl, {"interpolacion", "interp"})), d.interp = true;
      elseif strcmp (pl, "examen"), d.examen = true;
      elseif any (strcmp (pl, {"newtonsistemas", "newton-sistemas"})), d.iter = "newton";
      elseif strcmp (pl, "puntofijo"), d.iter = "puntofijo";
      elseif any (strcmp (pl, {"jacobi", "gaussseidel", "gauss-seidel"})), d.iter = "matricial"; if ! strcmp (pl, "jacobi"), d.gs = true; endif; if isfield (d, "C"), d.Cv = d.C; d = rmfield (d, "C"); endif
      elseif ! any (strcmp (pl, {"regresion", "multiple"})), error ("plantilla desconocida: %s", J.plantilla); endif
      if ! isfield (d, "titulo"), d.titulo = "Ejercicio"; endif
      Cs = {hm_ej_xlsx("", d)}; nom = {d.titulo}; directo = true;
    else
      hojas = J.hojas; if ! iscell (hojas), hojas = num2cell (hojas); endif
      Cs = {}; nom = {};
      for k = 1:numel (hojas)
        h = hojas{k}; Cs{end+1} = arreglar (filas_a_celdas (h.filas)); Cs{end} = chequear (Cs{end}, sprintf ("hoja %d", k)); 
        if isfield (h, "nombre"), nom{end+1} = h.nombre; else, nom{end+1} = sprintf ("Hoja%d", k); endif
      endfor
    endif
    if ! isempty (acum)
      % un solo libro para todo el PDF: una hoja por ejercicio (se reescribe el libro con todas las hojas hechas hasta ahora)
      H = {}; try, H = getappdata (0, "oi_hojas"); catch, end
      if isempty (H), H = {}; endif
      nm = regexprep (sprintf ("Ej%d %s", acum.n, acum.titulo), '[\[\]:*?/\\]', " "); nm = strtrim (nm(1:min (end, 31)));
      nueva = struct ("n", acum.n, "nombre", nm, "C", {merge_C(directo, Cs, nom)});
      H = H(cellfun (@(h) h.n != acum.n, H)); H{end+1} = nueva;
      [~, ord] = sort (cellfun (@(h) h.n, H)); H = H(ord);
      hm_xlsx (acum.archivo, cellfun (@(h) h.C, H, "UniformOutput", false), cellfun (@(h) h.nombre, H, "UniformOutput", false));
      setappdata (0, "oi_hojas", H);
      [~, a1, a2] = fileparts (acum.archivo);
      o = [o sprintf("\n[%s%s]", a1, a2)];
      return
    endif
    base = "oi_ejercicio"; if isfield (J, "archivo") && ischar (J.archivo), base = regexprep (J.archivo, '[^A-Za-z0-9_-]', "_"); endif
    if isempty (base), base = "oi_ejercicio"; endif
    arch = [base ".xlsx"]; n = 1;
    while exist (arch, "file"), n++; arch = sprintf ("%s_%d.xlsx", base, n); endwhile
    if isempty (libro)
      hm_xlsx (arch, merge_C (directo, Cs, nom));
      o = [o sprintf("\n[%s]", arch)];
    else
      dest = hm_xlsx_agregar (libro, merge_C (directo, Cs, nom), strrep (base, "_", " "));
      o = [o sprintf("\n[%s]", dest)];
    endif
  catch err
    o = [o sprintf("\n[No pude generar el Excel: %s]", strtok (err.message, "\n"))];
  end_try_catch
endfunction

function C = merge_C (directo, Cs, nom)
  if directo, C = Cs{1}; else, C = hm_apilar (Cs, nom); endif
endfunction

function C = arreglar (C)
  % SUMPRODUCT(rango_columna, rango_fila) da #VALUE! en Excel: se expande a  a1*b1+a2*b2+...
  for k = 1:numel (C)
    v = C{k};
    if ischar (v) && ! isempty (v) && v(1) == "=" && ! isempty (strfind (upper (v), "SUMPRODUCT("))
      pat = '(?i)SUMPRODUCT\(\s*(\$?[A-Z]{1,3})(\$?)(\d+):(\$?[A-Z]{1,3})(\$?)(\d+)\s*,\s*(\$?[A-Z]{1,3})(\$?)(\d+):(\$?[A-Z]{1,3})(\$?)(\d+)\s*\)';
      [tk, m] = regexp (v, pat, "tokens", "match");
      for i = 1:numel (m)
        t = tk{i};
        a1 = t{1}; a2 = t{4}; b1 = t{7}; b2 = t{10};
        ra = [str2double(t{3}) str2double(t{6})]; rb = [str2double(t{9}) str2double(t{12})];
        colA = strcmp (strrep (a1, "$", ""), strrep (a2, "$", "")); colB = strcmp (strrep (b1, "$", ""), strrep (b2, "$", ""));
        if colA == colB, continue; endif
        n = ra(2) - ra(1) + 1; if ! colA, n = col2n (a2) - col2n (a1) + 1; endif
        nb = rb(2) - rb(1) + 1; if ! colB, nb = col2n (b2) - col2n (b1) + 1; endif
        if n != nb || n < 1 || n > 60, continue; endif
        p = cell (1, n);
        for j = 0:n-1
          if colA, ca = sprintf ("%s%s%d", a1, t{2}, ra(1)+j); else, ca = sprintf ("%s%s%d", n2col (col2n (a1)+j), t{2}, ra(1)); endif
          if colB, cb = sprintf ("%s%s%d", b1, t{8}, rb(1)+j); else, cb = sprintf ("%s%s%d", n2col (col2n (b1)+j), t{8}, rb(1)); endif
          p{j+1} = [ca "*" cb];
        endfor
        v = strrep (v, m{i}, ["(" strjoin(p, "+") ")"]);
      endfor
      C{k} = v;
    endif
  endfor
endfunction

function n = col2n (s)
  s = strrep (s, "$", ""); n = 0; for ch = upper (s), n = n*26 + double (ch) - 64; endfor
endfunction

function s = n2col (n)
  s = ""; while n > 0, r = mod (n-1, 26); s = [char(65+r) s]; n = (n-1-r)/26; endwhile
endfunction

function C = chequear (C, nom)
  % avisa de formulas con nombres que Excel no conoce (dan #NAME?)
  ok = {"SUM","SUMPRODUCT","IF","ABS","SQRT","MAX","MIN","AVERAGE","COUNT","ROUND","EXP","LN","LOG","LOG10","SIN","COS","TAN","ATAN","PI","POWER","INDEX","MATCH","MMULT","MINVERSE","TRANSPOSE","AND","OR","NOT","SUMSQ","SUMX2MY2","IFERROR","SIGN","ASIN","ACOS","SQRT","TEXT","INT","MOD","RSQ","SLOPE","INTERCEPT","LINEST","DEVSQ","STDEV","VAR","MDETERM","SUMIF","COUNTIF","ROWS","COLUMNS","TRUE","FALSE","E","ABS"};
  for k = 1:numel (C)
    v = C{k};
    if ischar (v) && ! isempty (v) && v(1) == "="
      s = regexprep (v, '"[^"]*"', ""); s = regexprep (s, '(?:''[^'']+''|[A-Za-z0-9_]+)!', ""); s = regexprep (s, '\$?[A-Za-z]{1,3}\$?[0-9]+', "0");
      t = regexp (s, '[A-Za-z_][A-Za-z_0-9.]*(?:\()?', "match");
      for q = t
        w = q{1}; fn = w(end) == "(";
        if fn, w(end) = []; endif
        if (fn && ! any (strcmpi (w, ok))) || (! fn && isempty (regexp (w, '^\$?[A-Za-z]{1,3}\$?[0-9]+$')) && ! any (strcmpi (w, ok)))
          [r, c] = ind2sub (size (C), k);
          printf ("  (aviso %s: la celda %d,%d usa '%s', que Excel no reconoce; la dejo vacia)\n", nom, r, c, w); C{k} = []; break;
        endif
      endfor
    endif
  endfor
endfunction

function C = filas_a_celdas (filas)
  if isnumeric (filas), filas = num2cell (filas, 2); endif
  if ! iscell (filas), filas = {filas}; endif
  nf = numel (filas); filasc = cell (nf, 1); nc = 1;
  for i = 1:nf
    r = filas{i};
    if isnumeric (r) || islogical (r), r = num2cell (r(:)'); 
    elseif ischar (r), r = {r};
    elseif iscell (r), r = r(:)';
    elseif isempty (r), r = {};
    else, error ("fila %d no valida", i); endif
    for j = 1:numel (r)
      v = r{j};
      if isempty (v), r{j} = []; elseif ! (ischar (v) || (isnumeric (v) && isscalar (v)) || islogical (v)), error ("celda no valida en fila %d", i); endif
    endfor
    filasc{i} = r; nc = max (nc, numel (r));
  endfor
  if nf > 500 || nc > 60, error ("hoja demasiado grande"); endif
  C = cell (nf, nc);
  for i = 1:nf, for j = 1:numel (filasc{i}), C{i,j} = filasc{i}{j}; endfor, endfor
endfunction



