% haz3  ->  haz 3
function haz3 ()
  haz ("3");
endfunction
