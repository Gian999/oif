% Redondeo de cada resultado de iteracion: mitades alejadas de cero (ROUND).
% Corrige solo empates a unas pocas ulp: 1.005 no debe bajar a 1.00 por
% representacion binaria. No redondea X0, coeficientes ni derivadas.
function v = hm_redondear (v, dec)
  if isempty(dec), return; endif
  u = v * 10^dec;
  mitad = floor(abs(u)) + 0.5;
  empate = isfinite(u) & abs(abs(u)-mitad) <= 4*eps(max(1,abs(u)));
  u(empate) = sign(u(empate)) .* mitad(empate);
  v = round(u) / 10^dec;
endfunction
