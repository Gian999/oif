
## Reglas del Excel de ia (v0.9.11, obligatorias)
- Un ejercicio completo = UNA sola hoja (partes apiladas), con margen: columna A y fila 1 vacias (como sus hojas).
- Un solo titulo por parte (sin repetir); respuesta final con {y} (amarillo); bordes solo en tablas (los pone hm_xlsx).
- Ninguna respuesta tipeada: todo resultado es formula viva que jala de la tabla (AVERAGE, SUM, SUMPRODUCT, MMULT, MINVERSE...); solo los datos del enunciado son numeros fijos. Interpretaciones pueden ser formulas de texto.
- Estas reglas estan en el system prompt de ia.m; ia.m desplaza referencias (filas y columnas) al apilar.

## Libros del usuario (v0.9.12)
- `hm_xlsx_agregar(origen, C, nombre)`: agrega una hoja a una COPIA del libro; copia crudo (byte a byte) todo lo del usuario (imagenes, graficos, formulas); solo cambian workbook.xml, rels, [Content_Types].xml y styles.xml (se agregan estilos al final).
- `ia("... @libro.xlsx")` usa esa funcion. Lo hecho a mano (imagenes de formulas, plots) nunca se inventa ni se toca.
- Sin verificar: abrir la copia en Microsoft Excel real; Windows (usa unzip de Octave).

## v0.10.0 (modo teclas, prompt octave:N, exportar simple)
- `ia` sin argumentos muestra el prompt `octave:N>` (N = siguiente numero real de la sesion, `hm_prompt_n`). `ia 3` / `ia dieta` / `ia 0` (lista) usan el catalogo `hm_catalogo` (8 ejercicios de regresion + 4 de clase); otra pregunta va a Codex/API.
- `hm_teclear`: una tecla = una letra del codigo; con la linea terminada otra tecla la ejecuta (evalin base); Esc sale. `OCT_IA_TECLAS=0` ejecuta todo sin teclas, `=texto` solo imprime (modo viejo). En la GUI de Octave (sin `kbhit`) una tecla/Enter = una linea completa.
- `exportar` (alias `export`): arma el Excel con formulas vivas (`hm_ej_xlsx`) del ultimo ejercicio de `ia`, de `exportar(N)` (catalogo) o de las variables de la sesion (x,y [ap] / x1,x2,y). Ya no escribe Excel automaticamente al preguntar a la IA: el bloque ```excel se guarda y sale con `exportar`.
- `hm_xlsx`: celdas `struct("v",valor,"s",0..4)` fuerzan el estilo (0 normal, 1 tabla, 2 negrita, 3 amarillo, 4 tabla+amarillo).
- ia.m: alcance "desde el 14 de septiembre". Sin verificar: kbhit en una terminal real (probado solo en un pty), GUI de Octave, Windows/macOS.

## v0.11.0 (paquete `oi`, comando `octavei`)
- Paquete renombrado: `oi` (antes octguias). Cargar con `pkg load oi`. Comando principal `octavei` (`ia` queda como atajo). Desinstalar el viejo: `pkg uninstall octguias`; en ~/.octaverc cambiar `pkg load octguias` por `pkg load oi`.
- El prompt para la IA (octavei.m, variable `sis`) ahora describe el estilo de las hojas de clase (tabla de calculo sin bordes, datos con {k}, cajitas, respuestas {Y}/{K}), la estructura de regresion de la hoja tarea (sin SST), "Comparacion" y "Me piden:", y las CAPTURAS: solo si el enunciado pide grafico o lo hecho en Octave se deja un titulo {b} y 20 filas vacias para pegar; nada se inventa ni se simula.
- hm_xlsx: marcas {n} sin borde, {k} con borde, {Y} amarillo sin borde, {K} amarillo con borde (ademas de {b}, {y}).
- Ejercicio de colesterol (inciso a): deja el titulo "Captura del diagrama de dispersion (pegar aqui)".

## v0.11.1
- `haz N` / `haz1`..`haz30`: resuelve la imagen N (N.png, ejN.png, ejeN.png, ejercicioN.png; png/jpg/webp) de la carpeta actual.
- Codex ya no cambia la carpeta de Octave (el explorador de la GUI no salta a /tmp): el `cd` va dentro del comando.
- Numero de prompt corregido en la GUI (ignora encabezados "# Octave" del historial). En la GUI, Enter = una linea.

## v0.11.2
- El Excel se guarda SOLO al terminar el ejercicio (catalogo o Codex), en la carpeta actual; solo se imprime `[nombre.xlsx]`, sin ruta ni textos. Si se detiene con Esc no se exporta. `exportar` sigue disponible a mano.

## v0.12.0
- `haz examen.pdf` (o `haz 1` si existe 1.pdf): convierte hasta 6 paginas (OCT_IA_PAGS) a imagenes con Ghostscript/pdftoppm, las manda a Codex en UNA consulta con el formato `@@EJ n | octave|excel | titulo` y guarda el plan. Luego `start1`, `start2`... (hasta `start12`; `start N`): tipo octave -> escribe el codigo con teclas y exporta el Excel solo; tipo excel -> solo exporta el Excel.

## v0.12.1
- `start N e` / `start N o` fuerzan solo Excel / con Octave si la lista marco mal. Prompt: criterio excel/octave segun lo que NO tiene diario de la docente; orden obligatorio antes de iterar (E.D.D. -> BJ y C -> verificar convergencia con normas/radio espectral -> iterar).

## v0.12.2
- Titulo vacio en la lista de start (fallback), y una linea "..." mientras Codex piensa.

## v0.12.2
- Titulo vacio en la lista de start (fallback) y una linea "..." mientras Codex piensa.

## v0.12.3
- start/catalogo mas discretos (sin titulo ni "presiona cualquier tecla"); en la GUI la linea sale en el mismo prompt; todos los ejercicios del PDF piden su Excel; numeracion de prompt corregida para la GUI (historial incremental).

## v0.13.0
- Comandos `ss1`..`ss12` / `ss N [e|o]` (reemplazan a start; `start` queda como alias).
- Las lineas que escribe el tool entran al historial de comandos (history -r); hm_prompt_n descuenta esas lineas (appdata oi_extra) para no desfasar los numeros.

## v0.13.1
- PDF: UN solo Excel para todo el PDF (nombre del PDF, en la carpeta actual), una hoja por ejercicio (Ej1 titulo, Ej2 ...); cada ssN agrega o reemplaza su hoja y las hojas quedan ordenadas por numero.

## v0.13.2
- El tool quita el ; final de cada linea para que siempre salga el resultado (OCT_IA_PUNTOYCOMA=1 los conserva).

## v0.14.0
- Catalogo 13: interpolacion de Newton (Ejemplo 4.4, solo Excel) con la forma de la hoja newthonRapshon de clase.xlsx (hm_ej_xlsx: generador newton). Prompt: Newton por diferencias divididas = solo Excel + su layout.

## v0.14.1
- Plantillas en el bloque excel de Codex: {"plantilla":"newton|regresion|multiple", datos...}; el programa arma la hoja con hm_ej_xlsx (misma forma que catalogo, sin errores de rotulado). hm_ej_xlsx("", d) devuelve las celdas.

## v0.15.0
- Catalogo 14: punto fijo (Clase 03). Excel con formulas vivas en formato `I | Xi | E` (reproduce su tabla: E9=5.2789e-05).
- Plantillas `puntofijo`, `jacobi`, `gaussseidel` (JSON, Codex solo da datos). `hm_bloques_vivo("")` devuelve celdas sin escribir.
- Newton de sistemas: sin plantilla (pendiente). Modo offline/por entradas: pendiente.

## v0.15.1
- Plantilla lagrange (formato Ejemplo2: cajita de nodos + Li(x) + P=SUMPRODUCT). Validador de formulas (avisa #NAME?). Prompt: reglas de formulas.

## v0.15.2
- apilar: referencias entre partes (a!C60, 'Recta'!B3) se resuelven al desplazamiento de esa parte (antes daban #NAME?).

## v0.15.3
- octavei: 'haz X', 'ssN', 'exportar' escritos dentro del prompt de octavei se ejecutan como comando (antes iban a Codex como pregunta).

## v0.15.4
- Marcas dobles {k}{b}x ya no salen literales; validador sin falsos avisos con $B$10; SUMPRODUCT fila x columna (#VALUE!) se expande a suma de productos.

## v0.16.0 (examen modelo)
- Layout de su ods "examenmodelo": por pregunta, titulo del metodo en fila 18 (A / F), tabla `I | Xi | Ei` desde fila 22 (B:D, F:H...), n filas por iteracion. Plantilla `examen` (metodos: newton | puntofijo | jacobi | gaussseidel) + `newtonsistemas`. Newton en Excel: J y F por iteracion en celdas auxiliares (a la derecha) y `X - INDEX(MMULT(MINVERSE(J),F),j)`.
- Catalogo 15 (pregunta 1: Newton + punto fijo 3x3, X0=(1,0,0), 2 iteraciones) y 16 (pregunta 2: Jacobi con despeje en comentarios). Claves: "modelo p1", "modelo p2".
- Newton de sistemas: SIN comprobar jacobiano; X0 sin transpuesta; el prompt exige el despeje (comentarios %) antes de BJ en Jacobi/GS.
- Nota: el diario del estudiante tenia BJ(3,:)=[0 0 1/2] (error); correcto [0 1/2 0] (z=y/2). El Excel del estudiante ya tenia z2=0.875.

## v0.16.1
- Celdas auxiliares J/F del Newton en Excel: columnas ocultas (marca {h}). Comprobar jacobiano/convergencia: solo si el enunciado lo pide, explicado con comentarios %.

## v0.17.0 (interpolacion)
- hm_apilar.m publico (antes interno de hm_excel_ia): apila partes, quita filas vacias iniciales, respeta estilos (struct v,s) y entiende referencias entre partes ('nombre'!C6).
- hm_ej_xlsx: segunda salida `info` (posiciones de P/x/error); lagrange: `casos` (idx de nodos elegidos + rotulo) y `fexacta` (f(x) exacto y error absoluto); newton: `fexacta`, `rotulo`, fila "Mas apropiado" (menor error).
- Libro de ejemplo: Interpolacion_4.2_4.3_ej1_ej2.xlsx (generado con un script a partir de estos bloques).

## v0.17.1
- Lagrange ahora con la forma EXACTA de la hoja Ejemplo2 de clase.xlsx: NODOS en A14, cajitas "GRADOn | x= | valor", nodos x0 y0.., P(x)=y0L0(x)+.., L0(x)=(x-x1)/(x0-x1) y L0(valor)=, P(valor)= amarillo; cajitas de a dos (columnas E y L) hacia abajo. Sin columnas extra (nada de exacto/error ni bloques "Me piden"): solo lo que pide el enunciado.
- Regla del estudiante: no explicar cada cosa; solo lo necesario, como en sus Excel.

## v0.18.0 — interpolacion de varias partes (4.2, 4.3, Ejercicio 1, 2...)
Plantilla JSON `{"plantilla":"interpolacion","x":[..],"y":[..],"fexacta":"exp(x)","partes":[...]}` -> UNA hoja con partes apiladas (hm_apilar), en el estilo de sus hojas (Ejemplo2 para Lagrange, newthonRapshon para Newton).
Partes: `lagrange` (casos: xe, idx 1-based, rotulo), `newton` (xe, grados), `comparacion` (a, b, etiquetas; solo si el enunciado pregunta cual es mejor), `cota` (caso, nodos, derivada, xmax; solo si piden cota teorica).
Regla: solo lo que pide el enunciado; sin columnas de error/exacto/"Me piden" por defecto. Todo con formulas vivas.

v0.18.1: motor Claude por API (ANTHROPIC_API_KEY, OCT_IA_PROVIDER=anthropic) con max_tokens 8192; mismas plantillas y mismo Excel que con Codex.

v0.19.0: oif_setup guarda la clave de Claude en ~/.oif (una vez, la pide al primer octavei; octavei setup para cambiarla); Claude primero, Codex si se omite.

v0.20.0: clave cifrada con contrasena: oif_cifrar (genera clave_cifrada.txt), oif_clave.m guarda el texto cifrado, oif_setup pide la contrasena.

v0.21.0: celdas combinadas en hm_xlsx (marca {M} al inicio de un texto = fusiona con la celda de la derecha); Newton interpolacion con encabezados fusionados de a 2 como newthonRapshon (f[xk,xk+1]...).

v0.21.1: ancho de columna fijo 11.5 (como sus hojas, sin ensanchar por texto) y partes apiladas con 1 fila de separacion (no 2).

v0.22.0: Lagrange sin rotulo NODOS: tabla x|y pegada arriba (A1) y cajas desde la columna D (una columna de separacion, 1 fila entre bandas); textos de cota solo ASCII con ^ (sin superindices ni letras griegas).

v0.23.0 REGLA DE COMPACTACION (tambien en el prompt de octavei): nunca fila/columna vacia entre un subtitulo/rotulo y su tabla; a lo mas 1 fila vacia entre bloques; sin rotulo NODOS; ASCII simple en textos (x^2, e^(x^2-1)); ancho de columna normal 11.5. Lagrange: cajas con la tabla x/y pegada al rotulo; Newton: encabezados en fila 5-6 (sin fila vacia tras la nota) y los P(x) en filas seguidas.

v0.23.1: sin bordes en rotulos/subtitulos (GRADOn x=, L0(x)=, P(x)=, grado, cota): solo llevan borde las tablas de datos. Regla para la extension.

v0.24.0 AUDITORIA con las reglas de compactacion en TODAS las hojas: regresion (titulo y tabla sin fila vacia, bloques separados por 1 fila, rotulos m=, N+1=, Si X=, y= sin borde), regresion multiple pegada a la hoja `Regresion multiple` de clase (misma fila/columna; extras error estandar/r/Me piden solo si d.resp), interpolacion (cota con % ). Lo que va EN PAPEL (d.sistema = ecuaciones reordenadas E.D.D., d.despeje = despeje por incognita, texto de la cota) se escribe como comentario `%`. Plantillas jacobi/gaussseidel/puntofijo aceptan "sistema" y "despeje".
