
## Reglas del Excel de ia (v0.9.11, obligatorias)
- Un ejercicio completo = UNA sola hoja (partes apiladas), con margen: columna A y fila 1 vacias (como sus hojas).
- Un solo titulo por parte (sin repetir); respuesta final con {y} (amarillo); bordes solo en tablas (los pone hm_xlsx).
- Ninguna respuesta tipeada: todo resultado es formula viva que jala de la tabla (AVERAGE, SUM, SUMPRODUCT, MMULT, MINVERSE...); solo los datos del enunciado son numeros fijos. Interpretaciones pueden ser formulas de texto.
- Estas reglas estan en el system prompt de ia.m; ia.m desplaza referencias (filas y columnas) al apilar.

## Libros del usuario (v0.9.12)
- `hm_xlsx_agregar(origen, C, nombre)`: agrega una hoja a una COPIA del libro; copia crudo (byte a byte) todo lo del usuario (imagenes, graficos, formulas); solo cambian workbook.xml, rels, [Content_Types].xml y styles.xml (se agregan estilos al final).
- `ia("... @libro.xlsx")` usa esa funcion. Lo hecho a mano (imagenes de formulas, plots) nunca se inventa ni se toca.
- Sin verificar: abrir la copia en Microsoft Excel real; Windows (usa unzip de Octave).

## v0.10.0 (modo teclas, prompt octave:N, exportar simple)
- `ia` sin argumentos muestra el prompt `octave:N>` (N = siguiente numero real de la sesion, `hm_prompt_n`). `ia 3` / `ia dieta` / `ia 0` (lista) usan el catalogo `hm_catalogo` (8 ejercicios de regresion + 4 de clase); otra pregunta va a Codex/API.
- `hm_teclear`: una tecla = una letra del codigo; con la linea terminada otra tecla la ejecuta (evalin base); Esc sale. `OCT_IA_TECLAS=0` ejecuta todo sin teclas, `=texto` solo imprime (modo viejo). En la GUI de Octave (sin `kbhit`) una tecla/Enter = una linea completa.
- `exportar` (alias `export`): arma el Excel con formulas vivas (`hm_ej_xlsx`) del ultimo ejercicio de `ia`, de `exportar(N)` (catalogo) o de las variables de la sesion (x,y [ap] / x1,x2,y). Ya no escribe Excel automaticamente al preguntar a la IA: el bloque ```excel se guarda y sale con `exportar`.
- `hm_xlsx`: celdas `struct("v",valor,"s",0..4)` fuerzan el estilo (0 normal, 1 tabla, 2 negrita, 3 amarillo, 4 tabla+amarillo).
- ia.m: alcance "desde el 14 de septiembre". Sin verificar: kbhit en una terminal real (probado solo en un pty), GUI de Octave, Windows/macOS.

## v0.11.0 (paquete `oi`, comando `octavei`)
- Paquete renombrado: `oi` (antes octguias). Cargar con `pkg load oi`. Comando principal `octavei` (`ia` queda como atajo). Desinstalar el viejo: `pkg uninstall octguias`; en ~/.octaverc cambiar `pkg load octguias` por `pkg load oi`.
- El prompt para la IA (octavei.m, variable `sis`) ahora describe el estilo de las hojas de clase (tabla de calculo sin bordes, datos con {k}, cajitas, respuestas {Y}/{K}), la estructura de regresion de la hoja tarea (sin SST), "Comparacion" y "Me piden:", y las CAPTURAS: solo si el enunciado pide grafico o lo hecho en Octave se deja un titulo {b} y 20 filas vacias para pegar; nada se inventa ni se simula.
- hm_xlsx: marcas {n} sin borde, {k} con borde, {Y} amarillo sin borde, {K} amarillo con borde (ademas de {b}, {y}).
- Ejercicio de colesterol (inciso a): deja el titulo "Captura del diagrama de dispersion (pegar aqui)".

## v0.11.1
- `haz N` / `haz1`..`haz30`: resuelve la imagen N (N.png, ejN.png, ejeN.png, ejercicioN.png; png/jpg/webp) de la carpeta actual.
- Codex ya no cambia la carpeta de Octave (el explorador de la GUI no salta a /tmp): el `cd` va dentro del comando.
- Numero de prompt corregido en la GUI (ignora encabezados "# Octave" del historial). En la GUI, Enter = una linea.

## v0.11.2
- El Excel se guarda SOLO al terminar el ejercicio (catalogo o Codex), en la carpeta actual; solo se imprime `[nombre.xlsx]`, sin ruta ni textos. Si se detiene con Esc no se exporta. `exportar` sigue disponible a mano.

## v0.12.0
- `haz examen.pdf` (o `haz 1` si existe 1.pdf): convierte hasta 6 paginas (OCT_IA_PAGS) a imagenes con Ghostscript/pdftoppm, las manda a Codex en UNA consulta con el formato `@@EJ n | octave|excel | titulo` y guarda el plan. Luego `start1`, `start2`... (hasta `start12`; `start N`): tipo octave -> escribe el codigo con teclas y exporta el Excel solo; tipo excel -> solo exporta el Excel.

## v0.12.1
- `start N e` / `start N o` fuerzan solo Excel / con Octave si la lista marco mal. Prompt: criterio excel/octave segun lo que NO tiene diario de la docente; orden obligatorio antes de iterar (E.D.D. -> BJ y C -> verificar convergencia con normas/radio espectral -> iterar).

## v0.12.2
- Titulo vacio en la lista de start (fallback), y una linea "..." mientras Codex piensa.

## v0.12.2
- Titulo vacio en la lista de start (fallback) y una linea "..." mientras Codex piensa.

## v0.12.3
- start/catalogo mas discretos (sin titulo ni "presiona cualquier tecla"); en la GUI la linea sale en el mismo prompt; todos los ejercicios del PDF piden su Excel; numeracion de prompt corregida para la GUI (historial incremental).

## v0.13.0
- Comandos `ss1`..`ss12` / `ss N [e|o]` (reemplazan a start; `start` queda como alias).
- Las lineas que escribe el tool entran al historial de comandos (history -r); hm_prompt_n descuenta esas lineas (appdata oi_extra) para no desfasar los numeros.

## v0.13.1
- PDF: UN solo Excel para todo el PDF (nombre del PDF, en la carpeta actual), una hoja por ejercicio (Ej1 titulo, Ej2 ...); cada ssN agrega o reemplaza su hoja y las hojas quedan ordenadas por numero.

## v0.13.2
- El tool quita el ; final de cada linea para que siempre salga el resultado (OCT_IA_PUNTOYCOMA=1 los conserva).

## v0.14.0
- Catalogo 13: interpolacion de Newton (Ejemplo 4.4, solo Excel) con la forma de la hoja newthonRapshon de clase.xlsx (hm_ej_xlsx: generador newton). Prompt: Newton por diferencias divididas = solo Excel + su layout.

## v0.14.1
- Plantillas en el bloque excel de Codex: {"plantilla":"newton|regresion|multiple", datos...}; el programa arma la hoja con hm_ej_xlsx (misma forma que catalogo, sin errores de rotulado). hm_ej_xlsx("", d) devuelve las celdas.

## v0.15.0
- Catalogo 14: punto fijo (Clase 03). Excel con formulas vivas en formato `I | Xi | E` (reproduce su tabla: E9=5.2789e-05).
- Plantillas `puntofijo`, `jacobi`, `gaussseidel` (JSON, Codex solo da datos). `hm_bloques_vivo("")` devuelve celdas sin escribir.
- Newton de sistemas: sin plantilla (pendiente). Modo offline/por entradas: pendiente.

## v0.15.1
- Plantilla lagrange (formato Ejemplo2: cajita de nodos + Li(x) + P=SUMPRODUCT). Validador de formulas (avisa #NAME?). Prompt: reglas de formulas.

## v0.15.2
- apilar: referencias entre partes (a!C60, 'Recta'!B3) se resuelven al desplazamiento de esa parte (antes daban #NAME?).

## v0.15.3
- octavei: 'haz X', 'ssN', 'exportar' escritos dentro del prompt de octavei se ejecutan como comando (antes iban a Codex como pregunta).

## v0.15.4
- Marcas dobles {k}{b}x ya no salen literales; validador sin falsos avisos con $B$10; SUMPRODUCT fila x columna (#VALUE!) se expande a suma de productos.

## v0.16.0 (examen modelo)
- Layout de su ods "examenmodelo": por pregunta, titulo del metodo en fila 18 (A / F), tabla `I | Xi | Ei` desde fila 22 (B:D, F:H...), n filas por iteracion. Plantilla `examen` (metodos: newton | puntofijo | jacobi | gaussseidel) + `newtonsistemas`. Newton en Excel: J y F por iteracion en celdas auxiliares (a la derecha) y `X - INDEX(MMULT(MINVERSE(J),F),j)`.
- Catalogo 15 (pregunta 1: Newton + punto fijo 3x3, X0=(1,0,0), 2 iteraciones) y 16 (pregunta 2: Jacobi con despeje en comentarios). Claves: "modelo p1", "modelo p2".
- Newton de sistemas: SIN comprobar jacobiano; X0 sin transpuesta; el prompt exige el despeje (comentarios %) antes de BJ en Jacobi/GS.
- Nota: el diario del estudiante tenia BJ(3,:)=[0 0 1/2] (error); correcto [0 1/2 0] (z=y/2). El Excel del estudiante ya tenia z2=0.875.

## v0.16.1
- Celdas auxiliares J/F del Newton en Excel: columnas ocultas (marca {h}). Comprobar jacobiano/convergencia: solo si el enunciado lo pide, explicado con comentarios %.

## v0.17.0 (interpolacion)
- hm_apilar.m publico (antes interno de hm_excel_ia): apila partes, quita filas vacias iniciales, respeta estilos (struct v,s) y entiende referencias entre partes ('nombre'!C6).
- hm_ej_xlsx: segunda salida `info` (posiciones de P/x/error); lagrange: `casos` (idx de nodos elegidos + rotulo) y `fexacta` (f(x) exacto y error absoluto); newton: `fexacta`, `rotulo`, fila "Mas apropiado" (menor error).
- Libro de ejemplo: Interpolacion_4.2_4.3_ej1_ej2.xlsx (generado con un script a partir de estos bloques).

## v0.17.1
- Lagrange ahora con la forma EXACTA de la hoja Ejemplo2 de clase.xlsx: NODOS en A14, cajitas "GRADOn | x= | valor", nodos x0 y0.., P(x)=y0L0(x)+.., L0(x)=(x-x1)/(x0-x1) y L0(valor)=, P(valor)= amarillo; cajitas de a dos (columnas E y L) hacia abajo. Sin columnas extra (nada de exacto/error ni bloques "Me piden"): solo lo que pide el enunciado.
- Regla del estudiante: no explicar cada cosa; solo lo necesario, como en sus Excel.

## v0.18.0 — interpolacion de varias partes (4.2, 4.3, Ejercicio 1, 2...)
Plantilla JSON `{"plantilla":"interpolacion","x":[..],"y":[..],"fexacta":"exp(x)","partes":[...]}` -> UNA hoja con partes apiladas (hm_apilar), en el estilo de sus hojas (Ejemplo2 para Lagrange, newthonRapshon para Newton).
Partes: `lagrange` (casos: xe, idx 1-based, rotulo), `newton` (xe, grados), `comparacion` (a, b, etiquetas; solo si el enunciado pregunta cual es mejor), `cota` (caso, nodos, derivada, xmax; solo si piden cota teorica).
Regla: solo lo que pide el enunciado; sin columnas de error/exacto/"Me piden" por defecto. Todo con formulas vivas.

v0.18.1: motor Claude por API (ANTHROPIC_API_KEY, OCT_IA_PROVIDER=anthropic) con max_tokens 8192; mismas plantillas y mismo Excel que con Codex.

v0.19.0: oif_setup guarda la clave de Claude en ~/.oif (una vez, la pide al primer octavei; octavei setup para cambiarla); Claude primero, Codex si se omite.

v0.20.0: clave cifrada con contrasena: oif_cifrar (genera clave_cifrada.txt), oif_clave.m guarda el texto cifrado, oif_setup pide la contrasena.

v0.21.0: celdas combinadas en hm_xlsx (marca {M} al inicio de un texto = fusiona con la celda de la derecha); Newton interpolacion con encabezados fusionados de a 2 como newthonRapshon (f[xk,xk+1]...).

v0.21.1: ancho de columna fijo 11.5 (como sus hojas, sin ensanchar por texto) y partes apiladas con 1 fila de separacion (no 2).

v0.22.0: Lagrange sin rotulo NODOS: tabla x|y pegada arriba (A1) y cajas desde la columna D (una columna de separacion, 1 fila entre bandas); textos de cota solo ASCII con ^ (sin superindices ni letras griegas).

v0.23.0 REGLA DE COMPACTACION (tambien en el prompt de octavei): nunca fila/columna vacia entre un subtitulo/rotulo y su tabla; a lo mas 1 fila vacia entre bloques; sin rotulo NODOS; ASCII simple en textos (x^2, e^(x^2-1)); ancho de columna normal 11.5. Lagrange: cajas con la tabla x/y pegada al rotulo; Newton: encabezados en fila 5-6 (sin fila vacia tras la nota) y los P(x) en filas seguidas.

v0.23.1: sin bordes en rotulos/subtitulos (GRADOn x=, L0(x)=, P(x)=, grado, cota): solo llevan borde las tablas de datos. Regla para la extension.

v0.24.0 AUDITORIA con las reglas de compactacion en TODAS las hojas: regresion (titulo y tabla sin fila vacia, bloques separados por 1 fila, rotulos m=, N+1=, Si X=, y= sin borde), regresion multiple pegada a la hoja `Regresion multiple` de clase (misma fila/columna; extras error estandar/r/Me piden solo si d.resp), interpolacion (cota con % ). Lo que va EN PAPEL (d.sistema = ecuaciones reordenadas E.D.D., d.despeje = despeje por incognita, texto de la cota) se escribe como comentario `%`. Plantillas jacobi/gaussseidel/puntofijo aceptan "sistema" y "despeje".

v0.24.1: (1) celdas con formulas que Excel no reconoce (ej. =FORMULA_0 que escribio la IA en una hoja libre) se dejan VACIAS con aviso en vez de #NAME?; (2) el prompt del PDF exige plantillas (puntofijo, newtonsistemas, jacobi, gaussseidel, examen, interpolacion, regresion) para esos temas, nunca filas libres; (3) punto fijo 3 variables en Octave usa X0/X1/E1 (como sus otros metodos), ya no XX1/EE1.

v0.25.0 ANALISIS DEL ENUNCIADO: el prompt exige un analisis previo (que pide cada inciso, que metodo/plantilla, que preparar a papel: E.D.D., despejes, J, nodos/grados; verificar datos; agregar solo lo que se pide; combinar plantillas si hace falta). Con API de Claude se activa razonamiento extendido (budget 6000 tokens, max_tokens 16000; OCT_IA_THINK=0 lo desactiva; si la API responde 400 reintenta sin razonamiento). max-time de curl 280 s. El texto se toma de los bloques type=text.

v0.25.1: ARREGLO error HTTP 400 "system.0: Input does not match the expected shape": faltaba un `...` al agregar el ANALISIS PREVIO al prompt y el texto quedaba en varias filas (jsonencode lo mandaba como lista). Ahora system es un solo texto (probado con servidor falso). PKG_ADD + oif_arranque: al hacer `pkg load oi` (o al abrir Octave) pide la contrasena de la clave una sola vez (Enter = omitir); si ya hay clave guardada la carga sola.

v0.25.2: al cargar el paquete ya NO pregunta (el prompt dentro de PKG_ADD no se veia); imprime un aviso "escribe oif_setup" y oif_setup muestra "contrasena>" . oif_setup("contrasena") tambien acepta la contrasena como argumento. octavei/haz piden la contrasena si falta (mismo oif_setup).

v0.26.0: hoja "examen" pegada a la esquina (A1: titulo en fila 1, tabla I|Xi|E en fila 2, tablas una al lado de otra). Nuevo metodo "verificar" ({"metodo":"verificar","F":[..],"puntos":[[..]],"nota":".."}): tabla x,y,z,f1..fn evaluada con formulas vivas (incisos "muestre que ... es solucion"); la nota va como comentario %. Varios puntos de partida = un metodo newton por X0. El prompt exige atender TODOS los incisos (a, b, c) y avisar si la verificacion no da cero (errata: en el ej. de clase (+-1,0,0) no anula F; las soluciones son (+-1,0,1)). Sin avisos de sym ("passing floating-point values...") al teclear.

## v0.26.1
- Fix: `'ABS' undefined` al exportar Excel: nuevo `hm_normexpr` (funciones/variables sin importar mayusculas, `**`->`^`, signos unicode) usado en `hm_fexcel` e `iterativa` (g, F, J) antes de str2func.
- Prompt: despeje de punto fijo como en clase (g1=(2-y^2-z^2)/x, g2=(1-z)/3, g3=x^2+y^2); prohibido sqrt/abs en g; aviso `%` cuando F(punto)!=0 al verificar soluciones.

## v0.27.0
- Jacobi/Gauss-Seidel: plantilla con A y b (sistema reordenado): cada fila se despeja con aritmetica exacta (antes B/C redondeados -> Gauss-Seidel con valores mal). Gauss-Seidel usa lo ya calculado en la iteracion (`gs`). `conv:true` agrega bloque Convergencia (E.D.D. por filas, D+L, U, BJ, BGS, normas inf con formulas vivas). `sistema`/`despeje` salen como comentarios % bajo las tablas del examen.
- Regresion: `solo:"parabola"` -> hoja con solo la parabola (datos en las columnas x|y, 15 columnas, estadisticas bajo coef.), sin recta ni comparacion.
- Lagrange: `labs` (nombres de las columnas/variables) -> interpolacion inversa (x=valores de y, labs ["y","x"]); idx = numero de punto + 1.
- Prompt: reglas de interpolacion inversa, solo parabola, A/b exactos, funciones en minuscula; hm_normexpr acepta mayusculas.

## v0.28.0
- `repensar N [nota]` (alias `otra`, `rehacer`): la IA vuelve a leer el ejercicio N del PDF (guarda las imagenes en appdata oi_plan_imgs), recibe su solucion anterior + lo que el estudiante vio raro, y lo rehace o lo resuelve por otro camino; reemplaza el plan N y se ejecuta con `ssN` (reemplaza la hoja N). Sin numero: rehace la ultima pregunta suelta (oi_ult_q / oi_ult_resp). `fmt_plan()` comparte el formato del plan.
- Exportacion: junto a cada .xlsx se deja un .ods (hm_ods, LibreOffice headless con perfil temporal; no hace nada si no esta instalado; `setenv("OCT_IA_ODS","0")` lo desactiva). Hook en hm_xlsx (omite archivos en tempdir) y hm_xlsx_agregar.
- Excel/Windows: el xlsx solo usa funciones clasicas (SUM, SUMPRODUCT, INDEX/MMULT/MINVERSE, IF, COUNTIF, TEXT...), sin arrays dinamicos ni _xlfn.

## v0.28.1
- Fix "syntax error": si la IA parte una matriz/comando en varias lineas, `unir_lineas` (en mostrar) las junta en una linea (filas con ;) antes de teclearlas. Prompt: cada comando en una sola linea; el comentario de verificacion debe decir el resultado real de F.

## v0.28.2
- Verificar soluciones: si F no se anula en un punto, la hoja agrega `% OJO: ...` y las filas de los puntos cercanos que SI anulan F (Newton numerico, solo si converge a un valor limpio), con formulas vivas.
- Jacobi/Gauss-Seidel: formulas limpias `=(7+B3+2*B5)/4` (sin 0+ ni 1*), despeje en `%` igual.
- Newton interpolacion: `extra` [{rotulo, expr con P}] (ej. flecha = 50-P). Parabola sola: linea `a) P2(x)=a0+a1*x+a2*x^2` con formula viva.

## v0.28.3
- Jacobi/Gauss-Seidel (A,b): las formulas de iteracion ya no llevan numeros del sistema; apuntan a las celdas del bloque "Sistema (reordenado)" (A | b | E.D.D.) a la derecha de las tablas: `=($L$3-$J$3*B4-$K$3*B5)/$I$3`. El bloque Convergencia (D+L, U, BJ, BGS) tambien referencia esas celdas, asi que cambiar A o b recalcula todo.

## v0.28.4
- Octave 11 inunda de warnings ("concatenation of single and double quoted...", "language extension"): `hm_silenciar` (warning off all + restaura al salir) al inicio de octavei y exportar.
- Jacobi/Gauss-Seidel con A,b: `reordenar_sis` en normaliza: si A no es E.D.D. o tiene ceros en la diagonal busca el orden de filas E.D.D. (o el mas parecido) y deja la nota `% Filas reordenadas...`; error con tamanos legibles si A no es cuadrada del tamano de x0.

## v0.29.0  (revision del sistema de extension)
- Problema: la IA reordenaba mal el sistema (diagonal con ceros) y escribia codigo de Octave roto; Excel y Octave podian no coincidir.
- `hm_octave_plantilla(J)` (nuevo): arma el codigo de Octave (estilo de clase) de jacobi/gaussseidel/puntofijo/newtonsistemas/examen/verificar desde el MISMO JSON del Excel; devuelve tambien `chk` (valores esperados por linea). `octavei>mostrar` ya no usa el bloque octave de la IA para esos temas (`codigo_plantilla`, `preparar_codigo`).
- `hm_ej_xlsx` modos internos: `"@norm"` (datos normalizados: A reordenada, despeje auto desde A y b, J comprobada), `"@pf"` (g vs F), `"@verif"`. `normaliza` ahora: despeje en papel generado desde A,b (se ignora el de la IA), `revisar_newton` (compara J con `hm_derivar(F)`, usa la exacta si no coincide, nota si J(X0) singular), `nota_pf` (g(x*)=x* donde F=0).
- `hm_derivar(expr,var)` (nuevo): derivada simbolica en Octave puro (+ - * / ^ exp sin cos tan log sqrt atan).
- `hm_validar(L,chk)` (nuevo): ejecuta las lineas en espacio aislado (`correr`, nombres internos oi_*__), omite lineas peligrosas (system, delete, fopen, cd, clear, close, eval...), matriz singular = error, detecta NaN/Inf, compara con `chk` (tol 1e-5: `subs` de symbolic racionaliza los decimales y arrastra ~1e-8). Restaura output_precision/format/figuras.
- `octavei`: la llamada a la IA es `consultar(sis,pregunta,imgs)` (reusable); `reparar` pide el bloque octave corregido con el mensaje real de Octave (max 2 rondas); `reemplazar_bloque` para OCT_IA_TECLAS=texto; `OCT_IA_VALIDAR=0` apaga. `ss N` acepta ejercicios de Octave sin bloque octave si hay plantilla iterativa.
- Fix: `hm_ej_xlsx>revisar_puntos` hacia `warning("on","all")` y reencendia todos los avisos (el diluvio de warnings); ahora hm_ej_xlsx abre con hm_silenciar y no hay on/off.
- Prompt: Jacobi/GS pasan A,b TAL COMO LO DA EL ENUNCIADO (el programa reordena); J opcional en Newton; F opcional en punto fijo; NO escribir bloque octave en los iterativos.
- Nota: en regex de Octave `\b` NO es borde de palabra (usar `\<` `\>`).

## v0.29.1  (sin warnings de Octave 11)
- Octave 11 trae activos `Octave:language-extension` y `Octave:mixed-string-concat`: los de sintaxis salen al PARSEAR un .m la primera vez (antes de que hm_silenciar pueda actuar), por eso `haz`/`ss`/`octavei` los mostraban. Se reescribio TODO el paquete sin `!`, `!=`, `++`, `--`, `+=`, `-=` (usar `~`, `~=`, `k = k + 1`; ver /tmp/bi/limpia.py en la sesion de trabajo, transformador con tokenizador de cadenas/comentarios). Comprobado con `__parse_file__` y `warning("on","all")`: 0 avisos de sintaxis en los 100 archivos. Los hojas generadas son identicas (comparadas celda por celda).
- Regla para codigo nuevo: NO usar `!`, `!=`, `++`, `+=`; comprobar con `__parse_file__(archivo)` y `warning("on","all")`.
- `hm_silenciar` tambien al inicio de haz, ss, repensar, h (concatenaciones de cadenas mixtas en tiempo de ejecucion) y dentro de la limpieza de hm_validar.
- Quedan solo los `missing-semicolon` (apagado por defecto) de `catch e`.

## v0.29.2  (salida discreta)
- `armar_plan` (octavei): ya no lista ss1..ssN con sus nombres; imprime UNA linea `  ready: ss1 - ssN` y nada mas.
- `oif_pedir(prompt)` (nuevo): lee texto sin eco con `kbhit` (Enter termina y borra la linea del prompt, Esc = vacio, Retroceso borra); si el terminal no deja leer teclas sueltas cae a `input`.
- `oif_setup` / `oif_cifrar`: la contrasena (y la clave sin cifrar) se piden con `oif_pedir`, una sola linea `  > `; sin mensajes de exito; contrasena mala = `  no` (3 intentos).
- `oif_arranque`: ya no imprime el aviso de "escribe oif_setup" al cargar el paquete.
- Regla: nada de `!`, `!=`, `++`, `+=` en codigo nuevo; para pedir texto secreto usar `oif_pedir`, nunca `input`.

## v0.29.3  (menos ruido)
- `octavei>preparar_codigo`: ya no imprime "(comprobando el codigo en Octave...)" ni "Codigo armado ... sin errores" / "Codigo comprobado ... sin errores". Si todo sale bien no se dice nada; solo salen los avisos reales (OJO..., no pude comprobar con symbolic, "La IA corrigio el codigo tras un error ...", y "(error en Octave ...; le pido a la IA ...)" mientras espera la correccion).


## v0.29.4  (`h` pide los datos y los teclea, sin IA)
- `h` (lista de metodos) ahora tiene 3 columnas en la matriz `m`: archivo, rotulo y CLAVE (gaussjordan, inversa, lu, cholesky, normas, reordenar, jacobi, gaussseidel, directos, puntofijo, newton, regresion, ajuste, interpola). Tras la chuleta: Enter = modo nuevo (`hm_h_teclas (clave)`), `g` = modo guiado de antes (`feval (archivo)`), `n` = solo la chuleta.
- `hm_h_teclas.m` (nuevo): pide los datos (matriz A y b o las ECUACIONES escritas, X0, iteraciones o tolerancia, tablas x e y, `excel archivo.xlsx RANGO`) y arma el mismo texto que devolveria la IA (bloque ```octave y, si el metodo tiene Excel, bloque ```excel con "plantilla"). Lo entrega a `octavei (struct ("texto", t))`, asi usa el MISMO camino: `mostrar` -> `preparar_codigo`/`hm_validar` -> `hm_teclear` (una letra por tecla) -> `exportar`. No llama a ninguna IA.
- `octavei.m`: nuevo campo de `pregunta`: `texto` (respuesta ya armada) -> `mostrar (pregunta.texto, "", false, [])`.
- Con Excel: Jacobi, Gauss-Seidel (plantillas jacobi / gaussseidel), punto fijo, Newton de sistemas (puntofijo / newtonsistemas), regresion recta/parabola/ambas/multiple de 2 variables (regresion / multiple), Lagrange y Newton de interpolacion (lagrange / newton). Solo codigo: Gauss-Jordan, inversa, LU, Cholesky, normas, reordenar, directos (Cramer, eliminacion, sustitucion) y ajuste con polyfit.
- `hm_pedir.m` (nuevo): `v = hm_pedir (texto, def)`; evalua lo que escribas; acepta `excel datos.xlsx B4:D9` (.ods/.csv); `hm_pedir ("@valor", s)` evalua sin preguntar.
- `hm_lineas.m` (nuevo): generadores de lineas (datos2, datos3, poly1, poly2, multiple) sacados de `hm_catalogo`, que ahora los usa (salida identica).
- `hm_octave_plantilla`: si el unico metodo ya lleva el mismo titulo en su comentario, no se repite la linea de titulo.
- `oif_clave.m`, `oif_home.m`: comentario de cabecera (quita el aviso "unusable help text" al instalar).
- Probado en instalacion limpia: todos los metodos de `h`; los Excel recalculados con LibreOffice (0 errores) y comparados con numpy; modo de teclas reales con pty.

## v0.29.5  (fidelidad a tus hojas + anss)
- Auditoria contra tus archivos (claseS6, claseFmiercoles, claseytarea, clase, S3C9, s3C11, S4C12, S5C13): regresion polinomial/multiple, Lagrange y Newton de interpolacion, Gauss-Seidel y punto fijo ya seguian tu disposicion; se corrigio lo que diferia.
- Encabezado de error como en tus hojas: Gauss-Seidel/Jacobi `E`, punto fijo y Newton de sistemas `Ei`, y todas las tablas de la plantilla `examen` `Ei` (`hm_bloques_vivo`: opcion `op.hdrE`; `hm_ej_xlsx>iterativa` y `>examen` la ponen).
- Punto fijo con `"conv":true` (y en `h`: "estudiar la convergencia? s"): `hm_octave_plantilla>cod_pf` teclea como en tu clase `dg1x=diff(g1,x)` ... y `double(subs(dg1x,[x y],[x0 y0]))` en X0, mas un comentario con la suma por columna de |dg| (con `hm_derivar`); si la derivada no esta definida en X0 solo avisa. El prompt de octavei lo documenta.
- Lagrange tecleado (`h`): tras cada `Pg=...` agrega `hold on; ezplot(@(t) polyval(polyfit(xs,ys,g),t), [min(x) max(x)])` (tu clase dibuja el polinomio junto a los puntos).
- `anss N [nota]` / `anss1..anss12 [nota]` (nuevo): despues de `haz examen.pdf`, la IA analiza OTRA VEZ el ejercicio N con lo que escribas y lo ejecuta de una vez (repensar N + ssN; marca appdata `oi_anss` para que repensar no pida escribir ssN). Si el ejercicio no cambia no lo ejecuta. `ssN texto` / `ss N texto` hace lo mismo. `ss N e|o` sigue forzando solo Excel / con Octave. `octavei` reconoce `anssN` dentro de su prompt.
- Jacobi: se mantiene la disposicion G:I `I | Xi | E` de tus hojas de la semana 7 (tu hoja claseS6 usa I:K con `Xk`; es la unica asi).

## v0.29.6  (historial limpio + oifs)
- `oif_setup` pasa a llamarse `oifs` (mismo comportamiento: `oifs`, `oifs("clave")`, `oifs("borrar")`); se quita `oif_setup.m`. `octavei setup` y los mensajes usan `oifs`. Nuevo: `oifs limpiar` quita del historial todo lo que ya habia de comandos del paquete.
- `hm_ocultar.m` (nuevo): al empezar `haz`, `ss`, `anss`, `repensar`, `h`, `exportar`, `octavei` y `oifs` se quita del historial de Octave (en memoria; se guarda al salir) el comando del paquete que se acaba de escribir (haz/ssN/anssN/octavei/exportar/export/repensar/otra/rehacer/ia/oifs/h). Octave no borra una sola linea: `history -c` y `history -r` con las demas (las lineas de codigo que teclea `hm_historial` se quedan). El numero del prompt (octave:N>) lo lleva Octave aparte y no cambia; solo se corrige `oi_extra` para `hm_prompt_n`. Con `OCT_IA_N` no se toca. Probado en consola real (pty): sesion nueva sin archivo de historial, con archivo y con `# Octave ...` de sesiones anteriores.

## v0.29.7  (@nombre sin extension en octavei)
- `hm_arrobas.m` (nuevo): dentro de la pregunta de `octavei`, `@nombre` sin extension se busca en la carpeta actual como hace `haz` (prefijos "", ej, eje, ejercicio, ejer, e; .png .jpg .jpeg .webp .gif, luego .pdf y al final .xlsx; sin distinguir mayusculas) y se reescribe como `@"archivo.ext"` antes de leer imagenes/libro. `@examen` que resuelve a un PDF = `octavei (struct ("pdf", ruta))` (igual que `haz examen`). Si un `@nombre` simple (letras, numeros, _ y -) no existe: error claro sin llamar a la IA. `@(x)...` y correos (`a@b.com`) no se tocan; con extension funciona como antes.
